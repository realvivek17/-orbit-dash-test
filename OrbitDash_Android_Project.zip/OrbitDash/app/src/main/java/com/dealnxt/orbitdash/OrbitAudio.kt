package com.dealnxt.orbitdash

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.media.SoundPool.OnLoadCompleteListener
import java.util.Collections

/** Local-only audio. Missing audio support never blocks or crashes gameplay. */
internal class OrbitAudio(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("orbit_dash_settings", Context.MODE_PRIVATE)
    private var hostResumed = false
    private var released = false
    private var musicPlayer: MediaPlayer? = null
    private val loadedSounds: MutableSet<Int> = Collections.synchronizedSet(HashSet())
    private val soundPool: SoundPool
    private val switchId: Int
    private val collectId: Int
    private val crashId: Int
    private val startId: Int
    private val clickId: Int
    private val rewardId: Int

    val musicEnabled: Boolean
        get() = prefs.getBoolean("music_on", true)
    val effectsEnabled: Boolean
        get() = prefs.getBoolean("effects_on", true)

    init {
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        soundPool = SoundPool.Builder()
            .setMaxStreams(5)
            .setAudioAttributes(attributes)
            .build()
        soundPool.setOnLoadCompleteListener(OnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) loadedSounds.add(sampleId)
        })
        switchId = soundPool.load(appContext, R.raw.sfx_switch, 1)
        collectId = soundPool.load(appContext, R.raw.sfx_collect, 1)
        crashId = soundPool.load(appContext, R.raw.sfx_crash, 1)
        startId = soundPool.load(appContext, R.raw.sfx_start, 1)
        clickId = soundPool.load(appContext, R.raw.sfx_click, 1)
        rewardId = soundPool.load(appContext, R.raw.sfx_reward, 1)
        musicPlayer = try {
            MediaPlayer.create(appContext, R.raw.orbit_ambience)?.apply {
                isLooping = true
                setVolume(0.34f, 0.34f)
            }
        } catch (_: Exception) {
            null
        }
    }

    fun onHostResume() {
        hostResumed = true
        startMusicIfAllowed()
    }

    fun onHostPause() {
        hostResumed = false
        try {
            if (musicPlayer?.isPlaying == true) musicPlayer?.pause()
        } catch (_: Exception) {
            // Audio lifecycle is best-effort; gameplay remains independent.
        }
    }

    fun setMusicEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("music_on", enabled).apply()
        if (enabled) startMusicIfAllowed() else pauseMusic()
    }

    fun toggleMusic() = setMusicEnabled(!musicEnabled)

    fun setEffectsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("effects_on", enabled).apply()
    }

    fun toggleEffects() = setEffectsEnabled(!effectsEnabled)

    fun play(effect: Effect) {
        if (released || !effectsEnabled) return
        val id = when (effect) {
            Effect.SWITCH -> switchId
            Effect.COLLECT -> collectId
            Effect.CRASH -> crashId
            Effect.START -> startId
            Effect.CLICK -> clickId
            Effect.REWARD -> rewardId
        }
        if (loadedSounds.contains(id)) {
            try {
                soundPool.play(id, 0.76f, 0.76f, 1, 0, 1f)
            } catch (_: Exception) {
                // Suppress unsupported audio-device errors.
            }
        }
    }

    private fun startMusicIfAllowed() {
        if (released || !hostResumed || !musicEnabled) return
        try {
            val player = musicPlayer ?: return
            if (!player.isPlaying) player.start()
        } catch (_: Exception) {
            // Music failure must never prevent the game from opening.
        }
    }

    private fun pauseMusic() {
        try {
            if (musicPlayer?.isPlaying == true) musicPlayer?.pause()
        } catch (_: Exception) {
            // No-op by design.
        }
    }

    fun release() {
        if (released) return
        released = true
        try { musicPlayer?.stop() } catch (_: Exception) {}
        try { musicPlayer?.release() } catch (_: Exception) {}
        musicPlayer = null
        try { soundPool.release() } catch (_: Exception) {}
        loadedSounds.clear()
    }

    enum class Effect { SWITCH, COLLECT, CRASH, START, CLICK, REWARD }
}
