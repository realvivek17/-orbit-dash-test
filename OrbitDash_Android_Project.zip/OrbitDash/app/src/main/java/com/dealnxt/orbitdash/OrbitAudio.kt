package com.dealnxt.orbitdash

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.media.SoundPool.OnLoadCompleteListener
import java.util.Collections

/** Local-only audio. Missing audio support never blocks or crashes gameplay. */
internal class OrbitAudio(context: Context) {
    data class MusicTrack(val resourceId: Int, val title: String, val mood: String)

    companion object {
        val musicTracks: List<MusicTrack> = listOf(
            MusicTrack(R.raw.music_cosmic_drift, "COSMIC DRIFT", "Calm space flute · ambient and dreamy"),
            MusicTrack(R.raw.music_serenity_flute, "SERENITY FLUTE", "Relaxing bamboo flute · soft and peaceful"),
            MusicTrack(R.raw.music_nebula_pulse, "NEBULA PULSE", "Energetic flute · gentle cosmic rhythm"),
            MusicTrack(R.raw.music_celestial_journey, "CELESTIAL JOURNEY", "Mystical flute · warm and uplifting")
        )
    }

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("orbit_dash_settings", Context.MODE_PRIVATE)
    private var hostResumed = false
    private var released = false
    private var musicPrepared = false
    private var musicPlayer: MediaPlayer? = null
    private val loadedSounds: MutableSet<Int> = Collections.synchronizedSet(HashSet())
    private val soundPool: SoundPool
    private val switchId: Int
    private val collectId: Int
    private val crashId: Int
    private val startId: Int
    private val clickId: Int
    private val rewardId: Int

    var selectedMusicIndex: Int = prefs.getInt("music_track_index", 0).coerceIn(0, musicTracks.lastIndex)
        private set

    val selectedMusicTrack: MusicTrack
        get() = musicTracks[selectedMusicIndex]

    val musicEnabled: Boolean
        get() = prefs.getBoolean("music_on", true)
    val effectsEnabled: Boolean
        get() = prefs.getBoolean("effects_on", true)

    // Deliberately conservative defaults: soft instrumental music and quiet taps.
    private var currentMusicVolume = prefs.getFloat("music_volume", 0.16f).coerceIn(0f, 1f)
    private var currentEffectsVolume = prefs.getFloat("effects_volume", 0.18f).coerceIn(0f, 1f)

    val musicVolume: Float
        get() = currentMusicVolume
    val effectsVolume: Float
        get() = currentEffectsVolume

    init {
        val attributes = gameAudioAttributes()
        soundPool = SoundPool.Builder()
            .setMaxStreams(5)
            .setAudioAttributes(attributes)
            .build()
        soundPool.setOnLoadCompleteListener(OnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) loadedSounds.add(sampleId)
        })
        switchId = soundPool.load(appContext, R.raw.sfx_switch, 1)
        collectId = soundPool.load(appContext, R.raw.sfx_collect, 1)
        crashId = soundPool.load(appContext, R.raw.sfx_crash, 1)
        startId = soundPool.load(appContext, R.raw.sfx_start, 1)
        clickId = soundPool.load(appContext, R.raw.sfx_click, 1)
        rewardId = soundPool.load(appContext, R.raw.sfx_reward, 1)
        // MediaPlayer prepares the currently selected bundled OGG asynchronously.
        musicPlayer = createMusicPlayer(attributes, selectedMusicTrack.resourceId)
    }

    private fun gameAudioAttributes(): AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_GAME)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private fun createMusicPlayer(attributes: AudioAttributes, resourceId: Int): MediaPlayer? {
        val player = MediaPlayer()
        return try {
            player.setAudioAttributes(attributes)
            player.setVolume(musicVolume, musicVolume)
            player.setOnPreparedListener { prepared ->
                if (released || musicPlayer !== prepared) {
                    try { prepared.release() } catch (_: Exception) {}
                    return@setOnPreparedListener
                }
                musicPrepared = true
                try {
                    prepared.isLooping = true
                    prepared.setVolume(musicVolume, musicVolume)
                } catch (_: Exception) {}
                startMusicIfAllowed()
            }
            player.setOnErrorListener { failed, _, _ ->
                if (musicPlayer === failed) {
                    musicPrepared = false
                    musicPlayer = null
                }
                try { failed.release() } catch (_: Exception) {}
                true
            }
            appContext.resources.openRawResourceFd(resourceId).use { descriptor ->
                player.setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.length)
            }
            player.isLooping = true
            player.prepareAsync()
            player
        } catch (_: Exception) {
            try { player.release() } catch (_: Exception) {}
            null
        }
    }

    /** Change to the selected track immediately and keep the choice after relaunch. */
    fun selectMusicTrack(index: Int) {
        if (released || musicTracks.isEmpty()) return
        val nextIndex = index.coerceIn(0, musicTracks.lastIndex)
        if (nextIndex == selectedMusicIndex) return
        selectedMusicIndex = nextIndex
        prefs.edit().putInt("music_track_index", nextIndex).apply()
        musicPrepared = false
        val old = musicPlayer
        musicPlayer = null
        try { old?.pause() } catch (_: Exception) {}
        try { old?.stop() } catch (_: Exception) {}
        try { old?.release() } catch (_: Exception) {}
        musicPlayer = createMusicPlayer(gameAudioAttributes(), selectedMusicTrack.resourceId)
    }

    fun changeMusicTrack(direction: Int) {
        if (musicTracks.isEmpty()) return
        val next = (selectedMusicIndex + direction).mod(musicTracks.size)
        selectMusicTrack(next)
    }

    fun onHostResume() {
        hostResumed = true
        startMusicIfAllowed()
    }

    fun onHostPause() {
        hostResumed = false
        try {
            if (musicPlayer?.isPlaying == true) musicPlayer?.pause()
        } catch (_: Exception) {
            // Audio lifecycle is best-effort; gameplay remains independent.
        }
    }

    fun setMusicEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("music_on", enabled).apply()
        if (enabled) startMusicIfAllowed() else pauseMusic()
    }

    fun toggleMusic() = setMusicEnabled(!musicEnabled)

    fun setEffectsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("effects_on", enabled).apply()
    }

    fun toggleEffects() = setEffectsEnabled(!effectsEnabled)

    fun setMusicVolume(volume: Float, persist: Boolean = true) {
        currentMusicVolume = volume.coerceIn(0f, 1f)
        if (persist) prefs.edit().putFloat("music_volume", currentMusicVolume).apply()
        try { musicPlayer?.setVolume(currentMusicVolume, currentMusicVolume) } catch (_: Exception) {}
    }

    fun setEffectsVolume(volume: Float, persist: Boolean = true) {
        currentEffectsVolume = volume.coerceIn(0f, 1f)
        if (persist) prefs.edit().putFloat("effects_volume", currentEffectsVolume).apply()
    }

    // Persist once on release/cancel rather than writing preferences for every slider movement.
    fun persistVolumes() {
        prefs.edit()
            .putFloat("music_volume", currentMusicVolume)
            .putFloat("effects_volume", currentEffectsVolume)
            .apply()
    }

    fun play(effect: Effect) {
        if (released || !effectsEnabled) return
        val id = when (effect) {
            Effect.SWITCH -> switchId
            Effect.COLLECT -> collectId
            Effect.CRASH -> crashId
            Effect.START -> startId
            Effect.CLICK -> clickId
            Effect.REWARD -> rewardId
        }
        if (loadedSounds.contains(id)) {
            val relativeGain = when (effect) {
                Effect.CLICK -> 0.22f
                Effect.SWITCH -> 0.32f
                Effect.COLLECT -> 0.48f
                Effect.CRASH -> 0.40f
                Effect.START -> 0.30f
                Effect.REWARD -> 0.36f
            }
            val gain = (effectsVolume * relativeGain).coerceIn(0f, 1f)
            try { soundPool.play(id, gain, gain, 1, 0, 1f) } catch (_: Exception) {}
        }
    }

    private fun startMusicIfAllowed() {
        if (released || !hostResumed || !musicEnabled || !musicPrepared) return
        try {
            val player = musicPlayer ?: return
            player.setVolume(musicVolume, musicVolume)
            if (!player.isPlaying) player.start()
        } catch (_: Exception) {
            // Music failure must never prevent the game from opening.
        }
    }

    private fun pauseMusic() {
        try { if (musicPlayer?.isPlaying == true) musicPlayer?.pause() } catch (_: Exception) {}
    }

    fun release() {
        if (released) return
        released = true
        musicPrepared = false
        try { musicPlayer?.stop() } catch (_: Exception) {}
        try { musicPlayer?.release() } catch (_: Exception) {}
        musicPlayer = null
        try { soundPool.release() } catch (_: Exception) {}
        loadedSounds.clear()
    }

    enum class Effect { SWITCH, COLLECT, CRASH, START, CLICK, REWARD }
}
