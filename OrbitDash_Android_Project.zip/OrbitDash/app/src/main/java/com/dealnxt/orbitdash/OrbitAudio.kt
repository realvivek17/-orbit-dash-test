package com.dealnxt.orbitdash

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.media.SoundPool.OnLoadCompleteListener
import java.util.Collections

/** Local-only audio. Missing audio support never blocks or crashes gameplay. */
internal class OrbitAudio(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("orbit_dash_settings", Context.MODE_PRIVATE)
    private var hostResumed = false
    private var released = false
    private var musicPrepared = false
    private var musicPlayer: MediaPlayer? = null
    private val loadedSounds: MutableSet<Int> = Collections.synchronizedSet(HashSet())
    private val soundPool: SoundPool
    private val switchId: Int
    private val collectId: Int
    private val crashId: Int
    private val startId: Int
    private val clickId: Int
    private val rewardId: Int

    val musicEnabled: Boolean
        get() = prefs.getBoolean("music_on", true)
    val effectsEnabled: Boolean
        get() = prefs.getBoolean("effects_on", true)

    // Conservative defaults keep the ambience and taps calm on phone speakers.
    private var currentMusicVolume = prefs.getFloat("music_volume", 0.18f).coerceIn(0f, 1f)
    private var currentEffectsVolume = prefs.getFloat("effects_volume", 0.22f).coerceIn(0f, 1f)

    val musicVolume: Float
        get() = currentMusicVolume

    val effectsVolume: Float
        get() = currentEffectsVolume

    init {
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        soundPool = SoundPool.Builder()
            .setMaxStreams(5)
            .setAudioAttributes(attributes)
            .build()
        soundPool.setOnLoadCompleteListener(OnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) loadedSounds.add(sampleId)
        })
        switchId = soundPool.load(appContext, R.raw.sfx_switch, 1)
        collectId = soundPool.load(appContext, R.raw.sfx_collect, 1)
        crashId = soundPool.load(appContext, R.raw.sfx_crash, 1)
        startId = soundPool.load(appContext, R.raw.sfx_start, 1)
        clickId = soundPool.load(appContext, R.raw.sfx_click, 1)
        rewardId = soundPool.load(appContext, R.raw.sfx_reward, 1)
        // Prepare the bundled 24-second instrumental off the critical startup path.
        // prepareAsync avoids blocking the first home-screen frame while decoding the WAV.
        musicPlayer = createMusicPlayer(attributes)
    }

    private fun createMusicPlayer(attributes: AudioAttributes): MediaPlayer? {
        val player = MediaPlayer()
        return try {
            player.setAudioAttributes(attributes)
            player.setVolume(musicVolume, musicVolume)
            player.setOnPreparedListener { prepared ->
                if (released) {
                    try { prepared.release() } catch (_: Exception) {}
                    if (musicPlayer === prepared) musicPlayer = null
                } else {
                    musicPrepared = true
                    try {
                        prepared.isLooping = true
                        prepared.setVolume(musicVolume, musicVolume)
                    } catch (_: Exception) {}
                    startMusicIfAllowed()
                }
            }
            player.setOnErrorListener { failed, _, _ ->
                musicPrepared = false
                try { failed.release() } catch (_: Exception) {}
                if (musicPlayer === failed) musicPlayer = null
                true
            }
            appContext.resources.openRawResourceFd(R.raw.orbit_ambience).use { descriptor ->
                player.setDataSource(descriptor.fileDescriptor, descriptor.startOffset, descriptor.length)
            }
            player.isLooping = true
            player.prepareAsync()
            player
        } catch (_: Exception) {
            musicPrepared = false
            try { player.release() } catch (_: Exception) {}
            null
        }
    }

    fun onHostResume() {
        hostResumed = true
        startMusicIfAllowed()
    }

    fun onHostPause() {
        hostResumed = false
        try {
            if (musicPlayer?.isPlaying == true) musicPlayer?.pause()
        } catch (_: Exception) {
            // Audio lifecycle is best-effort; gameplay remains independent.
        }
    }

    fun setMusicEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("music_on", enabled).apply()
        if (enabled) startMusicIfAllowed() else pauseMusic()
    }

    fun toggleMusic() = setMusicEnabled(!musicEnabled)

    fun setEffectsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("effects_on", enabled).apply()
    }

    fun toggleEffects() = setEffectsEnabled(!effectsEnabled)

    fun setMusicVolume(volume: Float, persist: Boolean = true) {
        currentMusicVolume = volume.coerceIn(0f, 1f)
        if (persist) prefs.edit().putFloat("music_volume", currentMusicVolume).apply()
        try { musicPlayer?.setVolume(currentMusicVolume, currentMusicVolume) } catch (_: Exception) {}
    }

    fun setEffectsVolume(volume: Float, persist: Boolean = true) {
        currentEffectsVolume = volume.coerceIn(0f, 1f)
        if (persist) prefs.edit().putFloat("effects_volume", currentEffectsVolume).apply()
    }

    // Persist once when a slider is released instead of scheduling a disk write for every move.
    fun persistVolumes() {
        prefs.edit()
            .putFloat("music_volume", currentMusicVolume)
            .putFloat("effects_volume", currentEffectsVolume)
            .apply()
    }

    fun play(effect: Effect) {
        if (released || !effectsEnabled) return
        val id = when (effect) {
            Effect.SWITCH -> switchId
            Effect.COLLECT -> collectId
            Effect.CRASH -> crashId
            Effect.START -> startId
            Effect.CLICK -> clickId
            Effect.REWARD -> rewardId
        }
        if (loadedSounds.contains(id)) {
            // Per-effect gain keeps clicks unobtrusive while collectibles remain readable.
            val relativeGain = when (effect) {
                Effect.CLICK -> 0.30f
                Effect.SWITCH -> 0.38f
                Effect.COLLECT -> 0.55f
                Effect.CRASH -> 0.48f
                Effect.START -> 0.36f
                Effect.REWARD -> 0.42f
            }
            val gain = (effectsVolume * relativeGain).coerceIn(0f, 1f)
            try {
                soundPool.play(id, gain, gain, 1, 0, 1f)
            } catch (_: Exception) {
                // Suppress unsupported audio-device errors.
            }
        }
    }

    private fun startMusicIfAllowed() {
        if (released || !hostResumed || !musicEnabled || !musicPrepared) return
        try {
            val player = musicPlayer ?: return
            player.setVolume(musicVolume, musicVolume)
            if (!player.isPlaying) player.start()
        } catch (_: Exception) {
            // Music failure must never prevent the game from opening.
        }
    }

    private fun pauseMusic() {
        try {
            if (musicPlayer?.isPlaying == true) musicPlayer?.pause()
        } catch (_: Exception) {
            // No-op by design.
        }
    }

    fun release() {
        if (released) return
        released = true
        musicPrepared = false
        try { musicPlayer?.stop() } catch (_: Exception) {}
        try { musicPlayer?.release() } catch (_: Exception) {}
        musicPlayer = null
        try { soundPool.release() } catch (_: Exception) {}
        loadedSounds.clear()
    }

    enum class Effect { SWITCH, COLLECT, CRASH, START, CLICK, REWARD }
}
