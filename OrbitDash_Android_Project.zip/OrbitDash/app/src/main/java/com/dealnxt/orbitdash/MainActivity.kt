package com.dealnxt.orbitdash

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** A native Canvas game. It intentionally avoids WebView/HTML so the installed app
 * does not depend on Android System WebView behaving correctly. */
class MainActivity : Activity() {
    private lateinit var gameView: OrbitDashView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 9, 20)
        window.navigationBarColor = Color.rgb(7, 9, 20)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()
        gameView = OrbitDashView(this)
        setContentView(gameView)
    }

    override fun onResume() {
        super.onResume()
        if (::gameView.isInitialized) gameView.resumeGameLoop()
        hideSystemBars()
    }

    override fun onPause() {
        if (::gameView.isInitialized) gameView.pauseGameLoop()
        super.onPause()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    @Deprecated("Deprecated in Android API; handled for compatibility")
    override fun onBackPressed() {
        if (::gameView.isInitialized && gameView.handleBack()) return
        super.onBackPressed()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }
}

private class OrbitDashView(context: Context) : View(context) {
    private enum class Scene { MENU, PLAYING, OVER }
    private data class Star(val x: Float, val y: Float, val radius: Float, val alpha: Float, val phase: Float, val twinkle: Float)
    private data class Obstacle(val lane: Int, var distance: Float, var spin: Float, val gem: Boolean, var resolved: Boolean = false)
    private data class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val maxLife: Float, val radius: Float, val color: Int)

    private val prefs = context.getSharedPreferences("orbit_dash_settings", Context.MODE_PRIVATE)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif", Typeface.NORMAL) }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f }
    private val rect = RectF()
    private var tone: ToneGenerator? = null

    private var scene = Scene.MENU
    private var screenW = 1f
    private var screenH = 1f
    private var unit = 1f
    private var running = false
    private var lastFrameNs = 0L
    private var elapsed = 0f
    private var backgroundTime = 0f
    private var angle = (-PI / 2.0).toFloat()
    private var speed = 1.22f
    private var lane = 0
    private var score = 0
    private var best = prefs.getInt("best_score", 0).coerceAtLeast(0)
    private var gems = 0
    private var spawnTimer = 0.62f
    private var spawnIndex = 0
    private var lastHazardLane = 1
    private var lastSwitch = 0f
    private var shake = 0f
    private var soundOn = prefs.getBoolean("sound_on", false)
    private var gameOverReason = "ORBIT MISSED"
    private val hazards = mutableListOf<Obstacle>()
    private val particles = mutableListOf<Particle>()
    private var stars = emptyList<Star>()

    init {
        isClickable = true
        isFocusable = true
        setBackgroundColor(Color.rgb(7, 9, 20))
    }

    fun resumeGameLoop() {
        if (!running) {
            running = true
            lastFrameNs = 0L
            postInvalidateOnAnimation()
        }
    }

    fun pauseGameLoop() {
        running = false
        lastFrameNs = 0L
    }

    fun handleBack(): Boolean {
        if (scene == Scene.PLAYING) {
            scene = Scene.MENU
            hazards.clear()
            particles.clear()
            invalidate()
            return true
        }
        return false
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        screenW = max(1, w).toFloat()
        screenH = max(1, h).toFloat()
        unit = (screenW / 390f).coerceIn(0.72f, 3.2f)
        val count = (screenW * screenH / (22000f * unit * unit)).toInt().coerceIn(28, 72)
        stars = List(count) {
            Star(Random.nextFloat() * screenW, Random.nextFloat() * screenH,
                (0.45f + Random.nextFloat() * 1.2f) * unit,
                0.12f + Random.nextFloat() * 0.62f,
                Random.nextFloat() * (2f * PI.toFloat()),
                0.6f + Random.nextFloat() * 1.6f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.nanoTime()
        val dt = if (lastFrameNs == 0L) 0f else ((now - lastFrameNs) / 1_000_000_000f).coerceIn(0f, 0.04f)
        lastFrameNs = now
        if (running) update(dt)
        drawBackground(canvas)
        when (scene) {
            Scene.MENU -> drawMenu(canvas, now / 1_000_000_000f)
            Scene.PLAYING -> drawPlaying(canvas, now / 1_000_000_000f)
            Scene.OVER -> drawGameOver(canvas, now / 1_000_000_000f)
        }
        if (running) postInvalidateOnAnimation()
    }

    private fun update(dt: Float) {
        backgroundTime += dt
        for (p in particles) {
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vx *= 0.94f
            p.vy *= 0.94f
            p.life -= dt
        }
        particles.removeAll { it.life <= 0f }
        lastSwitch = max(0f, lastSwitch - dt)
        shake = max(0f, shake - dt)
        if (scene != Scene.PLAYING) return

        elapsed += dt
        speed = min(2.45f, 1.22f + elapsed * 0.026f)
        angle = (angle + speed * dt) % (2f * PI.toFloat())
        score = floor(elapsed * 8f + gems * 25f).toInt()
        spawnTimer -= dt
        if (spawnTimer <= 0f) {
            spawnObject()
            spawnTimer = max(0.61f, 1.02f - elapsed * 0.004f) + Random.nextFloat() * 0.22f - 0.1f
        }

        for (o in hazards) {
            o.distance -= speed * dt
            o.spin += dt * 2.8f
            if (!o.resolved && o.distance <= 0.11f) {
                o.resolved = true
                if (!o.gem && o.lane == lane) {
                    endGame("HAZARD HIT")
                    break
                }
                if (o.gem && o.lane == lane) {
                    gems++
                    score = floor(elapsed * 8f + gems * 25f).toInt()
                    val (cx, cy, r0, r1) = orbitGeometry()
                    addParticles(cx + cos(angle) * (if (lane == 1) r1 else r0),
                        cy + sin(angle) * (if (lane == 1) r1 else r0), 10, Color.rgb(255, 214, 107), 0.7f)
                    playTone(ToneGenerator.TONE_PROP_ACK, 85)
                }
            }
        }
        hazards.removeAll { it.distance <= -0.32f || (scene == Scene.OVER && it.resolved) }
    }

    private fun spawnObject() {
        spawnIndex++
        val distance = 2.05f + Random.nextFloat() * 0.65f
        if (spawnIndex % 5 == 0 || Random.nextFloat() < 0.13f) {
            hazards.add(Obstacle(if (Random.nextBoolean()) 1 else 0, distance, Random.nextFloat() * 6.28f, true))
        } else {
            lastHazardLane = 1 - lastHazardLane
            hazards.add(Obstacle(lastHazardLane, distance, Random.nextFloat() * 6.28f, false))
        }
    }

    private fun startGame() {
        scene = Scene.PLAYING
        score = 0; gems = 0; elapsed = 0f; lane = 0
        angle = (-PI / 2.0).toFloat(); speed = 1.22f
        spawnTimer = 0.62f; spawnIndex = 0; lastHazardLane = 1
        hazards.clear(); particles.clear(); shake = 0f; lastSwitch = 0f
        playTone(ToneGenerator.TONE_PROP_BEEP, 65)
    }

    private fun endGame(reason: String) {
        if (scene != Scene.PLAYING) return
        scene = Scene.OVER
        gameOverReason = reason
        shake = 0.2f
        if (score > best) {
            best = score
            prefs.edit().putInt("best_score", best).apply()
        }
        val (cx, cy, r0, r1) = orbitGeometry()
        val r = if (lane == 1) r1 else r0
        addParticles(cx + cos(angle) * r, cy + sin(angle) * r, 22, Color.rgb(255, 79, 131), 1.1f)
        playTone(ToneGenerator.TONE_PROP_NACK, 180)
    }

    private fun switchLane() {
        if (scene != Scene.PLAYING) return
        lane = 1 - lane
        lastSwitch = 0.2f
        val (cx, cy, r0, r1) = orbitGeometry()
        val r = if (lane == 1) r1 else r0
        addParticles(cx + cos(angle) * r, cy + sin(angle) * r, 5,
            if (lane == 1) Color.rgb(106, 247, 255) else Color.rgb(171, 117, 255), 0.45f)
        playTone(ToneGenerator.TONE_PROP_BEEP, 55)
    }

    private fun toggleSound() {
        soundOn = !soundOn
        prefs.edit().putBoolean("sound_on", soundOn).apply()
        if (soundOn) playTone(ToneGenerator.TONE_PROP_ACK, 65)
    }

    private fun playTone(toneType: Int, durationMs: Int) {
        if (!soundOn) return
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_MUSIC, 35)
            tone?.startTone(toneType, durationMs)
        } catch (_: Exception) {
            // Audio is optional; gameplay continues if a device doesn't support tones.
        }
    }

    private fun addParticles(x: Float, y: Float, count: Int, color: Int, force: Float) {
        repeat(count) {
            val a = Random.nextFloat() * 2f * PI.toFloat()
            val s = (38f + Random.nextFloat() * 162f) * unit * force
            particles.add(Particle(x, y, cos(a) * s, sin(a) * s,
                0.25f + Random.nextFloat() * 0.4f, 0.65f, (1.5f + Random.nextFloat() * 2f) * unit, color))
        }
    }

    private fun drawBackground(c: Canvas) {
        c.drawColor(Color.rgb(7, 9, 20))
        // Subtle purple/blue halo with solid low-cost translucent circles.
        fillPaint.color = Color.argb(14, 90, 68, 190)
        c.drawCircle(screenW * 0.5f, screenH * 0.49f, max(screenW, screenH) * 0.38f, fillPaint)
        for (s in stars) {
            val flicker = (0.65f + sin(s.phase + backgroundTime * s.twinkle) * 0.35f).coerceIn(0.05f, 1f)
            fillPaint.color = Color.argb((s.alpha * flicker * 255).toInt().coerceIn(0, 255), 174, 202, 255)
            c.drawCircle(s.x, s.y, s.radius, fillPaint)
        }
        for (p in particles) {
            val a = (p.life / p.maxLife).coerceIn(0f, 1f)
            fillPaint.color = Color.argb((a * 210).toInt(), Color.red(p.color), Color.green(p.color), Color.blue(p.color))
            c.drawCircle(p.x, p.y, p.radius, fillPaint)
        }
    }

    private fun drawMenu(c: Canvas, time: Float) {
        drawHeader(c, true)
        val cx = screenW / 2f
        val cy = screenH * 0.395f
        val r = min(screenW * 0.285f, screenH * 0.155f)
        drawRing(c, cx, cy, r * 1.35f, Color.argb(64, 111, 114, 224), 1.0f * unit)
        drawRing(c, cx, cy, r, Color.argb(180, 144, 117, 255), 1.7f * unit)
        drawRing(c, cx, cy, r * 0.68f, Color.argb(155, 95, 230, 255), 1.5f * unit)
        repeat(4) { i ->
            val a = time * 0.65f + i * PI.toFloat() / 2f
            drawGlow(c, cx + cos(a) * r, cy + sin(a) * r, 2.5f * unit, Color.rgb(143, 122, 255))
        }
        drawGlow(c, cx, cy, 9f * unit, Color.rgb(109, 245, 255))
        fillPaint.color = Color.WHITE
        c.drawCircle(cx, cy, 3.8f * unit, fillPaint)
        val orbA = -PI.toFloat() / 2f + time * 0.25f
        drawGlow(c, cx + cos(orbA) * r * 0.68f, cy + sin(orbA) * r * 0.68f, 6f * unit, Color.rgb(114, 247, 255))
        text(c, "JUST ONE MORE", cx, screenH * 0.585f, 10f * unit, Color.rgb(143, 152, 200), true)
        text(c, "Orbit Dash", cx, screenH * 0.625f, (screenW * 0.094f).coerceIn(31f * unit, 42f * unit), Color.rgb(247, 248, 255), true)
        text(c, "Switch orbits. Dodge hazards. Beat your best.", cx, screenH * 0.675f,
            (screenW * 0.032f).coerceIn(11f * unit, 13f * unit), Color.rgb(168, 175, 207), false)
        drawPill(c, cx - 64f * unit, screenH * 0.715f, 128f * unit, 27f * unit,
            "BEST  ${best.toString().padStart(4, '0')}", Color.argb(28, 139, 123, 255), Color.argb(85, 147, 132, 255), Color.rgb(216, 208, 255), 10f * unit)
        drawButton(c, "PLAY NOW", "FREE · OFFLINE · NO WI-FI", screenH * 0.79f)
        text(c, "TAP TO SWITCH BETWEEN TWO ORBITS", cx, screenH * 0.91f, 9f * unit, Color.rgb(117, 127, 168), true)
    }

    private fun drawPlaying(c: Canvas, time: Float) {
        drawHeader(c, false)
        text(c, score.toString().padStart(4, '0'), screenW / 2f, 48f * unit, 25f * unit, Color.rgb(251, 252, 255), true)
        text(c, "SCORE", screenW / 2f, 70f * unit, 8f * unit, Color.rgb(124, 134, 180), true)
        text(c, "✦  $gems", screenW - 26f * unit, 60f * unit, 11f * unit, Color.rgb(255, 214, 107), true, Paint.Align.RIGHT)
        drawOrbitScene(c, time)
        text(c, "TAP TO SWITCH ORBITS", screenW / 2f, screenH * 0.825f, 10f * unit, Color.rgb(213, 217, 244), true)
        text(c, "Avoid pink hazards · Collect gold stars", screenW / 2f, screenH * 0.855f, 10f * unit, Color.rgb(119, 127, 166), false)
        val level = min(5, (elapsed / 12f).toInt())
        repeat(5) { i ->
            fillPaint.color = if (i <= level) Color.rgb(139, 130, 255) else Color.argb(58, 124, 134, 180)
            val x = screenW / 2f - 34f * unit + i * 15f * unit
            c.drawRoundRect(x, screenH * 0.895f, x + 10f * unit, screenH * 0.895f + 3f * unit, 1.5f * unit, 1.5f * unit, fillPaint)
        }
    }

    private fun drawGameOver(c: Canvas, time: Float) {
        drawHeader(c, false)
        drawOrbitScene(c, time)
        fillPaint.color = Color.argb(175, 5, 7, 18)
        c.drawRect(0f, 0f, screenW, screenH, fillPaint)
        val cw = min(screenW - 40f * unit, 340f * unit)
        val ch = 330f * unit
        val x = (screenW - cw) / 2f
        val y = (screenH - ch) / 2f
        rect.set(x, y, x + cw, y + ch)
        fillPaint.color = Color.rgb(18, 22, 49)
        c.drawRoundRect(rect, 28f * unit, 28f * unit, fillPaint)
        strokePaint.color = Color.argb(110, 140, 124, 255)
        strokePaint.strokeWidth = 1.2f * unit
        c.drawRoundRect(rect, 28f * unit, 28f * unit, strokePaint)
        drawGlow(c, screenW / 2f, y + 45f * unit, 4f * unit, Color.rgb(255, 94, 142))
        text(c, "RUN OVER", screenW / 2f, y + 78f * unit, 11f * unit, Color.rgb(255, 135, 170), true)
        text(c, if (gameOverReason == "HAZARD HIT") "Too close!" else "Keep going!", screenW / 2f, y + 116f * unit,
            (screenW * 0.066f).coerceIn(24f * unit, 30f * unit), Color.rgb(250, 250, 255), true)
        text(c, "Every run makes you sharper.", screenW / 2f, y + 147f * unit, 11f * unit, Color.rgb(170, 178, 212), false)
        strokePaint.color = Color.argb(45, 142, 151, 200)
        c.drawLine(x + 28f * unit, y + 174f * unit, x + cw - 28f * unit, y + 174f * unit, strokePaint)
        text(c, "YOUR SCORE", x + cw * 0.31f, y + 204f * unit, 9f * unit, Color.rgb(133, 143, 183), true)
        text(c, score.toString(), x + cw * 0.31f, y + 235f * unit, 27f * unit, Color.WHITE, true)
        text(c, "BEST", x + cw * 0.72f, y + 204f * unit, 9f * unit, Color.rgb(133, 143, 183), true)
        text(c, best.toString(), x + cw * 0.72f, y + 235f * unit, 27f * unit, Color.rgb(203, 191, 255), true)
        drawButton(c, "PLAY AGAIN", "ONE MORE RUN?", y + ch - 72f * unit)
        text(c, "Tap anywhere to restart", screenW / 2f, y + ch + 27f * unit, 10f * unit, Color.rgb(131, 139, 173), false)
    }

    private fun drawHeader(c: Canvas, tagline: Boolean) {
        text(c, "ORBIT", 22f * unit, 31f * unit, 12f * unit, Color.rgb(156, 166, 215), true, Paint.Align.LEFT)
        text(c, "DASH", 68f * unit, 31f * unit, 12f * unit, Color.rgb(246, 247, 255), true, Paint.Align.LEFT)
        if (tagline) text(c, "ONE TAP. TWO ORBITS.", 22f * unit, 51f * unit, 8.5f * unit, Color.rgb(113, 123, 167), true, Paint.Align.LEFT)
        val sx = screenW - 28f * unit
        val sy = 31f * unit
        fillPaint.color = Color.argb(14, 255, 255, 255)
        c.drawCircle(sx, sy, 16f * unit, fillPaint)
        strokePaint.color = Color.argb(45, 177, 185, 255)
        strokePaint.strokeWidth = unit
        c.drawCircle(sx, sy, 16f * unit, strokePaint)
        strokePaint.color = if (soundOn) Color.rgb(205, 214, 255) else Color.rgb(120, 128, 159)
        strokePaint.strokeWidth = 1.6f * unit
        strokePaint.strokeCap = Paint.Cap.ROUND
        strokePaint.strokeJoin = Paint.Join.ROUND
        val p = android.graphics.Path().apply {
            moveTo(sx - 7f * unit, sy - 4f * unit); lineTo(sx - 3f * unit, sy - 4f * unit)
            lineTo(sx + 2f * unit, sy - 8f * unit); lineTo(sx + 2f * unit, sy + 8f * unit)
            lineTo(sx - 3f * unit, sy + 4f * unit); lineTo(sx - 7f * unit, sy + 4f * unit); close()
        }
        c.drawPath(p, strokePaint)
        if (soundOn) c.drawArc(sx - 7f * unit, sy - 7f * unit, sx + 12f * unit, sy + 7f * unit, -55f, 110f, false, strokePaint)
        else c.drawLine(sx + 5f * unit, sy - 4f * unit, sx + 10f * unit, sy + 4f * unit, strokePaint)
    }

    private fun drawOrbitScene(c: Canvas, time: Float) {
        val (cx, cy, r0, r1) = orbitGeometry()
        fillPaint.color = Color.argb(16, 66, 49, 143)
        c.drawCircle(cx, cy, r1 * 1.5f, fillPaint)
        drawRing(c, cx, cy, r1, Color.argb(122, 104, 100, 166), 1.2f * unit)
        drawRing(c, cx, cy, r0, Color.argb(110, 104, 100, 166), 1.2f * unit)
        strokePaint.color = Color.argb(85, 106, 126, 195)
        strokePaint.strokeWidth = unit
        strokePaint.pathEffect = android.graphics.DashPathEffect(floatArrayOf(2f * unit, 11f * unit), 0f)
        c.drawCircle(cx, cy, r1 + 10f * unit, strokePaint)
        strokePaint.pathEffect = null
        repeat(8) { i ->
            val a = time * 0.12f + i * 2f * PI.toFloat() / 8f
            fillPaint.color = Color.argb(165, 126, 132, 218)
            c.drawCircle(cx + cos(a) * (r1 + 10f * unit), cy + sin(a) * (r1 + 10f * unit), 1.3f * unit, fillPaint)
        }
        fillPaint.color = Color.rgb(24, 22, 52)
        c.drawCircle(cx, cy, 22f * unit, fillPaint)
        strokePaint.color = Color.argb(140, 151, 120, 255)
        strokePaint.strokeWidth = 1.1f * unit
        c.drawCircle(cx, cy, 22f * unit, strokePaint)
        strokePaint.color = Color.argb(140, 166, 129, 255)
        strokePaint.strokeWidth = 2.2f * unit
        c.save(); c.rotate(-time * 20f, cx, cy)
        c.drawOval(cx - 10f * unit, cy - 4f * unit, cx + 10f * unit, cy + 4f * unit, strokePaint)
        c.restore()
        for (o in hazards) {
            val r = if (o.lane == 1) r1 else r0
            val a = angle + o.distance
            val x = cx + cos(a) * r
            val y = cy + sin(a) * r
            if (x < -30f * unit || x > screenW + 30f * unit || y < -30f * unit || y > screenH + 30f * unit) continue
            c.save(); c.rotate(o.spin * 57.2958f, x, y)
            if (o.gem) {
                val path = android.graphics.Path().apply {
                    moveTo(x, y - 8f * unit); lineTo(x + 3f * unit, y - 3f * unit); lineTo(x + 8f * unit, y)
                    lineTo(x + 3f * unit, y + 3f * unit); lineTo(x, y + 8f * unit); lineTo(x - 3f * unit, y + 3f * unit)
                    lineTo(x - 8f * unit, y); lineTo(x - 3f * unit, y - 3f * unit); close()
                }
                fillPaint.color = Color.rgb(255, 214, 107)
                c.drawPath(path, fillPaint)
            } else {
                val path = android.graphics.Path().apply {
                    moveTo(x, y - 9f * unit); lineTo(x + 7.5f * unit, y - 2f * unit); lineTo(x + 5.5f * unit, y + 7f * unit)
                    lineTo(x - 5.5f * unit, y + 7f * unit); lineTo(x - 7.5f * unit, y - 2f * unit); close()
                }
                fillPaint.color = Color.rgb(255, 79, 131)
                c.drawPath(path, fillPaint)
                strokePaint.color = Color.rgb(255, 209, 223)
                strokePaint.strokeWidth = unit
                c.drawLine(x, y - 4f * unit, x, y + 2f * unit, strokePaint)
                fillPaint.color = Color.WHITE
                c.drawCircle(x, y + 4f * unit, 0.8f * unit, fillPaint)
            }
            c.restore()
        }
        val pr = if (lane == 1) r1 else r0
        val px = cx + cos(angle) * pr
        val py = cy + sin(angle) * pr
        strokePaint.color = if (lane == 1) Color.argb(115, 101, 246, 255) else Color.argb(115, 176, 129, 255)
        strokePaint.strokeWidth = 3f * unit
        strokePaint.strokeCap = Paint.Cap.ROUND
        c.drawLine(px - cos(angle) * 15f * unit, py - sin(angle) * 15f * unit,
            px - cos(angle) * 4f * unit, py - sin(angle) * 4f * unit, strokePaint)
        drawGlow(c, px, py, 7.2f * unit, if (lane == 1) Color.rgb(105, 244, 255) else Color.rgb(176, 138, 255))
        fillPaint.color = Color.rgb(249, 255, 255)
        c.drawCircle(px, py, 3.2f * unit, fillPaint)
        if (lastSwitch > 0f) {
            strokePaint.color = Color.argb((lastSwitch * 255f * 2.8f).toInt().coerceIn(0, 255), 140, 225, 255)
            strokePaint.strokeWidth = 1.5f * unit
            c.drawCircle(px, py, (12f + (0.2f - lastSwitch) * 38f) * unit, strokePaint)
        }
    }

    private fun orbitGeometry(): OrbitGeometry {
        val base = min(screenW * 0.355f, screenH * 0.245f)
        return OrbitGeometry(screenW / 2f, screenH * 0.515f, base * 0.69f, base)
    }

    private data class OrbitGeometry(val cx: Float, val cy: Float, val r0: Float, val r1: Float)

    private fun drawRing(c: Canvas, cx: Float, cy: Float, radius: Float, color: Int, width: Float) {
        strokePaint.color = color
        strokePaint.strokeWidth = width
        strokePaint.pathEffect = null
        c.drawCircle(cx, cy, radius, strokePaint)
    }

    private fun drawGlow(c: Canvas, x: Float, y: Float, radius: Float, color: Int) {
        val a = Color.alpha(color)
        repeat(3) { i ->
            fillPaint.color = Color.argb((a * (0.10f + i * 0.10f)).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
            c.drawCircle(x, y, radius * (2.4f - i * 0.55f), fillPaint)
        }
        fillPaint.color = color
        c.drawCircle(x, y, radius, fillPaint)
    }

    private fun drawButton(c: Canvas, label: String, subtitle: String, y: Float) {
        val bw = min(screenW - 48f * unit, 310f * unit)
        val bh = 58f * unit
        val x = (screenW - bw) / 2f
        rect.set(x, y, x + bw, y + bh)
        fillPaint.color = Color.rgb(93, 111, 255)
        c.drawRoundRect(rect, 18f * unit, 18f * unit, fillPaint)
        strokePaint.color = Color.argb(64, 255, 255, 255)
        strokePaint.strokeWidth = unit
        c.drawRoundRect(rect, 18f * unit, 18f * unit, strokePaint)
        text(c, label, x + bw / 2f, y + bh / 2f - if (subtitle.isNotEmpty()) 6f * unit else 0f, 15f * unit, Color.WHITE, true)
        if (subtitle.isNotEmpty()) text(c, subtitle, x + bw / 2f, y + bh / 2f + 13f * unit, 9.5f * unit, Color.argb(205, 255, 255, 255), false)
    }

    private fun drawPill(c: Canvas, x: Float, y: Float, w: Float, h: Float, label: String, fill: Int, border: Int, color: Int, size: Float) {
        rect.set(x, y, x + w, y + h)
        fillPaint.color = fill; c.drawRoundRect(rect, h / 2f, h / 2f, fillPaint)
        strokePaint.color = border; strokePaint.strokeWidth = unit; c.drawRoundRect(rect, h / 2f, h / 2f, strokePaint)
        text(c, label, x + w / 2f, y + h / 2f, size, color, true)
    }

    private fun text(c: Canvas, value: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean, align: Paint.Align = Paint.Align.CENTER) {
        textPaint.color = color
        textPaint.textSize = size
        textPaint.textAlign = align
        textPaint.typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        val baseline = y - (textPaint.ascent() + textPaint.descent()) / 2f
        c.drawText(value, x, baseline, textPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val x = event.x
            val y = event.y
            if (x >= screenW - 54f * unit && y <= 58f * unit) {
                toggleSound()
                invalidate()
                performClick()
                return true
            }
            when (scene) {
                Scene.MENU -> startGame()
                Scene.PLAYING -> switchLane()
                Scene.OVER -> startGame()
            }
            invalidate()
            performClick()
            return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onDetachedFromWindow() {
        pauseGameLoop()
        try { tone?.release() } catch (_: Exception) {}
        tone = null
        super.onDetachedFromWindow()
    }
}
