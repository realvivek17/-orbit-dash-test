package com.dealnxt.orbitdash

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var gameView: OrbitDashView
    private lateinit var audio: OrbitAudio

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 9, 20)
        window.navigationBarColor = Color.rgb(7, 9, 20)
        hideSystemBars()
        audio = OrbitAudio(this)
        gameView = OrbitDashView(this, audio)
        setContentView(gameView)
    }

    override fun onResume() {
        super.onResume()
        if (::audio.isInitialized) audio.onHostResume()
        if (::gameView.isInitialized) gameView.resumeGameLoop()
        hideSystemBars()
    }

    override fun onPause() {
        if (::gameView.isInitialized) gameView.pauseForHost()
        if (::audio.isInitialized) audio.onHostPause()
        super.onPause()
    }

    override fun onDestroy() {
        if (::audio.isInitialized) audio.release()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    @Deprecated("Deprecated by Android; kept for compatibility with older API levels")
    override fun onBackPressed() {
        if (::gameView.isInitialized && gameView.handleBack()) return
        super.onBackPressed()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }
}

private class OrbitDashView(context: Context, private val audio: OrbitAudio) : View(context) {
    private enum class Scene { SPLASH, PROFILE_SETUP, HOME, PLAYING, COUNTDOWN, PAUSED, OVER, SETTINGS, SCORES, CUSTOMIZE, MISSIONS, THEMES, ABOUT_US }
    private enum class ButtonAction {
        NONE, NEW_GAME, CONTINUE, OPEN_SCORES, OPEN_CUSTOMIZE, OPEN_MISSIONS, OPEN_SETTINGS, OPEN_THEMES, OPEN_ABOUT, PROFILE_CONTINUE,
        SELECT_THEME_NEBULA, SELECT_THEME_FRONTIER, SELECT_THEME_HEAVENLY,
        TOGGLE_MUSIC, TOGGLE_EFFECTS, MUSIC_PREVIOUS, MUSIC_NEXT, MUSIC_VOLUME_SLIDER, EFFECTS_VOLUME_SLIDER,
        SELECT_EASY, SELECT_NORMAL, SELECT_HARD, GRAPHICS_AUTO, GRAPHICS_LOW, GRAPHICS_HIGH,
        BACK, PAUSE, RESUME, RESTART, HOME, EXIT,
        SHOP_NEBULA, SHOP_ICE, SHOP_SOLAR, SHOP_AURORA, SHOP_STARBURST, SHOP_ECLIPSE,
        CLAIM_STARS, CLAIM_SURVIVE, CLAIM_SCORE
    }
    private enum class ButtonStyle { PRIMARY, SECONDARY, SELECTED, DANGER, DISABLED }
    private enum class Difficulty(val key: String, val title: String, val description: String,
                                  val startSpeed: Float, val maxSpeed: Float, val speedGain: Float,
                                  val scoreRate: Float) {
        EASY("easy", "EASY", "More room to react · slower hazards", 0.88f, 1.55f, 0.0065f, 7f),
        NORMAL("normal", "NORMAL", "Balanced challenge · steady progression", 1.08f, 2.10f, 0.0145f, 8f),
        HARD("hard", "HARD", "Ramps up every 15 seconds", 1.24f, 3.55f, 0.034f, 10f);

        companion object {
            fun fromKey(key: String?): Difficulty = entries.firstOrNull { it.key == key } ?: NORMAL
        }
    }
    private enum class GraphicsQuality(val key: String, val title: String) {
        AUTO("auto", "AUTO"), LOW("low", "LOW"), HIGH("high", "HIGH");
        companion object {
            fun fromKey(key: String?): GraphicsQuality = entries.firstOrNull { it.key == key } ?: AUTO
        }
    }
    private enum class WorldTheme(val key: String, val title: String, val lineOne: String, val lineTwo: String,
                                  val asset: String, val accent: Int) {
        COSMIC_NEBULA("cosmic_nebula", "COSMIC NEBULA", "Galaxies, planets", "and shining stars.", "themes/cosmic_nebula.jpg", Color.rgb(158, 115, 255)),
        CELESTIAL_FRONTIER("celestial_frontier", "CELESTIAL FRONTIER", "Sunset clouds, floating", "islands and ringed worlds.", "themes/celestial_frontier.jpg", Color.rgb(255, 177, 100)),
        HEAVENLY_REALMS("heavenly_realms", "HEAVENLY REALMS", "Golden skies, temples", "and luminous waterfalls.", "themes/heavenly_realms.jpg", Color.rgb(94, 224, 255));

        companion object {
            fun fromKey(key: String?): WorldTheme = entries.firstOrNull { it.key == key } ?: COSMIC_NEBULA
        }
    }
    private data class Star(val x: Float, val y: Float, val radius: Float, val alpha: Float, val phase: Float, val twinkle: Float)
    private data class Obstacle(val lane: Int, var distance: Float, var spin: Float, val gem: Boolean, var resolved: Boolean = false)
    private data class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val maxLife: Float, val radius: Float, val color: Int)
    private class HitTarget {
        val bounds = RectF()
        var action: ButtonAction = ButtonAction.NONE
    }
    private data class Skin(
        val id: String,
        val title: String,
        val color: Int,
        val requiredPoints: Int,
        val description: String
    )

    private val prefs = context.getSharedPreferences("orbit_dash_settings", Context.MODE_PRIVATE)
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bitmapOverlayPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val themeClipPath = Path()
    private val screenRect = RectF()
    private val themeBackgrounds: Array<Bitmap?> = arrayOfNulls(WorldTheme.entries.size)
    private var themeBackgroundLoadingStarted = false
    private var selectedTheme = WorldTheme.fromKey(prefs.getString("selected_theme", WorldTheme.COSMIC_NEBULA.key))
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f }
    private val regularTypeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val boldTypeface = Typeface.create("sans-serif", Typeface.BOLD)
    private val rect = RectF()
    private val panelRect = RectF()
    private val hazardPath = Path().apply {
        moveTo(0f, -9f); lineTo(7.5f, -2f); lineTo(5.5f, 7f); lineTo(-5.5f, 7f); lineTo(-7.5f, -2f); close()
    }
    private val gemPath = Path().apply {
        moveTo(0f, -8f); lineTo(3f, -3f); lineTo(8f, 0f); lineTo(3f, 3f)
        lineTo(0f, 8f); lineTo(-3f, 3f); lineTo(-8f, 0f); lineTo(-3f, -3f); close()
    }
    // Nebula stays free. The five shop items unlock cosmetic looks/effects only.
    private val shipSkins = listOf(
        Skin("nebula", "NEBULA", Color.rgb(174, 135, 255), 0, "Your original violet ship glow"),
        Skin("ice_comet", "ICE COMET", Color.rgb(86, 235, 255), 3_000, "Cool cyan glow and comet trail"),
        Skin("solar_flare", "SOLAR FLARE", Color.rgb(255, 190, 91), 5_000, "Warm golden solar glow"),
        Skin("aurora_trail", "AURORA TRAIL", Color.rgb(108, 255, 204), 8_000, "Mint-green extended trail"),
        Skin("starburst", "STARBURST", Color.rgb(255, 133, 210), 12_000, "Rose-pink collection burst"),
        Skin("eclipse", "ECLIPSE", Color.rgb(191, 171, 255), 18_000, "Premium violet-white glow")
    )
    // Cached, immutable tables avoid allocating arrays inside the per-frame game loop.
    private val hardSpeedMilestones = arrayOf(
        0f to 1.24f, 15f to 1.43f, 30f to 1.83f, 45f to 2.42f,
        60f to 3.08f, 90f to 3.40f, 120f to 3.55f
    )
    private val hardSpawnMilestones = arrayOf(
        0f to 0.98f, 15f to 0.90f, 30f to 0.80f, 45f to 0.67f,
        60f to 0.55f, 90f to 0.49f, 120f to 0.46f
    )
    private val homeDifficultyOptions = arrayOf(Difficulty.EASY, Difficulty.NORMAL, Difficulty.HARD)
    private val homeDifficultyActions = arrayOf(ButtonAction.SELECT_EASY, ButtonAction.SELECT_NORMAL, ButtonAction.SELECT_HARD)
    private val themeSelectActions = arrayOf(ButtonAction.SELECT_THEME_NEBULA, ButtonAction.SELECT_THEME_FRONTIER, ButtonAction.SELECT_THEME_HEAVENLY)
    private val shopPurchaseActions = arrayOf(
        ButtonAction.SHOP_NEBULA, ButtonAction.SHOP_ICE, ButtonAction.SHOP_SOLAR,
        ButtonAction.SHOP_AURORA, ButtonAction.SHOP_STARBURST, ButtonAction.SHOP_ECLIPSE
    )
    private val hitTargets = ArrayList<HitTarget>(24)
    private var hitTargetCount = 0
    private var scoreHistory: List<Int> = readScoreHistory()
    private var savedRunAvailable = prefs.getBoolean("run_saved", false)
    private val hazards = ArrayList<Obstacle>(12)
    private val particles = ArrayList<Particle>(100)
    private var stars: List<Star> = emptyList()

    private var scene = Scene.SPLASH
    private var splashElapsed = 0f
    private var profilePromptShown = false
    private var playerName = prefs.getString("player_name", "").orEmpty()
    private var playerAge = prefs.getInt("player_age", 0).coerceIn(0, 120)
    private var homeFadeElapsed = 0.35f
    private val homeFadeDuration = 0.35f
    private var screenW = 1f
    private var screenH = 1f
    private var unit = 1f
    private var running = false
    private var lastFrameNs = 0L
    private var elapsed = 0f
    private var backgroundTime = 0f
    private var angle = (-PI / 2.0).toFloat()
    private var speed = Difficulty.NORMAL.startSpeed
    private var lane = 0
    private var score = 0
    private var best = prefs.getInt("best_score", 0).coerceAtLeast(0)
    private var lastScore = prefs.getInt("last_score", 0).coerceAtLeast(0)
    private var totalRuns = prefs.getInt("total_runs", 0).coerceAtLeast(0)
    private var gems = 0
    private var spawnTimer = 0.95f
    private var spawnIndex = 0
    private var lastHazardLane = 1
    private var lastSwitch = 0f
    private var gameOverReason = "HAZARD HIT"
    private var isNewBestRun = false
    private var resumeCountdown = 0f
    private var dailyStars = 0
    private var dailySurvival = 0
    private var dailyScore = 0
    private var dailyClaimedStars = false
    private var dailyClaimedSurvive = false
    private var dailyClaimedScore = false
    private var lastDailyDateCheckAt = 0f
    private var selectedSkinIndex = prefs.getInt("selected_skin", 0).coerceIn(0, shipSkins.lastIndex)
    private var starPoints = loadOrMigrateStarPoints()
    private var formattedStarPoints = formatPoints(starPoints)
    private var ownedItemIds: Set<String> = loadOwnedItems()
    private var activeVolumeSlider: ButtonAction? = null
    private var difficulty = Difficulty.fromKey(prefs.getString("difficulty", "normal"))
    private var graphicsQuality = GraphicsQuality.fromKey(prefs.getString("graphics_quality", "auto"))
    private val autoGraphicsLevel: Int by lazy {
        try {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val info = ActivityManager.MemoryInfo()
            manager?.getMemoryInfo(info)
            if ((info.totalMem >= 4L * 1024L * 1024L * 1024L) && Runtime.getRuntime().availableProcessors() >= 6) 2 else 1
        } catch (_: Exception) { 1 }
    }

    init {
        // Never display a selected cosmetic that is not owned after a partial/legacy save migration.
        if (shipSkins[selectedSkinIndex].id !in ownedItemIds) {
            selectedSkinIndex = 0
            prefs.edit().putInt("selected_skin", 0).apply()
        }
        isClickable = true
        isFocusable = true
        contentDescription = "Orbit Dash arcade game"
        setBackgroundColor(Color.rgb(7, 9, 20))
        ensureDailyMissionsCurrent()
    }

    private fun loadThemeBackground(assetPath: String): Bitmap? = try {
        // JPEG backgrounds have no alpha channel. RGB_565 halves decoded memory use; do this off the UI thread.
        val options = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.RGB_565
            inDither = true
        }
        context.assets.open(assetPath).use { BitmapFactory.decodeStream(it, null, options) }
    } catch (_: Exception) {
        null // The game remains playable with the procedural fallback if an artwork file is missing.
    }

    private fun ensureThemeBackgroundsLoaded() {
        if (themeBackgroundLoadingStarted) return
        themeBackgroundLoadingStarted = true
        Thread({
            val decoded = WorldTheme.entries.map { loadThemeBackground(it.asset) }
            post {
                decoded.forEachIndexed { index, bitmap -> themeBackgrounds[index] = bitmap }
                rebuildStarfield()
                invalidate()
            }
        }, "OrbitDash-ThemeLoader").start()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    /** First-run onboarding is local-only. Name and age never leave this device. */
    private fun showProfileSetupDialog() {
        val activity = context as? Activity ?: return
        if (profilePromptShown || prefs.getBoolean("profile_complete", false)) return
        profilePromptShown = true

        val form = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(4))
        }
        val nameLabel = TextView(context).apply {
            text = "What should we call you?"
            textSize = 14f
            setTextColor(Color.rgb(206, 217, 255))
        }
        val nameInput = EditText(context).apply {
            hint = "Enter your name"
            textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setSingleLine(true)
            setText(playerName)
        }
        val ageLabel = TextView(context).apply {
            text = "How old are you?"
            textSize = 14f
            setTextColor(Color.rgb(206, 217, 255))
        }
        val ageInput = EditText(context).apply {
            hint = "Enter your age"
            textSize = 16f
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            if (playerAge > 0) setText(playerAge.toString())
        }
        form.addView(nameLabel, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        form.addView(nameInput, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        val gap = TextView(context).apply { text = " "; textSize = 5f }
        form.addView(gap, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8)))
        form.addView(ageLabel, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        form.addView(ageInput, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val dialog = AlertDialog.Builder(activity)
            .setTitle("Welcome to Orbit Dash")
            .setMessage("Create your pilot profile. Your details are saved only on this phone.")
            .setView(form)
            .setCancelable(false)
            .setPositiveButton("SAVE & START", null)
            .create()
        dialog.setCanceledOnTouchOutside(false)
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = nameInput.text.toString().trim().replace(Regex("\\s+"), " ").take(30)
                val age = ageInput.text.toString().trim().toIntOrNull()
                if (name.length < 2) {
                    Toast.makeText(activity, "Please enter a name with at least 2 characters.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (age == null || age !in 1..120) {
                    Toast.makeText(activity, "Please enter a valid age from 1 to 120.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                playerName = name
                playerAge = age
                prefs.edit().putString("player_name", name).putInt("player_age", age)
                    .putBoolean("profile_complete", true).apply()
                scene = Scene.HOME
                homeFadeElapsed = 0f
                profilePromptShown = false
                dialog.dismiss()
                invalidate()
            }
        }
        dialog.show()
    }

    fun resumeGameLoop() {
        if (!running) {
            running = true
            lastFrameNs = 0L
            postInvalidateOnAnimation()
        }
    }

    fun pauseForHost() {
        if (scene == Scene.PLAYING || scene == Scene.COUNTDOWN) {
            saveCurrentRun()
            scene = Scene.PAUSED
        }
        running = false
        lastFrameNs = 0L
    }

    fun handleBack(): Boolean {
        when (scene) {
            Scene.SPLASH -> scene = if (prefs.getBoolean("profile_complete", false)) Scene.HOME else Scene.PROFILE_SETUP
            Scene.PROFILE_SETUP -> { post { showProfileSetupDialog() }; return true }
            Scene.PLAYING, Scene.COUNTDOWN -> {
                saveCurrentRun()
                scene = Scene.PAUSED
                audio.play(OrbitAudio.Effect.CLICK)
            }
            Scene.PAUSED -> {
                saveCurrentRun()
                scene = Scene.HOME
            }
            Scene.OVER -> scene = Scene.HOME
            Scene.SETTINGS, Scene.SCORES, Scene.CUSTOMIZE, Scene.MISSIONS, Scene.THEMES, Scene.ABOUT_US -> scene = Scene.HOME
            Scene.HOME -> return false
        }
        invalidate()
        return true
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        screenW = max(1, w).toFloat()
        screenH = max(1, h).toFloat()
        screenRect.set(0f, 0f, screenW, screenH)
        // Scale to both width and height so six shop rows/settings never crowd shorter phones.
        unit = min(screenW / 390f, screenH / 760f).coerceIn(0.72f, 3.2f)
        rebuildStarfield()
        ensureThemeBackgroundsLoaded()
    }

    private fun rebuildStarfield() {
        val factor = when (effectiveGraphicsLevel()) { 0 -> 0.42f; 1 -> 0.72f; else -> 1f }
        val count = (screenW * screenH / (22000f * unit * unit) * factor).toInt().coerceIn(18, 88)
        stars = List(count) {
            Star(Random.nextFloat() * screenW, Random.nextFloat() * screenH,
                (0.45f + Random.nextFloat() * 1.2f) * unit,
                0.12f + Random.nextFloat() * 0.58f,
                Random.nextFloat() * (2f * PI.toFloat()), 0.6f + Random.nextFloat() * 1.6f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        hitTargetCount = 0
        val now = System.nanoTime()
        val dt = if (lastFrameNs == 0L) 0f else ((now - lastFrameNs) / 1_000_000_000f).coerceIn(0f, 0.033f)
        lastFrameNs = now
        if (running) update(dt)
        val shouldKeepScreenOn = scene == Scene.PLAYING || scene == Scene.COUNTDOWN
        if (keepScreenOn != shouldKeepScreenOn) keepScreenOn = shouldKeepScreenOn
        drawBackground(canvas)
        val time = now / 1_000_000_000f
        when (scene) {
            Scene.SPLASH -> drawSplash(canvas, time)
            Scene.PROFILE_SETUP -> drawProfileSetup(canvas)
            Scene.HOME -> drawHome(canvas, time)
            Scene.PLAYING -> drawPlaying(canvas, time, true)
            Scene.COUNTDOWN -> drawCountdown(canvas, time)
            Scene.PAUSED -> drawPaused(canvas, time)
            Scene.OVER -> drawGameOver(canvas, time)
            Scene.SETTINGS -> drawSettings(canvas)
            Scene.SCORES -> drawScores(canvas)
            Scene.CUSTOMIZE -> drawCustomize(canvas)
            Scene.MISSIONS -> drawMissions(canvas)
            Scene.THEMES -> drawThemes(canvas, time)
            Scene.ABOUT_US -> drawAboutUs(canvas, time)
        }
        if (scene == Scene.HOME && homeFadeElapsed < homeFadeDuration) {
            val alpha = (((homeFadeDuration - homeFadeElapsed) / homeFadeDuration) * 178f).toInt().coerceIn(0, 178)
            fillPaint.color = Color.argb(alpha, 3, 5, 16)
            canvas.drawRect(0f, 0f, screenW, screenH, fillPaint)
        }
        if (running) postInvalidateOnAnimation()
    }

    private fun update(dt: Float) {
        if (dt <= 0f) return
        backgroundTime += dt
        if (scene == Scene.SPLASH) {
            // Initialisation has already completed; this is a short animated intro, not a fake loading wait.
            splashElapsed = (splashElapsed + dt).coerceAtMost(4.9f)
            if (splashElapsed >= 4.9f) {
                if (prefs.getBoolean("profile_complete", false)) {
                    scene = Scene.HOME
                    homeFadeElapsed = 0f
                } else {
                    scene = Scene.PROFILE_SETUP
                    post { showProfileSetupDialog() }
                }
            }
            return
        }
        if (scene == Scene.HOME && homeFadeElapsed < homeFadeDuration) {
            homeFadeElapsed = (homeFadeElapsed + dt).coerceAtMost(homeFadeDuration)
        }
        var pi = particles.size - 1
        while (pi >= 0) {
            val p = particles[pi]
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vx *= 0.94f
            p.vy *= 0.94f
            p.life -= dt
            if (p.life <= 0f) particles.removeAt(pi)
            pi--
        }
        lastSwitch = max(0f, lastSwitch - dt)
        if (scene == Scene.COUNTDOWN) {
            resumeCountdown -= dt
            if (resumeCountdown <= 0f) {
                scene = Scene.PLAYING
                resumeCountdown = 0f
                clearRunSave()
            }
            return
        }
        if (scene != Scene.PLAYING) return

        elapsed += dt
        speed = speedAtElapsed(elapsed)
        angle = (angle + speed * dt) % (2f * PI.toFloat())
        score = floor(elapsed * difficulty.scoreRate + gems * 25f).toInt()
        if (elapsed - lastDailyDateCheckAt >= 10f) {
            ensureDailyMissionsCurrent()
            lastDailyDateCheckAt = elapsed
        }
        updateDailyProgress()
        spawnTimer -= dt
        if (spawnTimer <= 0f) {
            spawnObject()
            spawnTimer = nextSpawnInterval()
        }

        var i = hazards.size - 1
        while (i >= 0) {
            val o = hazards[i]
            o.distance -= speed * dt
            o.spin += dt * 2.8f
            if (!o.resolved && o.distance <= 0.11f) {
                o.resolved = true
                if (!o.gem && o.lane == lane) {
                    endGame("HAZARD HIT")
                    break
                } else if (o.gem && o.lane == lane) {
                    gems++
                    val pointsEarned = pointsPerCollectedStar()
                    starPoints = (starPoints.toLong() + pointsEarned.toLong())
                        .coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                    formattedStarPoints = formatPoints(starPoints)
                    dailyStars++
                    score = floor(elapsed * difficulty.scoreRate + gems * 25f).toInt()
                    prefs.edit().putInt("star_points", starPoints).putInt("daily_stars", dailyStars).apply()
                    val geo = orbitGeometry()
                    val r = if (lane == 1) geo.outer else geo.inner
                    addParticles(geo.cx + cos(angle) * r, geo.cy + sin(angle) * r, 12, collectionEffectColor(), 0.8f)
                    audio.play(OrbitAudio.Effect.COLLECT)
                }
            }
            if (o.distance <= -0.32f || (scene == Scene.OVER && o.resolved)) hazards.removeAt(i)
            i--
        }
    }

    private fun spawnObject() {
        spawnIndex++
        val distance = 2.05f + Random.nextFloat() * 0.55f
        if (spawnIndex % 5 == 0 || Random.nextFloat() < 0.14f) {
            hazards.add(Obstacle(if (Random.nextBoolean()) 1 else 0, distance, Random.nextFloat() * 6.28f, true))
        } else {
            lastHazardLane = 1 - lastHazardLane
            hazards.add(Obstacle(lastHazardLane, distance, Random.nextFloat() * 6.28f, false))
        }
    }

    private fun startNewGame() {
        difficulty = Difficulty.fromKey(prefs.getString("difficulty", difficulty.key))
        elapsed = 0f
        angle = (-PI / 2.0).toFloat()
        speed = difficulty.startSpeed
        lane = 0
        score = 0
        gems = 0
        spawnTimer = initialSpawnInterval()
        spawnIndex = 0
        lastHazardLane = 1
        lastSwitch = 0f
        hazards.clear()
        particles.clear()
        clearRunSave()
        scene = Scene.PLAYING
        isNewBestRun = false
        audio.play(OrbitAudio.Effect.START)
    }

    private fun startResumeCountdown() {
        scene = Scene.COUNTDOWN
        resumeCountdown = 3f
        // Keep the snapshot until the countdown finishes so a kill during resume can recover it.
        audio.play(OrbitAudio.Effect.START)
    }

    private fun endGame(reason: String) {
        if (scene != Scene.PLAYING) return
        scene = Scene.OVER
        gameOverReason = reason
        lastScore = score.coerceAtLeast(0)
        totalRuns++
        isNewBestRun = score > best
        if (isNewBestRun) best = score
        val history = scoreHistory.toMutableList()
        history.add(score.coerceAtLeast(0))
        val top = history.sortedDescending().take(5)
        scoreHistory = top
        prefs.edit()
            .putInt("best_score", best)
            .putInt("last_score", lastScore)
            .putInt("total_runs", totalRuns)
            .putString("top_scores", top.joinToString(","))
            .apply()
        clearRunSave()
        val geo = orbitGeometry()
        val r = if (lane == 1) geo.outer else geo.inner
        addParticles(geo.cx + cos(angle) * r, geo.cy + sin(angle) * r, 24, PINK, 1f)
        audio.play(OrbitAudio.Effect.CRASH)
    }

    private fun switchLane() {
        if (scene != Scene.PLAYING) return
        lane = 1 - lane
        lastSwitch = 0.22f
        val geo = orbitGeometry()
        val r = if (lane == 1) geo.outer else geo.inner
        addParticles(geo.cx + cos(angle) * r, geo.cy + sin(angle) * r, 6, shipColor(), 0.42f)
        audio.play(OrbitAudio.Effect.SWITCH)
    }

    private fun saveCurrentRun() {
        if (elapsed <= 0f || (scene != Scene.PLAYING && scene != Scene.COUNTDOWN && scene != Scene.PAUSED)) return
        val packedHazards = hazards.joinToString(";") {
            "${it.lane},${it.distance},${it.spin},${it.gem},${it.resolved}"
        }
        savedRunAvailable = true
        prefs.edit()
            .putBoolean("run_saved", true)
            .putFloat("run_elapsed", elapsed)
            .putFloat("run_angle", angle)
            .putFloat("run_speed", speed)
            .putInt("run_lane", lane)
            .putInt("run_score", score)
            .putInt("run_gems", gems)
            .putFloat("run_spawn_timer", spawnTimer)
            .putInt("run_spawn_index", spawnIndex)
            .putInt("run_last_hazard_lane", lastHazardLane)
            .putString("run_difficulty", difficulty.key)
            .putString("run_hazards", packedHazards)
            .apply()
    }

    private fun restoreSavedRun(): Boolean {
        if (!prefs.getBoolean("run_saved", false)) return false
        elapsed = prefs.getFloat("run_elapsed", 0f).coerceAtLeast(0f)
        angle = prefs.getFloat("run_angle", (-PI / 2.0).toFloat())
        speed = prefs.getFloat("run_speed", difficulty.startSpeed).coerceAtLeast(0f)
        lane = prefs.getInt("run_lane", 0).coerceIn(0, 1)
        score = prefs.getInt("run_score", 0).coerceAtLeast(0)
        gems = prefs.getInt("run_gems", 0).coerceAtLeast(0)
        spawnTimer = prefs.getFloat("run_spawn_timer", 0.7f).coerceAtLeast(0.05f)
        spawnIndex = prefs.getInt("run_spawn_index", 0).coerceAtLeast(0)
        lastHazardLane = prefs.getInt("run_last_hazard_lane", 1).coerceIn(0, 1)
        difficulty = Difficulty.fromKey(prefs.getString("run_difficulty", difficulty.key))
        hazards.clear()
        val packed = prefs.getString("run_hazards", "").orEmpty()
        if (packed.isNotBlank()) {
            for (row in packed.split(';')) {
                val parts = row.split(',')
                if (parts.size == 5) {
                    try {
                        hazards.add(Obstacle(parts[0].toInt().coerceIn(0, 1), parts[1].toFloat(), parts[2].toFloat(), parts[3].toBoolean(), parts[4].toBoolean()))
                    } catch (_: Exception) {
                        // Ignore a malformed individual obstacle rather than losing the whole saved run.
                    }
                }
            }
        }
        particles.clear()
        return true
    }

    private fun clearRunSave() {
        savedRunAvailable = false
        prefs.edit().putBoolean("run_saved", false).remove("run_hazards").apply()
    }

    private fun updateDailyProgress() {
        var changed = false
        val alive = elapsed.toInt()
        if (alive > dailySurvival) { dailySurvival = alive; changed = true }
        if (score > dailyScore) { dailyScore = score; changed = true }
        if (changed) prefs.edit().putInt("daily_survival", dailySurvival).putInt("daily_score", dailyScore).apply()
    }

    private fun ensureDailyMissionsCurrent() {
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        if (prefs.getString("daily_date", "") != today) {
            prefs.edit()
                .putString("daily_date", today)
                .putInt("daily_stars", 0)
                .putInt("daily_survival", 0)
                .putInt("daily_score", 0)
                .putBoolean("daily_claim_stars", false)
                .putBoolean("daily_claim_survive", false)
                .putBoolean("daily_claim_score", false)
                .apply()
        }
        dailyStars = prefs.getInt("daily_stars", 0).coerceAtLeast(0)
        dailySurvival = prefs.getInt("daily_survival", 0).coerceAtLeast(0)
        dailyScore = prefs.getInt("daily_score", 0).coerceAtLeast(0)
        dailyClaimedStars = prefs.getBoolean("daily_claim_stars", false)
        dailyClaimedSurvive = prefs.getBoolean("daily_claim_survive", false)
        dailyClaimedScore = prefs.getBoolean("daily_claim_score", false)
    }

    private fun claimMission(which: Int) {
        ensureDailyMissionsCurrent()
        val complete = when (which) { 0 -> dailyStars >= 10; 1 -> dailySurvival >= 45; else -> dailyScore >= 400 }
        val claimed = when (which) { 0 -> dailyClaimedStars; 1 -> dailyClaimedSurvive; else -> dailyClaimedScore }
        if (!complete || claimed) return
        // Mission rewards use the same Star Points currency as collectible stars.
        val reward = when (which) { 0 -> 300; 1 -> 500; else -> 400 }
        starPoints = (starPoints.toLong() + reward.toLong()).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        formattedStarPoints = formatPoints(starPoints)
        when (which) {
            0 -> dailyClaimedStars = true
            1 -> dailyClaimedSurvive = true
            else -> dailyClaimedScore = true
        }
        prefs.edit()
            .putInt("star_points", starPoints)
            .putBoolean("daily_claim_stars", dailyClaimedStars)
            .putBoolean("daily_claim_survive", dailyClaimedSurvive)
            .putBoolean("daily_claim_score", dailyClaimedScore)
            .apply()
        audio.play(OrbitAudio.Effect.REWARD)
    }

    private fun readScoreHistory(): List<Int> = prefs.getString("top_scores", "").orEmpty()
        .split(',').mapNotNull { it.toIntOrNull() }.filter { it >= 0 }.sortedDescending().take(5)

    private fun effectiveGraphicsLevel(): Int = when (graphicsQuality) {
        GraphicsQuality.LOW -> 0
        GraphicsQuality.AUTO -> autoGraphicsLevel
        GraphicsQuality.HIGH -> 2
    }

    private fun setGraphicsQuality(value: GraphicsQuality) {
        graphicsQuality = value
        prefs.edit().putString("graphics_quality", value.key).apply()
        rebuildStarfield()
    }

    private fun selectDifficulty(value: Difficulty) {
        difficulty = value
        prefs.edit().putString("difficulty", value.key).apply()
        scene = Scene.HOME
    }

    private fun setTheme(value: WorldTheme) {
        selectedTheme = value
        prefs.edit().putString("selected_theme", value.key).apply()
        // Theme choice changes only presentation; orbit positions, hitboxes and object logic stay unchanged.
    }

    private fun shipColor(): Int = shipSkins[selectedSkinIndex].color

    private fun shipTrailColor(): Int = when (selectedSkinIndex) {
        3 -> Color.rgb(108, 255, 204)
        4 -> Color.rgb(255, 133, 210)
        5 -> Color.rgb(210, 202, 255)
        else -> shipColor()
    }

    private fun collectionEffectColor(): Int = when (selectedSkinIndex) {
        4 -> Color.rgb(255, 133, 210)
        5 -> Color.rgb(190, 166, 255)
        else -> GOLD
    }

    private fun purchaseOrEquipSkin(index: Int) {
        if (index !in shipSkins.indices) return
        val skin = shipSkins[index]
        if (skin.id !in ownedItemIds) {
            if (skin.requiredPoints <= 0 || starPoints < skin.requiredPoints) return
            starPoints -= skin.requiredPoints
            formattedStarPoints = formatPoints(starPoints)
            ownedItemIds = ownedItemIds + skin.id
            prefs.edit()
                .putInt("star_points", starPoints)
                .putStringSet("owned_items", ownedItemIds.toSet())
                .apply()
        }
        selectedSkinIndex = index
        prefs.edit().putInt("selected_skin", index).apply()
        audio.play(OrbitAudio.Effect.REWARD)
    }

    private fun loadOrMigrateStarPoints(): Int {
        val current = prefs.getInt("star_points", -1)
        if (current >= 0) return current
        // Existing builds stored collected stars and mission currency as one count.
        // Convert once at the Normal-mode rate so existing balances keep fair value.
        val legacyStars = prefs.getInt("banked_stars", 0).coerceAtLeast(0)
        val migrated = (legacyStars.toLong() * 50L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        prefs.edit().putInt("star_points", migrated).apply()
        return migrated
    }

    private fun loadOwnedItems(): Set<String> {
        val saved = prefs.getStringSet("owned_items", null)
        if (saved != null) return saved.toSet() + "nebula"
        val legacyStars = prefs.getInt("banked_stars", 0).coerceAtLeast(0)
        val legacySelected = prefs.getInt("selected_skin", 0)
        val migrated = mutableSetOf("nebula")
        if (legacyStars >= 100 || legacySelected >= 1) migrated.add("ice_comet")
        if (legacyStars >= 250 || legacySelected >= 2) migrated.add("solar_flare")
        prefs.edit().putStringSet("owned_items", migrated.toSet()).apply()
        return migrated
    }

    private fun pointsPerCollectedStar(): Int = when (difficulty) {
        Difficulty.EASY -> 30
        Difficulty.NORMAL -> 50
        Difficulty.HARD -> 100
    }

    private fun formatPoints(value: Int): String {
        val digits = value.coerceAtLeast(0).toString()
        val firstGroup = digits.length % 3
        if (firstGroup == 0 && digits.length <= 3) return digits
        return buildString(digits.length + digits.length / 3) {
            if (firstGroup > 0) {
                append(digits, 0, firstGroup)
                if (firstGroup < digits.length) append(',')
            }
            var index = firstGroup
            while (index < digits.length) {
                append(digits, index, index + 3)
                index += 3
                if (index < digits.length) append(',')
            }
        }
    }

    private fun speedAtElapsed(seconds: Float): Float {
        return when (difficulty) {
            Difficulty.EASY -> min(difficulty.maxSpeed, difficulty.startSpeed + seconds * difficulty.speedGain)
            Difficulty.NORMAL -> min(difficulty.maxSpeed, difficulty.startSpeed + seconds * difficulty.speedGain)
            Difficulty.HARD -> interpolateMilestones(seconds, hardSpeedMilestones)
        }
    }

    private fun nextSpawnInterval(): Float {
        val base = when (difficulty) {
            Difficulty.EASY -> max(0.95f, 1.30f - elapsed * 0.0035f)
            Difficulty.NORMAL -> max(0.62f, 1.10f - elapsed * 0.0042f)
            Difficulty.HARD -> interpolateMilestones(elapsed, hardSpawnMilestones)
        }
        return (base + Random.nextFloat() * 0.08f - 0.025f).coerceIn(0.43f, 1.38f)
    }

    private fun initialSpawnInterval(): Float = when (difficulty) {
        Difficulty.EASY -> 1.30f
        Difficulty.NORMAL -> 1.10f
        Difficulty.HARD -> 0.98f
    }

    private fun interpolateMilestones(seconds: Float, points: Array<Pair<Float, Float>>): Float {
        if (points.isEmpty()) return 1f
        if (seconds <= points.first().first) return points.first().second
        for (index in 0 until points.lastIndex) {
            val (startTime, startValue) = points[index]
            val (endTime, endValue) = points[index + 1]
            if (seconds <= endTime) {
                val t = ((seconds - startTime) / (endTime - startTime)).coerceIn(0f, 1f)
                // Smoothstep prevents a sudden jump at 15/30/45/60-second milestones.
                val eased = t * t * (3f - 2f * t)
                return startValue + (endValue - startValue) * eased
            }
        }
        return points.last().second
    }

    private fun addParticles(x: Float, y: Float, count: Int, color: Int, force: Float) {
        val maxParticles = when (effectiveGraphicsLevel()) { 0 -> 48; 1 -> 88; else -> 132 }
        val actualCount = when (effectiveGraphicsLevel()) { 0 -> max(3, count / 2); else -> count }
        repeat(actualCount) {
            if (particles.size >= maxParticles) particles.removeAt(0)
            val a = Random.nextFloat() * 2f * PI.toFloat()
            val s = (38f + Random.nextFloat() * 162f) * unit * force
            particles.add(Particle(x, y, cos(a) * s, sin(a) * s,
                0.25f + Random.nextFloat() * 0.4f, 0.65f, (1.5f + Random.nextFloat() * 2f) * unit, color))
        }
    }

    // ----- Drawing: reusable paints/paths and pooled hit targets keep per-frame allocation low. -----

    private fun drawBackground(c: Canvas) {
        c.drawColor(BG)
        val themeIndex = if (scene == Scene.SPLASH) 0 else selectedTheme.ordinal
        val background = themeBackgrounds.getOrNull(themeIndex)
        if (background != null && screenW > 1f && screenH > 1f) {
            drawBitmapCover(c, background, screenRect)
            val shade = when (scene) {
                Scene.SPLASH -> 18
                Scene.PLAYING, Scene.COUNTDOWN -> if (effectiveGraphicsLevel() == 0) 88 else 66
                Scene.PAUSED, Scene.OVER -> 96
                Scene.THEMES -> 86
                else -> 98
            }
            bitmapOverlayPaint.color = Color.argb(shade, 4, 6, 18)
            c.drawRect(0f, 0f, screenW, screenH, bitmapOverlayPaint)
        } else {
            // Fallback if bitmap decode fails; never prevent the game from launching.
            val haloRadius = max(screenW, screenH) * 0.39f
            fillPaint.color = Color.argb(if (effectiveGraphicsLevel() == 0) 8 else 15, 81, 64, 180)
            c.drawCircle(screenW * 0.50f, screenH * 0.48f, haloRadius, fillPaint)
        }
        val starAlphaScale = if (background != null) 0.52f else 1f
        for (s in stars) {
            val flicker = (0.65f + sin(s.phase + backgroundTime * s.twinkle) * 0.35f).coerceIn(0.05f, 1f)
            fillPaint.color = Color.argb((s.alpha * flicker * 255f * starAlphaScale).toInt().coerceIn(0, 255), 174, 202, 255)
            c.drawCircle(s.x, s.y, s.radius, fillPaint)
        }
        if (scene == Scene.PLAYING || scene == Scene.COUNTDOWN || scene == Scene.PAUSED || scene == Scene.OVER || scene == Scene.SPLASH) {
            for (p in particles) {
                val alpha = (p.life / p.maxLife).coerceIn(0f, 1f)
                fillPaint.color = Color.argb((alpha * 210).toInt(), Color.red(p.color), Color.green(p.color), Color.blue(p.color))
                c.drawCircle(p.x, p.y, p.radius, fillPaint)
            }
        }
    }

    private fun drawBitmapCover(c: Canvas, bitmap: Bitmap, destination: RectF) {
        if (bitmap.width <= 0 || bitmap.height <= 0 || destination.width() <= 0f || destination.height() <= 0f) return
        val scale = max(destination.width() / bitmap.width.toFloat(), destination.height() / bitmap.height.toFloat())
        val drawW = bitmap.width * scale
        val drawH = bitmap.height * scale
        c.save()
        c.clipRect(destination)
        c.translate(destination.centerX() - drawW / 2f, destination.centerY() - drawH / 2f)
        c.scale(scale, scale)
        c.drawBitmap(bitmap, 0f, 0f, bitmapPaint)
        c.restore()
    }

    private fun drawSplash(c: Canvas, time: Float) {
        val progress = (splashElapsed / 4.6f).coerceIn(0f, 1f)
        val centerX = screenW / 2f
        // Logo reveal: two separately coloured lines for the cyan/violet brand treatment.
        val logoScale = (0.88f + 0.12f * smoothStep((splashElapsed / 0.8f).coerceIn(0f, 1f)))
        neonText(c, "ORBIT", centerX, screenH * 0.092f, 27f * unit * logoScale, CYAN, true)
        neonText(c, "DASH", centerX, screenH * 0.145f, 33f * unit * logoScale, LAVENDER, true)
        text(c, "NEON ARCADE  •  OFFLINE", centerX, screenH * 0.19f, 7.8f * unit, WHITE, true)
        val orbitY = screenH * 0.385f
        val orbitR = min(screenW * 0.31f, screenH * 0.105f) * (0.98f + 0.02f * sin(time * 1.2f))
        drawSplashOrbits(c, centerX, orbitY, orbitR, time)
        neonText(c, "JUST ONE MORE RUN", centerX, screenH * 0.54f, 11.2f * unit, WHITE, true)
        val featureY = screenH * 0.66f
        val featureX1 = screenW * 0.18f
        val featureX2 = screenW * 0.50f
        val featureX3 = screenW * 0.82f
        text(c, "★", featureX1, featureY, 25f * unit, GOLD, true)
        text(c, "✕", featureX2, featureY, 23f * unit, PINK, true)
        // Small orbital symbol: two thin ellipses and a cyan centre dot.
        c.save(); c.rotate(-18f, featureX3, featureY)
        strokePaint.color = CYAN; strokePaint.strokeWidth = 1.5f * unit
        c.drawOval(featureX3 - 12f * unit, featureY - 5f * unit, featureX3 + 12f * unit, featureY + 5f * unit, strokePaint)
        c.restore()
        drawGlow(c, featureX3, featureY, 2f * unit, CYAN)
        text(c, "COLLECT", featureX1, featureY + 23f * unit, 7.1f * unit, WHITE, true)
        text(c, "GOLD STARS", featureX1, featureY + 33f * unit, 6.7f * unit, GOLD, true)
        text(c, "AVOID", featureX2, featureY + 23f * unit, 7.1f * unit, WHITE, true)
        text(c, "PINK HAZARDS", featureX2, featureY + 33f * unit, 6.4f * unit, PINK, true)
        text(c, "SWITCH", featureX3, featureY + 23f * unit, 7.1f * unit, WHITE, true)
        text(c, "ORBITS", featureX3, featureY + 33f * unit, 6.7f * unit, CYAN, true)
        val barW = min(screenW * 0.72f, 310f * unit)
        val barH = 7f * unit
        val barX = (screenW - barW) / 2f
        val barY = screenH * 0.805f
        rect.set(barX, barY, barX + barW, barY + barH)
        fillPaint.color = Color.argb(180, 8, 13, 38)
        c.drawRoundRect(rect, barH / 2f, barH / 2f, fillPaint)
        strokePaint.color = Color.argb(125, 102, 104, 190)
        strokePaint.strokeWidth = unit
        c.drawRoundRect(rect, barH / 2f, barH / 2f, strokePaint)
        val reveal = smoothStep(progress)
        rect.set(barX + 1f, barY + 1f, barX + 1f + (barW - 2f) * reveal, barY + barH - 1f)
        fillPaint.shader = LinearGradient(barX, barY, barX + max(1f, barW * reveal), barY + barH,
            intArrayOf(Color.rgb(45, 232, 255), Color.rgb(96, 124, 255), Color.rgb(205, 82, 255)),
            null, Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, barH / 2f, barH / 2f, fillPaint)
        fillPaint.shader = null
        text(c, "LOADING...", centerX, barY + 22f * unit, 7.8f * unit, MUTED, true)
        text(c, "OFFICIALLY DESIGNED & DEVELOPED BY", centerX, screenH * 0.895f, 7.0f * unit, WHITE, true)
        text(c, "TecNxt Team • Vivek Singh", centerX, screenH * 0.928f, 10.1f * unit, WHITE, true)
    }

    private fun drawSplashOrbits(c: Canvas, cx: Float, cy: Float, radius: Float, time: Float) {
        drawRing(c, cx, cy, radius, Color.argb(210, 167, 103, 255), 2.0f * unit)
        drawRing(c, cx, cy, radius * 0.69f, Color.argb(210, 70, 226, 255), 1.7f * unit)
        drawRing(c, cx, cy, radius * 0.40f, Color.argb(105, 105, 124, 241), 1.0f * unit)
        drawGlow(c, cx, cy, (13f + 1.5f * sin(time * 2f)) * unit, Color.rgb(31, 110, 255))
        drawGlow(c, cx, cy, (6f + sin(time * 2.4f)) * unit, CYAN)
        val starAngle = -1.2f + time * 0.72f
        val hazardAngle = 2.25f + time * 0.49f
        val playerAngle = 3.0f + time * 0.82f
        val sx = cx + cos(starAngle) * radius * 0.69f
        val sy = cy + sin(starAngle) * radius * 0.69f
        drawGlow(c, sx, sy, 4.3f * unit, GOLD)
        text(c, "★", sx, sy, 12f * unit, GOLD, true)
        val hx = cx + cos(hazardAngle) * radius
        val hy = cy + sin(hazardAngle) * radius
        drawGlow(c, hx, hy, 4.0f * unit, PINK)
        text(c, "✕", hx, hy, 10f * unit, WHITE, true)
        val px = cx + cos(playerAngle) * radius * 0.69f
        val py = cy + sin(playerAngle) * radius * 0.69f
        strokePaint.color = Color.argb(200, 67, 209, 255); strokePaint.strokeWidth = 2f * unit
        c.drawLine(px - 17f * unit, py + 14f * unit, px - 4f * unit, py + 4f * unit, strokePaint)
        drawGlow(c, px, py, 6.0f * unit, CYAN)
        val breathe = 1f + 0.025f * sin(time * 1.1f)
        strokePaint.color = Color.argb(45, 139, 131, 250); strokePaint.strokeWidth = 1f * unit
        c.drawCircle(cx, cy, radius * 1.15f * breathe, strokePaint)
    }

    private fun smoothStep(value: Float): Float = value * value * (3f - 2f * value)

    private fun neonText(c: Canvas, value: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        textPaint.setShadowLayer(9f * unit, 0f, 0f, color)
        text(c, value, x, y, size, color, bold)
        textPaint.clearShadowLayer()
    }

    private fun drawProfileSetup(c: Canvas) {
        val cx = screenW / 2f
        drawGlow(c, cx, screenH * 0.235f, 7f * unit, CYAN)
        text(c, "WELCOME, PILOT", cx, screenH * 0.285f, 20f * unit, WHITE, true)
        text(c, "Let's personalise your Orbit Dash profile.", cx, screenH * 0.325f, 9.2f * unit, Color.rgb(215, 224, 255), false)
        val w = min(screenW - 44f * unit, 330f * unit)
        drawPanel(c, (screenW - w) / 2f, screenH * 0.365f, w, screenH * 0.22f)
        text(c, "YOUR NAME & AGE", cx, screenH * 0.405f, 12f * unit, CYAN, true)
        text(c, "These details stay on this device only.", cx, screenH * 0.445f, 8.4f * unit, WHITE, false)
        text(c, "You can start playing after saving", cx, screenH * 0.475f, 8.4f * unit, WHITE, false)
        text(c, "your local pilot profile.", cx, screenH * 0.503f, 8.4f * unit, WHITE, false)
        drawButton(c, "ENTER NAME & AGE", "Save profile and continue", cx, screenH * 0.635f, w, 44f * unit,
            ButtonAction.PROFILE_CONTINUE, ButtonStyle.PRIMARY, true, 10f * unit)
        text(c, "ORBIT DASH · NEON ARCADE · OFFLINE", cx, screenH * 0.72f, 8f * unit, MUTED, true)
    }

    private fun drawAboutUs(c: Canvas, time: Float) {
        drawPageHeading(c, "ABOUT US", "Built for fun, made with heart")
        val cx = screenW / 2f
        val heartSize = min(screenW * 0.075f, 52f * unit) * (1f + 0.025f * sin(time * 1.6f))
        val heartY = screenH * 0.225f
        val heart = Path().apply {
            moveTo(cx, heartY + heartSize * 0.45f)
            cubicTo(cx - heartSize * 0.90f, heartY - heartSize * 0.10f,
                cx - heartSize * 0.70f, heartY - heartSize * 0.74f, cx, heartY - heartSize * 0.28f)
            cubicTo(cx + heartSize * 0.70f, heartY - heartSize * 0.74f,
                cx + heartSize * 0.90f, heartY - heartSize * 0.10f, cx, heartY + heartSize * 0.45f)
            close()
        }
        fillPaint.color = Color.argb(38, 255, 78, 142)
        c.drawPath(heart, fillPaint)
        strokePaint.color = Color.argb(210, 255, 115, 176)
        strokePaint.strokeWidth = 1.6f * unit
        c.drawPath(heart, strokePaint)
        text(c, "♥", cx, heartY + heartSize * 0.06f, heartSize * 0.7f, Color.rgb(255, 152, 205), true)

        val w = min(screenW - 36f * unit, 344f * unit)
        val panelTop = screenH * 0.305f
        val panelBottom = screenH * 0.755f
        drawPanel(c, (screenW - w) / 2f, panelTop, w, panelBottom - panelTop)
        val lines = arrayOf(
            "Welcome to the game! 🎮",
            "We built this game purely for fun and",
            "non-stop entertainment, crafted to give you",
            "an engaging experience you’ll love playing",
            "every single day.",
            "Proudly developed from scratch by the",
            "Tecnxt Team — brought to life by",
            "Vivek Singh & Vicky Singh.",
            "Thank you so much for playing and",
            "supporting our journey! ❤️ Keep playing,",
            "beat your high scores, and enjoy every moment."
        )
        val startY = screenH * 0.355f
        val step = screenH * 0.029f
        lines.forEachIndexed { index, line ->
            val color = when (index) {
                0 -> Color.rgb(255, 221, 238)
                5, 6, 7 -> Color.rgb(177, 225, 255)
                8, 9, 10 -> Color.rgb(255, 214, 229)
                else -> Color.rgb(230, 235, 255)
            }
            text(c, line, cx, startY + index * step, if (index == 0) 9.5f * unit else 8.0f * unit, color, index == 0 || index == 7)
        }
        drawButton(c, "♡  BACK TO HOME", "", cx, screenH * 0.815f, w, 40f * unit,
            ButtonAction.BACK, ButtonStyle.PRIMARY, true, 10f * unit, PINK)
    }

    private fun drawThemes(c: Canvas, time: Float) {
        drawPageHeading(c, "THEMES", "Choose your world · all three themes are free")
        val w = min(screenW - 28f * unit, 350f * unit)
        val cardHeight = min(128f * unit, screenH * 0.158f)
        val firstTop = screenH * 0.225f
        val step = screenH * 0.205f
        WorldTheme.entries.forEachIndexed { index, theme ->
            val top = firstTop + index * step
            val left = (screenW - w) / 2f
            rect.set(left, top, left + w, top + cardHeight)
            fillPaint.color = Color.argb(218, Color.red(PANEL), Color.green(PANEL), Color.blue(PANEL))
            c.drawRoundRect(rect, 15f * unit, 15f * unit, fillPaint)
            strokePaint.color = Color.argb(if (selectedTheme == theme) 205 else 100,
                Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent))
            strokePaint.strokeWidth = if (selectedTheme == theme) 1.8f * unit else unit
            c.drawRoundRect(rect, 15f * unit, 15f * unit, strokePaint)
            val thumb = RectF(left + 7f * unit, top + 7f * unit, left + w * 0.39f, top + cardHeight - 7f * unit)
            val bitmap = themeBackgrounds.getOrNull(index)
            if (bitmap != null) {
                themeClipPath.reset()
                themeClipPath.addRoundRect(thumb, 10f * unit, 10f * unit, Path.Direction.CW)
                c.save(); c.clipPath(themeClipPath); drawBitmapCover(c, bitmap, thumb); c.restore()
                fillPaint.color = Color.argb(30, 0, 0, 12)
                c.drawRoundRect(thumb, 10f * unit, 10f * unit, fillPaint)
            } else {
                fillPaint.color = Color.argb(105, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent))
                c.drawRoundRect(thumb, 10f * unit, 10f * unit, fillPaint)
                drawLogoOrbits(c, thumb.centerX(), thumb.centerY(), min(thumb.width() * 0.3f, thumb.height() * 0.35f), time)
            }
            val titleX = left + w * 0.42f
            text(c, theme.title, titleX, top + 22f * unit, 7.9f * unit, theme.accent, true, Paint.Align.LEFT)
            text(c, theme.lineOne, titleX, top + 43f * unit, 6.5f * unit, WHITE, false, Paint.Align.LEFT)
            text(c, theme.lineTwo, titleX, top + 55f * unit, 6.5f * unit, WHITE, false, Paint.Align.LEFT)
            val actionW = min(102f * unit, w * 0.32f)
            drawButton(c, if (selectedTheme == theme) "✓ EQUIPPED" else "SELECT", "", left + w - actionW / 2f - 7f * unit,
                top + cardHeight - 31f * unit, actionW, 26f * unit, themeSelectActions[index],
                if (selectedTheme == theme) ButtonStyle.SELECTED else ButtonStyle.PRIMARY, true, 7.0f * unit, theme.accent)
        }
        text(c, "You can change the theme anytime.", screenW / 2f, screenH * 0.85f, 7.6f * unit, MUTED, false)
        drawButton(c, "⌂  BACK TO HOME", "", screenW / 2f, screenH * 0.905f, w, 41f * unit,
            ButtonAction.BACK, ButtonStyle.SECONDARY, true, 10f * unit)
    }

    private fun drawBrand(c: Canvas, showMusicButton: Boolean) {
        text(c, "ORBIT", 22f * unit, 28f * unit, 12.5f * unit, CYAN, true, Paint.Align.LEFT)
        text(c, "DASH", 66f * unit, 28f * unit, 12.5f * unit, WHITE, true, Paint.Align.LEFT)
        text(c, "NEON ARCADE  •  OFFLINE", 22f * unit, 47f * unit, 7.5f * unit, MUTED, true, Paint.Align.LEFT)
        if (showMusicButton) drawRoundIcon(c, screenW - 29f * unit, 30f * unit, if (audio.musicEnabled) "♫" else "×", ButtonAction.TOGGLE_MUSIC)
    }

    private fun drawTopBack(c: Canvas) {
        drawRoundIcon(c, 29f * unit, 30f * unit, "‹", ButtonAction.BACK)
    }

    private fun drawRoundIcon(c: Canvas, cx: Float, cy: Float, glyph: String, action: ButtonAction) {
        val r = 17f * unit
        fillPaint.color = Color.argb(24, 255, 255, 255)
        c.drawCircle(cx, cy, r, fillPaint)
        strokePaint.color = Color.argb(85, 133, 149, 220)
        strokePaint.strokeWidth = 1f * unit
        c.drawCircle(cx, cy, r, strokePaint)
        text(c, glyph, cx, cy - 0.5f * unit, 23f * unit, WHITE, true)
        registerTarget(action, cx - 23f * unit, cy - 23f * unit, cx + 23f * unit, cy + 23f * unit)
    }

    private fun drawHome(c: Canvas, time: Float) {
        drawBrand(c, true)
        drawPill(c, screenW / 2f - 94f * unit, screenH * 0.088f, 188f * unit, 25f * unit,
            "★  $formattedStarPoints STAR POINTS", Color.argb(30, 255, 205, 96),
            Color.argb(100, 255, 205, 96), GOLD, 8.2f * unit)
        val hasSave = savedRunAvailable
        drawLogoOrbits(c, screenW / 2f, screenH * 0.215f, min(screenW * 0.17f, screenH * 0.072f), time)
        text(c, "JUST ONE MORE RUN", screenW / 2f, screenH * 0.315f, 9.6f * unit, MUTED, true)
        drawPill(c, screenW / 2f - 80f * unit, screenH * 0.346f, 160f * unit, 29f * unit,
            "BEST SCORE  ${best.toString().padStart(4, '0')}", Color.argb(28, 139, 123, 255), Color.argb(95, 139, 123, 255), LAVENDER, 9.3f * unit)
        val mainW = min(screenW - 44f * unit, 344f * unit)
        drawButton(c, "▶   NEW GAME", "Start a fresh run", screenW / 2f, screenH * 0.405f, mainW, 47f * unit,
            ButtonAction.NEW_GAME, ButtonStyle.PRIMARY, true, 10.5f * unit)
        val diffLabelY: Float
        val selectorY: Float
        val rowOneY: Float
        val rowTwoY: Float
        val themesY: Float
        if (hasSave) {
            drawButton(c, "↻   CONTINUE", "Resume your saved run", screenW / 2f, screenH * 0.462f,
                mainW, 39f * unit, ButtonAction.CONTINUE, ButtonStyle.SECONDARY, true, 9.2f * unit)
            diffLabelY = screenH * 0.516f
            selectorY = screenH * 0.545f
            rowOneY = screenH * 0.601f
            rowTwoY = screenH * 0.659f
            themesY = screenH * 0.725f
        } else {
            // Keep the menu compact when there is no resumable run; do not show an inert Continue button.
            diffLabelY = screenH * 0.482f
            selectorY = screenH * 0.513f
            rowOneY = screenH * 0.572f
            rowTwoY = screenH * 0.634f
            themesY = screenH * 0.704f
        }
        text(c, "SELECT DIFFICULTY", screenW / 2f, diffLabelY, 8.1f * unit, MUTED, true)
        val selectorGap = 6f * unit
        val selectorW = min((screenW - 44f * unit - selectorGap * 2f) / 3f, 110f * unit)
        val selectorTotal = selectorW * 3f + selectorGap * 2f
        val selectorLeft = (screenW - selectorTotal) / 2f
        val selectorH = 31f * unit
        for (i in homeDifficultyOptions.indices) {
            val x = selectorLeft + i * (selectorW + selectorGap)
            val chosen = difficulty == homeDifficultyOptions[i]
            drawButton(c, homeDifficultyOptions[i].title, "", x + selectorW / 2f, selectorY, selectorW, selectorH,
                homeDifficultyActions[i], if (chosen) ButtonStyle.SELECTED else ButtonStyle.SECONDARY, true, 8.8f * unit,
                if (chosen) CYAN else LAVENDER)
        }
        val cardW = screenW * 0.435f
        val cardH = 42f * unit
        val left = screenW * 0.2725f
        val right = screenW * 0.7275f
        drawButton(c, "♛  HIGH SCORES", "Your records", left, rowOneY, cardW, cardH, ButtonAction.OPEN_SCORES, ButtonStyle.SECONDARY, true, 8.3f * unit)
        drawButton(c, "▣  SHOP", "Ships & effects", right, rowOneY, cardW, cardH, ButtonAction.OPEN_CUSTOMIZE, ButtonStyle.SECONDARY, true, 8.7f * unit)
        drawButton(c, "★  MISSIONS", "Daily rewards", left, rowTwoY, cardW, cardH, ButtonAction.OPEN_MISSIONS, ButtonStyle.SECONDARY, true, 8.7f * unit)
        drawButton(c, "⚙  SETTINGS", "Sound & graphics", right, rowTwoY, cardW, cardH, ButtonAction.OPEN_SETTINGS, ButtonStyle.SECONDARY, true, 8.7f * unit)
        val homeWideButton = min(screenW - 44f * unit, 344f * unit)
        drawButton(c, "◎  THEMES", "Choose your world", screenW / 2f, themesY, homeWideButton, 42f * unit,
            ButtonAction.OPEN_THEMES, ButtonStyle.SELECTED, true, 9.6f * unit, selectedTheme.accent)
        drawButton(c, "♡  ABOUT US", "Our story & team", screenW / 2f, themesY + screenH * 0.060f,
            homeWideButton, 34f * unit, ButtonAction.OPEN_ABOUT, ButtonStyle.SECONDARY, true, 9.2f * unit, PINK)
        // Dark translucent footer plaque keeps both credit lines readable over every world.
        rect.set(screenW * 0.045f, screenH * 0.892f, screenW * 0.955f, screenH * 0.978f)
        fillPaint.color = Color.argb(218, 4, 7, 20)
        c.drawRoundRect(rect, 12f * unit, 12f * unit, fillPaint)
        strokePaint.color = Color.argb(95, 124, 129, 235)
        strokePaint.strokeWidth = 0.85f * unit
        c.drawRoundRect(rect, 12f * unit, 12f * unit, strokePaint)
        text(c, "THANKS FOR PLAYING", screenW / 2f, screenH * 0.921f, 9.2f * unit, Color.rgb(196, 169, 255), true)
        text(c, "This game is officially developed by the TecNxt Team • Vivek Singh", screenW / 2f, screenH * 0.954f,
            8.0f * unit, Color.rgb(231, 235, 255), false)
    }

    private fun drawLogoOrbits(c: Canvas, cx: Float, cy: Float, radius: Float, time: Float) {
        // Small, deterministic breathing pulses keep the hero art lively without bitmaps or a 3D engine.
        val breathe = 1f + sin(time * 1.15f) * 0.018f
        val innerRadius = radius * 0.63f * (1f + sin(time * 1.35f + 0.7f) * 0.012f)
        drawRing(c, cx, cy, innerRadius, Color.argb(175, 97, 228, 255), 1.2f * unit)
        drawRing(c, cx, cy, radius * breathe, Color.argb(160, 150, 120, 255), 1.45f * unit)
        drawRing(c, cx, cy, radius * 1.30f, Color.argb(65, 94, 103, 193), 1f * unit)
        drawGlow(c, cx, cy, (4.8f + sin(time * 2.0f) * 0.45f) * unit, CYAN)
        repeat(3) { i ->
            val a = time * (0.47f + i * 0.08f) + i * 2f * PI.toFloat() / 3f
            val r = if (i % 2 == 0) radius * breathe else innerRadius
            drawGlow(c, cx + cos(a) * r, cy + sin(a) * r,
                (2.5f + sin(time * 1.8f + i) * 0.28f) * unit, if (i == 1) CYAN else LAVENDER)
        }
    }

    private fun drawPlaying(c: Canvas, time: Float, allowPause: Boolean) {
        drawGameHud(c, allowPause)
        drawOrbitScene(c, time)
        text(c, "TAP TO SWITCH ORBITS", screenW / 2f, screenH * 0.825f, 10f * unit, Color.rgb(213, 217, 244), true)
        text(c, "Avoid pink hazards  ·  Collect gold stars", screenW / 2f, screenH * 0.855f, 9.5f * unit, Color.rgb(119, 127, 166), false)
    }

    private fun drawGameHud(c: Canvas, allowPause: Boolean) {
        text(c, "ORBIT DASH", 22f * unit, 29f * unit, 10.5f * unit, WHITE, true, Paint.Align.LEFT)
        text(c, difficulty.title, 22f * unit, 45f * unit, 7.5f * unit, MUTED, true, Paint.Align.LEFT)
        text(c, score.toString().padStart(4, '0'), screenW / 2f, 49f * unit, 25f * unit, WHITE, true)
        text(c, "SCORE", screenW / 2f, 70f * unit, 8f * unit, MUTED, true)
        text(c, "✦ $gems", screenW - 66f * unit, 59f * unit, 10f * unit, GOLD, true, Paint.Align.RIGHT)
        if (allowPause) {
            drawRoundIcon(c, screenW - 78f * unit, 30f * unit, if (audio.musicEnabled) "♫" else "×", ButtonAction.TOGGLE_MUSIC)
            drawRoundIcon(c, screenW - 28f * unit, 30f * unit, "Ⅱ", ButtonAction.PAUSE)
        }
    }

    private fun drawOrbitScene(c: Canvas, time: Float) {
        val geo = orbitGeometry()
        fillPaint.color = Color.argb(14, 66, 49, 143)
        c.drawCircle(geo.cx, geo.cy, geo.outer * 1.5f, fillPaint)
        if (effectiveGraphicsLevel() >= 1) drawRing(c, geo.cx, geo.cy, geo.outer + 2f * unit, Color.argb(20, 126, 100, 255), 5f * unit)
        drawRing(c, geo.cx, geo.cy, geo.outer, Color.argb(130, 111, 110, 179), 1.3f * unit)
        drawRing(c, geo.cx, geo.cy, geo.inner, Color.argb(122, 111, 110, 179), 1.3f * unit)
        if (effectiveGraphicsLevel() >= 1) {
            strokePaint.color = Color.argb(74, 106, 126, 195)
            strokePaint.strokeWidth = unit
            strokePaint.pathEffect = android.graphics.DashPathEffect(floatArrayOf(2f * unit, 11f * unit), 0f)
            c.drawCircle(geo.cx, geo.cy, geo.outer + 10f * unit, strokePaint)
            strokePaint.pathEffect = null
        }
        repeat(if (effectiveGraphicsLevel() == 0) 4 else 8) { i ->
            val amount = if (effectiveGraphicsLevel() == 0) 4 else 8
            val a = time * 0.12f + i * 2f * PI.toFloat() / amount
            fillPaint.color = Color.argb(150, 126, 132, 218)
            c.drawCircle(geo.cx + cos(a) * (geo.outer + 10f * unit), geo.cy + sin(a) * (geo.outer + 10f * unit), 1.25f * unit, fillPaint)
        }
        fillPaint.color = Color.rgb(24, 22, 52)
        c.drawCircle(geo.cx, geo.cy, 22f * unit, fillPaint)
        strokePaint.color = Color.argb(150, 151, 120, 255)
        strokePaint.strokeWidth = 1.1f * unit
        c.drawCircle(geo.cx, geo.cy, 22f * unit, strokePaint)
        strokePaint.color = Color.argb(145, 166, 129, 255)
        strokePaint.strokeWidth = 2.2f * unit
        c.save(); c.rotate(-time * 20f, geo.cx, geo.cy)
        c.drawOval(geo.cx - 10f * unit, geo.cy - 4f * unit, geo.cx + 10f * unit, geo.cy + 4f * unit, strokePaint)
        c.restore()
        for (o in hazards) {
            val orbitRadius = if (o.lane == 1) geo.outer else geo.inner
            val a = angle + o.distance
            val x = geo.cx + cos(a) * orbitRadius
            val y = geo.cy + sin(a) * orbitRadius
            if (x < -30f * unit || x > screenW + 30f * unit || y < -30f * unit || y > screenH + 30f * unit) continue
            c.save()
            c.translate(x, y)
            c.rotate(o.spin * 57.2958f)
            c.scale(unit, unit)
            if (o.gem) {
                fillPaint.color = GOLD
                c.drawPath(gemPath, fillPaint)
                if (effectiveGraphicsLevel() >= 1) {
                    strokePaint.color = Color.argb(205, 255, 244, 190)
                    strokePaint.strokeWidth = 0.9f
                    c.drawPath(gemPath, strokePaint)
                }
            } else {
                if (effectiveGraphicsLevel() >= 1) drawGlow(c, 0f, 0f, 5f, PINK)
                if (o.distance < 0.62f && effectiveGraphicsLevel() >= 1) {
                    val alertPulse = (0.5f + 0.5f * sin(time * 10f + o.spin)).coerceIn(0f, 1f)
                    strokePaint.color = Color.argb((65f + alertPulse * 120f).toInt(), 255, 91, 145)
                    strokePaint.strokeWidth = 0.65f + alertPulse * 0.55f
                    c.drawCircle(0f, 0f, 11f + alertPulse * 1.3f, strokePaint)
                }
                fillPaint.color = PINK
                c.drawPath(hazardPath, fillPaint)
                strokePaint.color = Color.rgb(255, 209, 223)
                strokePaint.strokeWidth = 0.85f
                c.drawPath(hazardPath, strokePaint)
                c.drawLine(-3f, -2f, 3.5f, 2.8f, strokePaint)
                c.drawLine(0f, -4f, 0f, 2f, strokePaint)
                fillPaint.color = WHITE
                c.drawCircle(0f, 4f, 0.8f, fillPaint)
            }
            c.restore()
        }
        val pr = if (lane == 1) geo.outer else geo.inner
        val px = geo.cx + cos(angle) * pr
        val py = geo.cy + sin(angle) * pr
        val color = shipColor()
        if (effectiveGraphicsLevel() >= 1) {
            val trail = shipTrailColor()
            strokePaint.color = Color.argb(if (selectedSkinIndex == 3) 145 else 105,
                Color.red(trail), Color.green(trail), Color.blue(trail))
            strokePaint.strokeWidth = if (selectedSkinIndex == 3) 3.8f * unit else 3f * unit
            strokePaint.strokeCap = Paint.Cap.ROUND
            c.drawLine(px - cos(angle) * (if (selectedSkinIndex == 3) 27f else 18f) * unit,
                py - sin(angle) * (if (selectedSkinIndex == 3) 27f else 18f) * unit,
                px - cos(angle) * 4f * unit, py - sin(angle) * 4f * unit, strokePaint)
            if (selectedSkinIndex == 3 || selectedSkinIndex == 5) {
                strokePaint.color = Color.argb(70, Color.red(trail), Color.green(trail), Color.blue(trail))
                strokePaint.strokeWidth = 1.5f * unit
                c.drawLine(px - cos(angle) * 22f * unit, py - sin(angle) * 22f * unit,
                    px - cos(angle) * 5f * unit, py - sin(angle) * 5f * unit, strokePaint)
            }
        }
        drawGlow(c, px, py, 7.1f * unit, color)
        fillPaint.color = Color.rgb(249, 255, 255)
        c.drawCircle(px, py, 3.2f * unit, fillPaint)
        if (lastSwitch > 0f) {
            strokePaint.color = Color.argb((lastSwitch * 255f * 2.8f).toInt().coerceIn(0, 255), 140, 225, 255)
            strokePaint.strokeWidth = 1.5f * unit
            c.drawCircle(px, py, (12f + (0.22f - lastSwitch) * 38f) * unit, strokePaint)
        }
    }

    // Mutable scratch geometry is reused by the render/update loops to avoid 60+ short-lived objects per second.
    private class OrbitGeometry(var cx: Float = 0f, var cy: Float = 0f, var inner: Float = 0f, var outer: Float = 0f)
    private val cachedOrbitGeometry = OrbitGeometry()
    private fun orbitGeometry(): OrbitGeometry {
        val base = min(screenW * 0.355f, screenH * 0.245f)
        cachedOrbitGeometry.cx = screenW / 2f
        cachedOrbitGeometry.cy = screenH * 0.515f
        cachedOrbitGeometry.inner = base * 0.69f
        cachedOrbitGeometry.outer = base
        return cachedOrbitGeometry
    }

    private fun drawPaused(c: Canvas, time: Float) {
        drawPlaying(c, time, false)
        fillPaint.color = Color.argb(184, 4, 6, 17)
        c.drawRect(0f, 0f, screenW, screenH, fillPaint)
        val w = min(screenW - 44f * unit, 330f * unit)
        val h = 365f * unit
        val x = (screenW - w) / 2f
        val y = (screenH - h) / 2f
        drawPanel(c, x, y, w, h)
        drawGlow(c, screenW / 2f, y + 34f * unit, 3.2f * unit, CYAN)
        text(c, "PAUSED", screenW / 2f, y + 53f * unit, 22f * unit, WHITE, true)
        text(c, "YOUR RUN IS SAFE", screenW / 2f, y + 74f * unit, 8f * unit, MUTED, true)
        val bw = w - 40f * unit
        val bh = 39f * unit
        val top = y + 85f * unit
        val gap = 45f * unit
        drawButton(c, "RESUME", "3-second countdown", screenW / 2f, top, bw, bh, ButtonAction.RESUME, ButtonStyle.PRIMARY, true, 10f * unit)
        drawButton(c, "RESTART RUN", "Start this run over", screenW / 2f, top + gap, bw, bh, ButtonAction.RESTART, ButtonStyle.SECONDARY, true, 9.5f * unit)
        drawButton(c, "HOME MENU", "Your run stays saved", screenW / 2f, top + gap * 2f, bw, bh, ButtonAction.HOME, ButtonStyle.SECONDARY, true, 9.5f * unit)
        drawButton(c, "MUSIC  ·  ${if (audio.musicEnabled) "ON" else "OFF"}", "Flute background soundtrack", screenW / 2f, top + gap * 3f, bw, bh, ButtonAction.TOGGLE_MUSIC, if (audio.musicEnabled) ButtonStyle.SELECTED else ButtonStyle.SECONDARY, true, 9f * unit)
        drawButton(c, "SOUND EFFECTS  ·  ${if (audio.effectsEnabled) "ON" else "OFF"}", "Switch, collect and reward sounds", screenW / 2f, top + gap * 4f, bw, bh, ButtonAction.TOGGLE_EFFECTS, if (audio.effectsEnabled) ButtonStyle.SELECTED else ButtonStyle.SECONDARY, true, 8.6f * unit)
        drawButton(c, "EXIT GAME", "Close Orbit Dash", screenW / 2f, top + gap * 5f, bw, bh, ButtonAction.EXIT, ButtonStyle.DANGER, true, 9.5f * unit)
    }

    private fun drawCountdown(c: Canvas, time: Float) {
        drawPlaying(c, time, true)
        fillPaint.color = Color.argb(100, 4, 6, 17)
        c.drawRect(0f, 0f, screenW, screenH, fillPaint)
        val count = max(1, kotlin.math.ceil(resumeCountdown.toDouble()).toInt())
        drawGlow(c, screenW / 2f, screenH * 0.46f, 15f * unit, if (count == 1) CYAN else LAVENDER)
        text(c, count.toString(), screenW / 2f, screenH * 0.46f, 66f * unit, WHITE, true)
        text(c, "GET READY", screenW / 2f, screenH * 0.515f, 11f * unit, MUTED, true)
    }

    private fun drawGameOver(c: Canvas, time: Float) {
        drawPlaying(c, time, false)
        fillPaint.color = Color.argb(184, 4, 6, 17)
        c.drawRect(0f, 0f, screenW, screenH, fillPaint)
        val w = min(screenW - 44f * unit, 330f * unit)
        val h = 300f * unit
        val x = (screenW - w) / 2f
        val y = (screenH - h) / 2f
        drawPanel(c, x, y, w, h)
        drawGlow(c, screenW / 2f, y + 35f * unit, 3.5f * unit, PINK)
        text(c, "RUN COMPLETE", screenW / 2f, y + 59f * unit, 11f * unit, PINK, true)
        text(c, if (isNewBestRun) "NEW PERSONAL BEST" else "$gameOverReason · TRY AGAIN", screenW / 2f, y + 85f * unit, 9f * unit, WHITE, true)
        text(c, "${score.toString().padStart(4, '0')}", screenW / 2f, y + 125f * unit, 31f * unit, WHITE, true)
        text(c, "SCORE", screenW / 2f, y + 148f * unit, 8f * unit, MUTED, true)
        text(c, "BEST  ${best.toString().padStart(4, '0')}     ✦  $gems", screenW / 2f, y + 175f * unit, 10f * unit, GOLD, true)
        val bw = w - 40f * unit
        val bh = 40f * unit
        drawButton(c, "PLAY AGAIN", "One more run?", screenW / 2f, y + 195f * unit, bw, bh, ButtonAction.NEW_GAME, ButtonStyle.PRIMARY, true, 10.5f * unit)
        drawButton(c, "HOME MENU", "See records and upgrades", screenW / 2f, y + 243f * unit, bw, bh, ButtonAction.HOME, ButtonStyle.SECONDARY, true, 10f * unit)
    }

    private fun drawSettings(c: Canvas) {
        drawPageHeading(c, "SETTINGS", "Personalize your gameplay")
        val mainW = min(screenW - 44f * unit, 330f * unit)
        text(c, "AUDIO", screenW / 2f, screenH * 0.182f, 9.8f * unit, WHITE, true)
        drawButton(c, "BACKGROUND MUSIC", if (audio.musicEnabled) "ON · Selected track loops" else "OFF · Music muted",
            screenW / 2f, screenH * 0.215f, mainW, 34f * unit, ButtonAction.TOGGLE_MUSIC,
            if (audio.musicEnabled) ButtonStyle.SELECTED else ButtonStyle.SECONDARY, true, 9.6f * unit)

        text(c, "MUSIC TRACK  ·  TAP ARROWS TO CHANGE", screenW / 2f, screenH * 0.247f, 7.9f * unit, WHITE, true)
        drawMusicTrackPicker(c, screenH * 0.280f, mainW)

        drawButton(c, "SOUND EFFECTS", if (audio.effectsEnabled) "ON · Soft taps, stars and rewards" else "OFF · Effects muted",
            screenW / 2f, screenH * 0.323f, mainW, 34f * unit, ButtonAction.TOGGLE_EFFECTS,
            if (audio.effectsEnabled) ButtonStyle.SELECTED else ButtonStyle.SECONDARY, true, 9.5f * unit)
        text(c, "VOLUME LEVELS", screenW / 2f, screenH * 0.365f, 9.2f * unit, WHITE, true)
        drawVolumeSlider(c, "Music Volume", audio.musicVolume, screenH * 0.405f, ButtonAction.MUSIC_VOLUME_SLIDER)
        drawVolumeSlider(c, "Sound Effects Volume", audio.effectsVolume, screenH * 0.490f, ButtonAction.EFFECTS_VOLUME_SLIDER)
        text(c, "GRAPHICS QUALITY", screenW / 2f, screenH * 0.560f, 9.7f * unit, WHITE, true)
        val segW = (mainW - 12f * unit) / 3f
        val segTop = screenH * 0.590f
        for (index in 0..2) {
            val quality = when (index) { 0 -> GraphicsQuality.AUTO; 1 -> GraphicsQuality.LOW; else -> GraphicsQuality.HIGH }
            val cx = screenW / 2f - segW - 6f * unit + index * (segW + 6f * unit) + segW / 2f
            val action = when (quality) { GraphicsQuality.AUTO -> ButtonAction.GRAPHICS_AUTO; GraphicsQuality.LOW -> ButtonAction.GRAPHICS_LOW; GraphicsQuality.HIGH -> ButtonAction.GRAPHICS_HIGH }
            drawButton(c, quality.title, "", cx, segTop, segW, 36f * unit, action,
                if (graphicsQuality == quality) ButtonStyle.SELECTED else ButtonStyle.SECONDARY, true, 9.5f * unit)
        }
        text(c, "Higher quality adds glow and detail.", screenW / 2f, screenH * 0.655f, 8.2f * unit, MUTED, false)
        text(c, "Settings save automatically", screenW / 2f, screenH * 0.705f, 8.1f * unit, Color.rgb(105, 220, 206), true)
        drawButton(c, "BACK TO HOME", "", screenW / 2f, screenH * 0.745f, mainW, 42f * unit, ButtonAction.BACK, ButtonStyle.SECONDARY, true, 10.2f * unit)
    }

    private fun drawMusicTrackPicker(c: Canvas, centerY: Float, mainW: Float) {
        val left = screenW / 2f - mainW / 2f
        val height = 31f * unit
        rect.set(left, centerY - height / 2f, left + mainW, centerY + height / 2f)
        fillPaint.color = Color.argb(190, 11, 15, 38)
        c.drawRoundRect(rect, 10f * unit, 10f * unit, fillPaint)
        strokePaint.color = Color.argb(118, 102, 222, 255)
        strokePaint.strokeWidth = 0.9f * unit
        c.drawRoundRect(rect, 10f * unit, 10f * unit, strokePaint)
        val arrowW = 34f * unit
        drawButton(c, "‹", "", left + arrowW / 2f + 3f * unit, centerY, arrowW, height - 3f * unit,
            ButtonAction.MUSIC_PREVIOUS, ButtonStyle.SECONDARY, true, 17f * unit, CYAN)
        drawButton(c, "›", "", left + mainW - arrowW / 2f - 3f * unit, centerY, arrowW, height - 3f * unit,
            ButtonAction.MUSIC_NEXT, ButtonStyle.SECONDARY, true, 17f * unit, CYAN)
        text(c, "${audio.selectedMusicIndex + 1}/4  ·  ${audio.selectedMusicTrack.title}", screenW / 2f,
            centerY - 4.5f * unit, 8.1f * unit, WHITE, true)
        text(c, audio.selectedMusicTrack.mood, screenW / 2f,
            centerY + 8.0f * unit, 6.4f * unit, Color.rgb(191, 203, 240), false)
    }

    private fun drawVolumeSlider(c: Canvas, title: String, value: Float, centerY: Float, action: ButtonAction) {
        val left = screenW * 0.17f
        val right = screenW * 0.83f
        text(c, title, left, centerY - 15f * unit, 7.8f * unit, WHITE, true, Paint.Align.LEFT)
        text(c, "${(value * 100f).toInt()}%", right, centerY - 15f * unit, 7.8f * unit, MUTED, true, Paint.Align.RIGHT)
        rect.set(left, centerY - 2f * unit, right, centerY + 2f * unit)
        fillPaint.color = Color.argb(65, 154, 166, 214)
        c.drawRoundRect(rect, 4f * unit, 4f * unit, fillPaint)
        val knobX = left + (right - left) * value.coerceIn(0f, 1f)
        rect.set(left, centerY - 2f * unit, knobX, centerY + 2f * unit)
        fillPaint.color = CYAN
        c.drawRoundRect(rect, 4f * unit, 4f * unit, fillPaint)
        drawGlow(c, knobX, centerY, 3.8f * unit, CYAN)
        registerTarget(action, left - 14f * unit, centerY - 16f * unit,
            right + 14f * unit, centerY + 16f * unit)
    }

    private fun drawScores(c: Canvas) {
        drawPageHeading(c, "HIGH SCORES", "Your best local runs · stored on this device")
        val w = min(screenW - 44f * unit, 330f * unit)
        drawPill(c, screenW / 2f - w / 2f, screenH * 0.205f, w, 40f * unit,
            "PERSONAL BEST     ${best.toString().padStart(4, '0')}", Color.argb(25, 143, 122, 255), Color.argb(90, 143, 122, 255), LAVENDER, 10.5f * unit)
        text(c, "LAST RUN  ${lastScore.toString().padStart(4, '0')}     ·     RUNS  $totalRuns", screenW / 2f, screenH * 0.275f, 8.4f * unit, MUTED, true)
        text(c, "TOP RUNS", screenW / 2f, screenH * 0.335f, 10f * unit, WHITE, true)
        val list = scoreHistory
        repeat(5) { index ->
            val y = screenH * 0.365f + index * 49f * unit
            val value = list.getOrNull(index)
            drawScoreRow(c, y, index + 1, value)
        }
        drawPill(c, screenW / 2f - 92f * unit, screenH * 0.70f, 184f * unit, 30f * unit,
            "STAR POINTS   ★ $formattedStarPoints", Color.argb(22, 255, 204, 98), Color.argb(78, 255, 204, 98), GOLD, 8.2f * unit)
        drawButton(c, "BACK TO HOME", "", screenW / 2f, screenH * 0.77f, w, 44f * unit, ButtonAction.BACK, ButtonStyle.SECONDARY, true, 10.5f * unit)
    }

    private fun drawScoreRow(c: Canvas, top: Float, position: Int, value: Int?) {
        val w = min(screenW - 50f * unit, 318f * unit)
        val x = (screenW - w) / 2f
        rect.set(x, top, x + w, top + 39f * unit)
        fillPaint.color = Color.argb(if (position == 1) 34 else 17, 132, 119, 255)
        c.drawRoundRect(rect, 10f * unit, 10f * unit, fillPaint)
        text(c, "#${position.toString().padStart(2, '0')}", x + 24f * unit, top + 19.5f * unit, 10f * unit, if (position == 1) GOLD else MUTED, true)
        text(c, value?.toString()?.padStart(4, '0') ?: "—", x + w - 36f * unit, top + 19.5f * unit, 12f * unit, WHITE, true, Paint.Align.RIGHT)
    }

    private fun drawCustomize(c: Canvas) {
        drawPageHeading(c, "SHOP", "Ships & cosmic effects")
        val w = min(screenW - 30f * unit, 350f * unit)
        drawPill(c, screenW / 2f - 95f * unit, screenH * 0.172f, 190f * unit, 25f * unit,
            "★  $formattedStarPoints STAR POINTS", Color.argb(28, 255, 204, 98),
            Color.argb(100, 255, 204, 98), GOLD, 8f * unit)
        text(c, "EQUIPPED · ${shipSkins[selectedSkinIndex].title}", screenW / 2f,
            screenH * 0.218f, 7.8f * unit, MUTED, true)
        for (shopIndex in shipSkins.indices) {
            val skin = shipSkins[shopIndex]
            val rowTop = screenH * 0.245f + shopIndex * screenH * 0.075f
            val rowHeight = 52f * unit
            val left = (screenW - w) / 2f
            panelRect.set(left, rowTop, left + w, rowTop + rowHeight)
            fillPaint.color = Color.argb(226, Color.red(PANEL), Color.green(PANEL), Color.blue(PANEL))
            c.drawRoundRect(panelRect, 13f * unit, 13f * unit, fillPaint)
            strokePaint.color = Color.argb(if (selectedSkinIndex == shopIndex) 145 else 65,
                Color.red(skin.color), Color.green(skin.color), Color.blue(skin.color))
            strokePaint.strokeWidth = if (selectedSkinIndex == shopIndex) 1.6f * unit else unit
            c.drawRoundRect(panelRect, 13f * unit, 13f * unit, strokePaint)
            // A live Canvas preview represents the skin/effect and stays lightweight compared with a full bitmap per item.
            val previewX = left + 32f * unit
            val previewY = rowTop + rowHeight * 0.5f
            if (effectiveGraphicsLevel() >= 1) {
                strokePaint.color = Color.argb(56, Color.red(skin.color), Color.green(skin.color), Color.blue(skin.color))
                strokePaint.strokeWidth = unit
                c.drawCircle(previewX, previewY, 20f * unit, strokePaint)
            }
            strokePaint.color = Color.argb(190, Color.red(skin.color), Color.green(skin.color), Color.blue(skin.color))
            strokePaint.strokeWidth = 2f * unit
            c.drawLine(previewX - 21f * unit, previewY + 8f * unit, previewX - 7f * unit, previewY + 3f * unit, strokePaint)
            c.drawLine(previewX - 18f * unit, previewY + 13f * unit, previewX - 6f * unit, previewY + 7f * unit, strokePaint)
            drawGlow(c, previewX, previewY, 6f * unit, skin.color)
            val owned = skin.id in ownedItemIds
            val selected = selectedSkinIndex == shopIndex
            val canAfford = owned || starPoints >= skin.requiredPoints
            val textLeft = left + 63f * unit
            val actionLeft = left + w - 105f * unit
            text(c, skin.title, textLeft, rowTop + 15f * unit, 8.5f * unit, WHITE, true, Paint.Align.LEFT)
            val detail = when {
                selected -> "EQUIPPED · ${skin.description}"
                owned -> "OWNED · ${skin.description}"
                else -> skin.description
            }
            text(c, detail.take(34), textLeft, rowTop + 29f * unit, 6.5f * unit, MUTED, false, Paint.Align.LEFT)
            val status = when {
                selected -> "EQUIPPED"
                owned -> "OWNED · EQUIP"
                canAfford -> "UNLOCK · ${formatPoints(skin.requiredPoints)} PTS"
                else -> "${formatPoints(skin.requiredPoints)} PTS"
            }
            text(c, status, actionLeft + 52f * unit, rowTop + 19f * unit, 6.8f * unit,
                if (selected) skin.color else if (canAfford) GOLD else MUTED, true)
            if (!canAfford) text(c, "${formatPoints(skin.requiredPoints - starPoints)} MORE", actionLeft + 52f * unit,
                rowTop + 34f * unit, 6.2f * unit, MUTED, false)
            // Register only an action that can actually equip or buy the item.
            if (canAfford && !selected) registerTarget(shopPurchaseActions[shopIndex], left, rowTop, left + w, rowTop + rowHeight)
        }
        text(c, "COSMETIC ONLY · NO GAMEPLAY ADVANTAGE", screenW / 2f,
            screenH * 0.718f, 7.4f * unit, MUTED, true)
        drawButton(c, "⌂  BACK TO HOME", "", screenW / 2f, screenH * 0.765f,
            w, 40f * unit, ButtonAction.BACK, ButtonStyle.SECONDARY, true, 10f * unit)
    }

    private fun drawMissions(c: Canvas) {
        drawPageHeading(c, "DAILY MISSIONS", "Complete goals today to earn Star Points")
        val w = min(screenW - 32f * unit, 342f * unit)
        drawMissionCard(c, screenH * 0.225f, w, 82f * unit, "STAR COLLECTOR", "Collect 10 stars", dailyStars.coerceAtMost(10), 10, dailyClaimedStars, ButtonAction.CLAIM_STARS, 300)
        drawMissionCard(c, screenH * 0.355f, w, 82f * unit, "STAY IN ORBIT", "Survive 45 seconds in one run", dailySurvival.coerceAtMost(45), 45, dailyClaimedSurvive, ButtonAction.CLAIM_SURVIVE, 500)
        drawMissionCard(c, screenH * 0.485f, w, 82f * unit, "SCORE CHASER", "Reach 400 score in a run", dailyScore.coerceAtMost(400), 400, dailyClaimedScore, ButtonAction.CLAIM_SCORE, 400)
        text(c, "PROGRESS RESETS EACH NEW LOCAL DAY", screenW / 2f, screenH * 0.63f, 8f * unit, MUTED, true)
        drawButton(c, "BACK TO HOME", "", screenW / 2f, screenH * 0.70f, min(screenW - 44f * unit, 330f * unit), 44f * unit,
            ButtonAction.BACK, ButtonStyle.SECONDARY, true, 10.5f * unit)
    }

    private fun drawMissionCard(c: Canvas, top: Float, width: Float, height: Float,
                                title: String, description: String, progress: Int, goal: Int, claimed: Boolean,
                                action: ButtonAction, reward: Int) {
        val left = (screenW - width) / 2f
        panelRect.set(left, top, left + width, top + height)
        fillPaint.color = PANEL
        c.drawRoundRect(panelRect, 13f * unit, 13f * unit, fillPaint)
        strokePaint.color = Color.argb(70, 127, 119, 220)
        strokePaint.strokeWidth = unit
        c.drawRoundRect(panelRect, 13f * unit, 13f * unit, strokePaint)
        text(c, title, left + 13f * unit, top + 17f * unit, 9.3f * unit, WHITE, true, Paint.Align.LEFT)
        text(c, description, left + 13f * unit, top + 34f * unit, 7.7f * unit, MUTED, false, Paint.Align.LEFT)
        val barLeft = left + 13f * unit
        val barRight = left + width - 91f * unit
        rect.set(barLeft, top + 54f * unit, barRight, top + 59f * unit)
        fillPaint.color = Color.argb(42, 172, 180, 218)
        c.drawRoundRect(rect, 3f * unit, 3f * unit, fillPaint)
        rect.set(barLeft, top + 54f * unit, barLeft + (barRight - barLeft) * (progress.toFloat() / goal.toFloat()).coerceIn(0f, 1f), top + 59f * unit)
        fillPaint.color = CYAN
        c.drawRoundRect(rect, 3f * unit, 3f * unit, fillPaint)
        text(c, "$progress/$goal", (barLeft + barRight) / 2f, top + 67f * unit, 7f * unit, WHITE, true)
        val complete = progress >= goal
        val claimLabel = when { claimed -> "CLAIMED"; complete -> "CLAIM +$reward PTS"; else -> "✦ $reward PTS" }
        val claimStyle = when { claimed -> ButtonStyle.DISABLED; complete -> ButtonStyle.PRIMARY; else -> ButtonStyle.DISABLED }
        drawButton(c, claimLabel, "", left + width - 49f * unit, top + 28f * unit, 82f * unit, 31f * unit,
            action, claimStyle, complete && !claimed, 7.7f * unit)
    }

    private fun drawPageHeading(c: Canvas, title: String, subtitle: String) {
        drawTopBack(c)
        text(c, title, screenW / 2f, 31f * unit, 12f * unit, WHITE, true)
        text(c, subtitle, screenW / 2f, screenH * 0.145f, 9f * unit, MUTED, false)
    }

    private fun drawPanel(c: Canvas, x: Float, y: Float, width: Float, height: Float) {
        rect.set(x, y, x + width, y + height)
        fillPaint.color = PANEL
        c.drawRoundRect(rect, 23f * unit, 23f * unit, fillPaint)
        strokePaint.color = Color.argb(130, 129, 115, 255)
        strokePaint.strokeWidth = 1.1f * unit
        c.drawRoundRect(rect, 23f * unit, 23f * unit, strokePaint)
        fillPaint.color = Color.argb(18, 94, 240, 255)
        rect.set(x + 1f * unit, y + 1f * unit, x + width - 1f * unit, y + 4f * unit)
        c.drawRoundRect(rect, 2f * unit, 2f * unit, fillPaint)
    }

    private fun drawButton(c: Canvas, label: String, subtitle: String, centerX: Float, top: Float,
                           width: Float, height: Float, action: ButtonAction, style: ButtonStyle,
                           enabled: Boolean, fontSize: Float = 10.5f * unit, accentColor: Int = LAVENDER) {
        val left = centerX - width / 2f
        rect.set(left, top, left + width, top + height)
        fillPaint.color = when (style) {
            ButtonStyle.PRIMARY -> Color.rgb(77, 79, 220)
            ButtonStyle.SECONDARY -> Color.argb(23, 171, 180, 255)
            ButtonStyle.SELECTED -> Color.argb(42, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            ButtonStyle.DANGER -> Color.argb(35, 255, 79, 131)
            ButtonStyle.DISABLED -> Color.argb(11, 170, 177, 214)
        }
        c.drawRoundRect(rect, 13f * unit, 13f * unit, fillPaint)
        if (style == ButtonStyle.PRIMARY && effectiveGraphicsLevel() >= 1) {
            fillPaint.color = Color.argb(20, 99, 239, 255)
            c.drawRoundRect(rect, 13f * unit, 13f * unit, fillPaint)
        }
        strokePaint.color = when (style) {
            ButtonStyle.PRIMARY -> Color.argb(125, 180, 180, 255)
            ButtonStyle.SECONDARY -> Color.argb(68, 161, 172, 235)
            ButtonStyle.SELECTED -> Color.argb(155, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            ButtonStyle.DANGER -> Color.argb(110, 255, 107, 150)
            ButtonStyle.DISABLED -> Color.argb(30, 167, 176, 220)
        }
        strokePaint.strokeWidth = unit
        c.drawRoundRect(rect, 13f * unit, 13f * unit, strokePaint)
        val titleColor = if (style == ButtonStyle.DISABLED) Color.rgb(104, 111, 145) else WHITE
        if (subtitle.isBlank()) {
            text(c, label, centerX, top + height / 2f, fontSize, titleColor, true)
        } else {
            text(c, label, centerX, top + height * 0.40f, fontSize, titleColor, true)
            text(c, subtitle, centerX, top + height * 0.72f, (fontSize * 0.72f).coerceAtLeast(7f * unit),
                if (style == ButtonStyle.DISABLED) Color.rgb(88, 95, 125) else Color.rgb(180, 188, 221), false)
        }
        if (enabled && action != ButtonAction.NONE) registerTarget(action, left, top, left + width, top + height)
    }

    private fun drawPill(c: Canvas, left: Float, top: Float, width: Float, height: Float, label: String,
                         fill: Int, border: Int, color: Int, size: Float) {
        rect.set(left, top, left + width, top + height)
        fillPaint.color = fill
        c.drawRoundRect(rect, height / 2f, height / 2f, fillPaint)
        strokePaint.color = border
        strokePaint.strokeWidth = unit
        c.drawRoundRect(rect, height / 2f, height / 2f, strokePaint)
        text(c, label, left + width / 2f, top + height / 2f, size, color, true)
    }

    private fun drawRing(c: Canvas, cx: Float, cy: Float, radius: Float, color: Int, width: Float) {
        strokePaint.color = color
        strokePaint.strokeWidth = width
        strokePaint.pathEffect = null
        c.drawCircle(cx, cy, radius, strokePaint)
    }

    private fun drawGlow(c: Canvas, x: Float, y: Float, radius: Float, color: Int) {
        val alpha = Color.alpha(color)
        val layers = when (effectiveGraphicsLevel()) { 0 -> 1; 1 -> 3; else -> 4 }
        for (i in 0 until layers) {
            val divisor = if (layers == 1) 1f else layers.toFloat()
            val layerRadius = radius * (2.2f - i * (1.1f / max(1, layers - 1)))
            fillPaint.color = Color.argb((alpha * (0.10f + (i / divisor) * 0.10f)).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
            c.drawCircle(x, y, layerRadius, fillPaint)
        }
        fillPaint.color = color
        c.drawCircle(x, y, radius, fillPaint)
    }

    private fun text(c: Canvas, value: String, x: Float, y: Float, size: Float, color: Int,
                     bold: Boolean, align: Paint.Align = Paint.Align.CENTER) {
        textPaint.color = color
        textPaint.textSize = size * 1.045f
        textPaint.textAlign = align
        textPaint.typeface = if (bold) boldTypeface else regularTypeface
        val baseline = y - (textPaint.ascent() + textPaint.descent()) / 2f
        c.drawText(value, x, baseline, textPaint)
    }

    private fun registerTarget(action: ButtonAction, left: Float, top: Float, right: Float, bottom: Float) {
        val target = if (hitTargetCount < hitTargets.size) hitTargets[hitTargetCount] else HitTarget().also { hitTargets.add(it) }
        target.action = action
        target.bounds.set(left, top, right, bottom)
        hitTargetCount++
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activeVolumeSlider = null
                for (i in hitTargetCount - 1 downTo 0) {
                    val target = hitTargets[i]
                    if ((target.action == ButtonAction.MUSIC_VOLUME_SLIDER || target.action == ButtonAction.EFFECTS_VOLUME_SLIDER) &&
                        target.bounds.contains(event.x, event.y)) {
                        activeVolumeSlider = target.action
                        updateVolumeFromTouch(target.action, event.x)
                        invalidate()
                        return true
                    }
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val slider = activeVolumeSlider
                if (slider != null) {
                    updateVolumeFromTouch(slider, event.x)
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (activeVolumeSlider != null) audio.persistVolumes()
                activeVolumeSlider = null
                return true
            }
            MotionEvent.ACTION_UP -> {
                val slider = activeVolumeSlider
                if (slider != null) {
                    updateVolumeFromTouch(slider, event.x, persist = true)
                    activeVolumeSlider = null
                    performClick()
                    audio.play(OrbitAudio.Effect.CLICK)
                    invalidate()
                    return true
                }
                for (i in hitTargetCount - 1 downTo 0) {
                    val target = hitTargets[i]
                    if (target.bounds.contains(event.x, event.y)) {
                        performClick()
                        dispatch(target.action)
                        invalidate()
                        return true
                    }
                }
                if (scene == Scene.PLAYING) {
                    switchLane()
                    invalidate()
                }
                performClick()
                return true
            }
        }
        return true
    }

    private fun updateVolumeFromTouch(action: ButtonAction, x: Float, persist: Boolean = false) {
        val left = screenW * 0.17f
        val right = screenW * 0.83f
        val value = ((x - left) / max(1f, right - left)).coerceIn(0f, 1f)
        when (action) {
            ButtonAction.MUSIC_VOLUME_SLIDER -> audio.setMusicVolume(value, persist)
            ButtonAction.EFFECTS_VOLUME_SLIDER -> audio.setEffectsVolume(value, persist)
            else -> Unit
        }
    }

    private fun dispatch(action: ButtonAction) {
        val hasOwnFeedback = action == ButtonAction.TOGGLE_MUSIC || action == ButtonAction.TOGGLE_EFFECTS ||
            action == ButtonAction.NEW_GAME || action == ButtonAction.CONTINUE || action == ButtonAction.RESUME ||
            action == ButtonAction.RESTART || action == ButtonAction.SHOP_ICE || action == ButtonAction.SHOP_SOLAR ||
            action == ButtonAction.SHOP_NEBULA || action == ButtonAction.SHOP_AURORA || action == ButtonAction.SHOP_STARBURST || action == ButtonAction.SHOP_ECLIPSE ||
            action == ButtonAction.CLAIM_STARS || action == ButtonAction.CLAIM_SURVIVE || action == ButtonAction.CLAIM_SCORE
        if (!hasOwnFeedback) audio.play(OrbitAudio.Effect.CLICK)
        when (action) {
            ButtonAction.NEW_GAME -> startNewGame()
            ButtonAction.CONTINUE -> if (restoreSavedRun()) startResumeCountdown()
            ButtonAction.OPEN_SCORES -> { ensureDailyMissionsCurrent(); scene = Scene.SCORES }
            ButtonAction.OPEN_CUSTOMIZE -> scene = Scene.CUSTOMIZE
            ButtonAction.OPEN_MISSIONS -> { ensureDailyMissionsCurrent(); scene = Scene.MISSIONS }
            ButtonAction.OPEN_SETTINGS -> scene = Scene.SETTINGS
            ButtonAction.OPEN_THEMES -> scene = Scene.THEMES
            ButtonAction.OPEN_ABOUT -> scene = Scene.ABOUT_US
            ButtonAction.PROFILE_CONTINUE -> post { showProfileSetupDialog() }
            ButtonAction.SELECT_THEME_NEBULA -> setTheme(WorldTheme.COSMIC_NEBULA)
            ButtonAction.SELECT_THEME_FRONTIER -> setTheme(WorldTheme.CELESTIAL_FRONTIER)
            ButtonAction.SELECT_THEME_HEAVENLY -> setTheme(WorldTheme.HEAVENLY_REALMS)
            ButtonAction.TOGGLE_MUSIC -> audio.toggleMusic()
            ButtonAction.TOGGLE_EFFECTS -> audio.toggleEffects()
            ButtonAction.MUSIC_PREVIOUS -> audio.changeMusicTrack(-1)
            ButtonAction.MUSIC_NEXT -> audio.changeMusicTrack(1)
            ButtonAction.MUSIC_VOLUME_SLIDER, ButtonAction.EFFECTS_VOLUME_SLIDER -> Unit
            ButtonAction.SELECT_EASY -> selectDifficulty(Difficulty.EASY)
            ButtonAction.SELECT_NORMAL -> selectDifficulty(Difficulty.NORMAL)
            ButtonAction.SELECT_HARD -> selectDifficulty(Difficulty.HARD)
            ButtonAction.GRAPHICS_AUTO -> setGraphicsQuality(GraphicsQuality.AUTO)
            ButtonAction.GRAPHICS_LOW -> setGraphicsQuality(GraphicsQuality.LOW)
            ButtonAction.GRAPHICS_HIGH -> setGraphicsQuality(GraphicsQuality.HIGH)
            ButtonAction.BACK -> scene = Scene.HOME
            ButtonAction.PAUSE -> {
                if (scene == Scene.PLAYING || scene == Scene.COUNTDOWN) {
                    saveCurrentRun()
                    scene = Scene.PAUSED
                }
            }
            ButtonAction.RESUME -> startResumeCountdown()
            ButtonAction.RESTART -> startNewGame()
            ButtonAction.HOME -> {
                if (scene == Scene.PAUSED || scene == Scene.PLAYING || scene == Scene.COUNTDOWN) saveCurrentRun()
                scene = Scene.HOME
            }
            ButtonAction.EXIT -> (context as? Activity)?.finish()
            ButtonAction.SHOP_NEBULA -> purchaseOrEquipSkin(0)
            ButtonAction.SHOP_ICE -> purchaseOrEquipSkin(1)
            ButtonAction.SHOP_SOLAR -> purchaseOrEquipSkin(2)
            ButtonAction.SHOP_AURORA -> purchaseOrEquipSkin(3)
            ButtonAction.SHOP_STARBURST -> purchaseOrEquipSkin(4)
            ButtonAction.SHOP_ECLIPSE -> purchaseOrEquipSkin(5)
            ButtonAction.CLAIM_STARS -> claimMission(0)
            ButtonAction.CLAIM_SURVIVE -> claimMission(1)
            ButtonAction.CLAIM_SCORE -> claimMission(2)
            ButtonAction.NONE -> Unit
        }
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onDetachedFromWindow() {
        running = false
        lastFrameNs = 0L
        super.onDetachedFromWindow()
    }

    companion object {
        private val BG = Color.rgb(7, 9, 20)
        private val PANEL = Color.rgb(18, 22, 49)
        private val WHITE = Color.rgb(247, 248, 255)
        private val MUTED = Color.rgb(174, 185, 220)
        private val LAVENDER = Color.rgb(161, 136, 255)
        private val CYAN = Color.rgb(100, 239, 255)
        private val PINK = Color.rgb(255, 79, 131)
        private val GOLD = Color.rgb(255, 214, 107)
    }
}
