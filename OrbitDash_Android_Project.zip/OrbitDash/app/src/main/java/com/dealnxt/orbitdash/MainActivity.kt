package com.dealnxt.orbitdash

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var gameView: OrbitDashView
    private lateinit var audio: OrbitAudio

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 9, 20)
        window.navigationBarColor = Color.rgb(7, 9, 20)
        hideSystemBars()
        audio = OrbitAudio(this)
        gameView = OrbitDashView(this, audio)
        setContentView(gameView)
    }

    override fun onResume() {
        super.onResume()
        if (::audio.isInitialized) audio.onHostResume()
        if (::gameView.isInitialized) gameView.resumeGameLoop()
        hideSystemBars()
    }

    override fun onPause() {
        if (::gameView.isInitialized) gameView.pauseForHost()
        if (::audio.isInitialized) audio.onHostPause()
        super.onPause()
    }

    override fun onDestroy() {
        if (::audio.isInitialized) audio.release()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    @Deprecated("Deprecated by Android; kept for compatibility with older API levels")
    override fun onBackPressed() {
        if (::gameView.isInitialized && gameView.handleBack()) return
        super.onBackPressed()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }
}

private class OrbitDashView(context: Context, private val audio: OrbitAudio) : View(context) {
    private enum class Scene { HOME, PLAYING, COUNTDOWN, PAUSED, OVER, SETTINGS, DIFFICULTY, SCORES, CUSTOMIZE, MISSIONS }
    private enum class ButtonAction {
        NONE, NEW_GAME, CONTINUE, OPEN_DIFFICULTY, OPEN_SCORES, OPEN_CUSTOMIZE, OPEN_MISSIONS, OPEN_SETTINGS,
        TOGGLE_MUSIC, TOGGLE_EFFECTS, SELECT_EASY, SELECT_NORMAL, SELECT_HARD, GRAPHICS_AUTO, GRAPHICS_LOW, GRAPHICS_HIGH,
        BACK, PAUSE, RESUME, RESTART, HOME, EXIT, SKIN_NEBULA, SKIN_ICE, SKIN_SOLAR,
        CLAIM_STARS, CLAIM_SURVIVE, CLAIM_SCORE
    }
    private enum class ButtonStyle { PRIMARY, SECONDARY, SELECTED, DANGER, DISABLED }
    private enum class Difficulty(val key: String, val title: String, val description: String,
                                  val startSpeed: Float, val maxSpeed: Float, val speedGain: Float,
                                  val spawnStart: Float, val spawnFloor: Float, val scoreRate: Float) {
        EASY("easy", "EASY", "More room to react · slower hazards", 0.92f, 1.72f, 0.015f, 1.28f, 0.86f, 7f),
        NORMAL("normal", "NORMAL", "Balanced challenge · steady progression", 1.12f, 2.42f, 0.025f, 1.05f, 0.64f, 8f),
        HARD("hard", "HARD", "Fast hazards · sharp timing required", 1.32f, 3.02f, 0.034f, 0.92f, 0.51f, 10f);

        companion object {
            fun fromKey(key: String?): Difficulty = entries.firstOrNull { it.key == key } ?: NORMAL
        }
    }
    private enum class GraphicsQuality(val key: String, val title: String) {
        AUTO("auto", "AUTO"), LOW("low", "LOW"), HIGH("high", "HIGH");
        companion object {
            fun fromKey(key: String?): GraphicsQuality = entries.firstOrNull { it.key == key } ?: AUTO
        }
    }
    private data class Star(val x: Float, val y: Float, val radius: Float, val alpha: Float, val phase: Float, val twinkle: Float)
    private data class Obstacle(val lane: Int, var distance: Float, var spin: Float, val gem: Boolean, var resolved: Boolean = false)
    private data class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val maxLife: Float, val radius: Float, val color: Int)
    private class HitTarget {
        val bounds = RectF()
        var action: ButtonAction = ButtonAction.NONE
    }
    private data class Skin(val title: String, val color: Int, val requiredStars: Int)

    private val prefs = context.getSharedPreferences("orbit_dash_settings", Context.MODE_PRIVATE)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f }
    private val regularTypeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val boldTypeface = Typeface.create("sans-serif", Typeface.BOLD)
    private val rect = RectF()
    private val panelRect = RectF()
    private val hazardPath = Path().apply {
        moveTo(0f, -9f); lineTo(7.5f, -2f); lineTo(5.5f, 7f); lineTo(-5.5f, 7f); lineTo(-7.5f, -2f); close()
    }
    private val gemPath = Path().apply {
        moveTo(0f, -8f); lineTo(3f, -3f); lineTo(8f, 0f); lineTo(3f, 3f)
        lineTo(0f, 8f); lineTo(-3f, 3f); lineTo(-8f, 0f); lineTo(-3f, -3f); close()
    }
    private val shipSkins = listOf(
        Skin("NEBULA", Color.rgb(174, 135, 255), 0),
        Skin("ICE COMET", Color.rgb(86, 235, 255), 100),
        Skin("SOLAR FLARE", Color.rgb(255, 190, 91), 250)
    )
    private val hitTargets = ArrayList<HitTarget>(24)
    private var hitTargetCount = 0
    private var scoreHistory: List<Int> = readScoreHistory()
    private var savedRunAvailable = prefs.getBoolean("run_saved", false)
    private val hazards = ArrayList<Obstacle>(12)
    private val particles = ArrayList<Particle>(100)
    private var stars: List<Star> = emptyList()

    private var scene = Scene.HOME
    private var screenW = 1f
    private var screenH = 1f
    private var unit = 1f
    private var running = false
    private var lastFrameNs = 0L
    private var elapsed = 0f
    private var backgroundTime = 0f
    private var angle = (-PI / 2.0).toFloat()
    private var speed = Difficulty.NORMAL.startSpeed
    private var lane = 0
    private var score = 0
    private var best = prefs.getInt("best_score", 0).coerceAtLeast(0)
    private var lastScore = prefs.getInt("last_score", 0).coerceAtLeast(0)
    private var totalRuns = prefs.getInt("total_runs", 0).coerceAtLeast(0)
    private var gems = 0
    private var bankedStars = prefs.getInt("banked_stars", 0).coerceAtLeast(0)
    private var spawnTimer = 0.70f
    private var spawnIndex = 0
    private var lastHazardLane = 1
    private var lastSwitch = 0f
    private var gameOverReason = "HAZARD HIT"
    private var isNewBestRun = false
    private var resumeCountdown = 0f
    private var dailyStars = 0
    private var dailySurvival = 0
    private var dailyScore = 0
    private var dailyClaimedStars = false
    private var dailyClaimedSurvive = false
    private var dailyClaimedScore = false
    private var lastDailyDateCheckAt = 0f
    private var selectedSkinIndex = prefs.getInt("selected_skin", 0).coerceIn(0, 2)
    private var difficulty = Difficulty.fromKey(prefs.getString("difficulty", "normal"))
    private var graphicsQuality = GraphicsQuality.fromKey(prefs.getString("graphics_quality", "auto"))
    private val autoGraphicsLevel: Int by lazy {
        try {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val info = ActivityManager.MemoryInfo()
            manager?.getMemoryInfo(info)
            if ((info.totalMem >= 4L * 1024L * 1024L * 1024L) && Runtime.getRuntime().availableProcessors() >= 6) 2 else 1
        } catch (_: Exception) { 1 }
    }

    init {
        isClickable = true
        isFocusable = true
        contentDescription = "Orbit Dash arcade game"
        setBackgroundColor(Color.rgb(7, 9, 20))
        ensureDailyMissionsCurrent()
    }

    fun resumeGameLoop() {
        if (!running) {
            running = true
            lastFrameNs = 0L
            postInvalidateOnAnimation()
        }
    }

    fun pauseForHost() {
        if (scene == Scene.PLAYING || scene == Scene.COUNTDOWN) {
            saveCurrentRun()
            scene = Scene.PAUSED
        }
        running = false
        lastFrameNs = 0L
    }

    fun handleBack(): Boolean {
        when (scene) {
            Scene.PLAYING, Scene.COUNTDOWN -> {
                saveCurrentRun()
                scene = Scene.PAUSED
                audio.play(OrbitAudio.Effect.CLICK)
            }
            Scene.PAUSED -> {
                saveCurrentRun()
                scene = Scene.HOME
            }
            Scene.OVER -> scene = Scene.HOME
            Scene.SETTINGS, Scene.DIFFICULTY, Scene.SCORES, Scene.CUSTOMIZE, Scene.MISSIONS -> scene = Scene.HOME
            Scene.HOME -> return false
        }
        invalidate()
        return true
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        screenW = max(1, w).toFloat()
        screenH = max(1, h).toFloat()
        unit = (screenW / 390f).coerceIn(0.72f, 3.2f)
        rebuildStarfield()
    }

    private fun rebuildStarfield() {
        val factor = when (effectiveGraphicsLevel()) { 0 -> 0.42f; 1 -> 0.72f; else -> 1f }
        val count = (screenW * screenH / (22000f * unit * unit) * factor).toInt().coerceIn(18, 88)
        stars = List(count) {
            Star(Random.nextFloat() * screenW, Random.nextFloat() * screenH,
                (0.45f + Random.nextFloat() * 1.2f) * unit,
                0.12f + Random.nextFloat() * 0.58f,
                Random.nextFloat() * (2f * PI.toFloat()), 0.6f + Random.nextFloat() * 1.6f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        hitTargetCount = 0
        val now = System.nanoTime()
        val dt = if (lastFrameNs == 0L) 0f else ((now - lastFrameNs) / 1_000_000_000f).coerceIn(0f, 0.033f)
        lastFrameNs = now
        if (running) update(dt)
        val shouldKeepScreenOn = scene == Scene.PLAYING || scene == Scene.COUNTDOWN
        if (keepScreenOn != shouldKeepScreenOn) keepScreenOn = shouldKeepScreenOn
        drawBackground(canvas)
        val time = now / 1_000_000_000f
        when (scene) {
            Scene.HOME -> drawHome(canvas, time)
            Scene.PLAYING -> drawPlaying(canvas, time, true)
            Scene.COUNTDOWN -> drawCountdown(canvas, time)
            Scene.PAUSED -> drawPaused(canvas, time)
            Scene.OVER -> drawGameOver(canvas, time)
            Scene.SETTINGS -> drawSettings(canvas)
            Scene.DIFFICULTY -> drawDifficulty(canvas)
            Scene.SCORES -> drawScores(canvas)
            Scene.CUSTOMIZE -> drawCustomize(canvas, time)
            Scene.MISSIONS -> drawMissions(canvas)
        }
        if (running) postInvalidateOnAnimation()
    }

    private fun update(dt: Float) {
        if (dt <= 0f) return
        backgroundTime += dt
        var pi = particles.size - 1
        while (pi >= 0) {
            val p = particles[pi]
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vx *= 0.94f
            p.vy *= 0.94f
            p.life -= dt
            if (p.life <= 0f) particles.removeAt(pi)
            pi--
        }
        lastSwitch = max(0f, lastSwitch - dt)
        if (scene == Scene.COUNTDOWN) {
            resumeCountdown -= dt
            if (resumeCountdown <= 0f) {
                scene = Scene.PLAYING
                resumeCountdown = 0f
            }
            return
        }
        if (scene != Scene.PLAYING) return

        elapsed += dt
        speed = min(difficulty.maxSpeed, difficulty.startSpeed + elapsed * difficulty.speedGain)
        angle = (angle + speed * dt) % (2f * PI.toFloat())
        score = floor(elapsed * difficulty.scoreRate + gems * 25f).toInt()
        if (elapsed - lastDailyDateCheckAt >= 10f) {
            ensureDailyMissionsCurrent()
            lastDailyDateCheckAt = elapsed
        }
        updateDailyProgress()
        spawnTimer -= dt
        if (spawnTimer <= 0f) {
            spawnObject()
            spawnTimer = max(difficulty.spawnFloor, difficulty.spawnStart - elapsed * 0.0032f) + Random.nextFloat() * 0.20f - 0.09f
        }

        var i = hazards.size - 1
        while (i >= 0) {
            val o = hazards[i]
            o.distance -= speed * dt
            o.spin += dt * 2.8f
            if (!o.resolved && o.distance <= 0.11f) {
                o.resolved = true
                if (!o.gem && o.lane == lane) {
                    endGame("HAZARD HIT")
                    break
                } else if (o.gem && o.lane == lane) {
                    gems++
                    bankedStars++
                    dailyStars++
                    score = floor(elapsed * difficulty.scoreRate + gems * 25f).toInt()
                    prefs.edit().putInt("banked_stars", bankedStars).putInt("daily_stars", dailyStars).apply()
                    val geo = orbitGeometry()
                    val r = if (lane == 1) geo.outer else geo.inner
                    addParticles(geo.cx + cos(angle) * r, geo.cy + sin(angle) * r, 12, GOLD, 0.8f)
                    audio.play(OrbitAudio.Effect.COLLECT)
                }
            }
            if (o.distance <= -0.32f || (scene == Scene.OVER && o.resolved)) hazards.removeAt(i)
            i--
        }
    }

    private fun spawnObject() {
        spawnIndex++
        val distance = 2.05f + Random.nextFloat() * 0.55f
        if (spawnIndex % 5 == 0 || Random.nextFloat() < 0.14f) {
            hazards.add(Obstacle(if (Random.nextBoolean()) 1 else 0, distance, Random.nextFloat() * 6.28f, true))
        } else {
            lastHazardLane = 1 - lastHazardLane
            hazards.add(Obstacle(lastHazardLane, distance, Random.nextFloat() * 6.28f, false))
        }
    }

    private fun startNewGame() {
        difficulty = Difficulty.fromKey(prefs.getString("difficulty", difficulty.key))
        elapsed = 0f
        angle = (-PI / 2.0).toFloat()
        speed = difficulty.startSpeed
        lane = 0
        score = 0
        gems = 0
        spawnTimer = 0.72f
        spawnIndex = 0
        lastHazardLane = 1
        lastSwitch = 0f
        hazards.clear()
        particles.clear()
        clearRunSave()
        scene = Scene.PLAYING
        isNewBestRun = false
        audio.play(OrbitAudio.Effect.START)
    }

    private fun startResumeCountdown() {
        scene = Scene.COUNTDOWN
        resumeCountdown = 3f
        clearRunSave()
        audio.play(OrbitAudio.Effect.START)
    }

    private fun endGame(reason: String) {
        if (scene != Scene.PLAYING) return
        scene = Scene.OVER
        gameOverReason = reason
        lastScore = score.coerceAtLeast(0)
        totalRuns++
        isNewBestRun = score > best
        if (isNewBestRun) best = score
        val history = scoreHistory.toMutableList()
        history.add(score.coerceAtLeast(0))
        val top = history.sortedDescending().take(5)
        scoreHistory = top
        prefs.edit()
            .putInt("best_score", best)
            .putInt("last_score", lastScore)
            .putInt("total_runs", totalRuns)
            .putString("top_scores", top.joinToString(","))
            .apply()
        clearRunSave()
        val geo = orbitGeometry()
        val r = if (lane == 1) geo.outer else geo.inner
        addParticles(geo.cx + cos(angle) * r, geo.cy + sin(angle) * r, 24, PINK, 1f)
        audio.play(OrbitAudio.Effect.CRASH)
    }

    private fun switchLane() {
        if (scene != Scene.PLAYING) return
        lane = 1 - lane
        lastSwitch = 0.22f
        val geo = orbitGeometry()
        val r = if (lane == 1) geo.outer else geo.inner
        addParticles(geo.cx + cos(angle) * r, geo.cy + sin(angle) * r, 6, shipColor(), 0.42f)
        audio.play(OrbitAudio.Effect.SWITCH)
    }

    private fun saveCurrentRun() {
        if (elapsed <= 0f || (scene != Scene.PLAYING && scene != Scene.COUNTDOWN && scene != Scene.PAUSED)) return
        val packedHazards = hazards.joinToString(";") {
            "${it.lane},${it.distance},${it.spin},${it.gem},${it.resolved}"
        }
        savedRunAvailable = true
        prefs.edit()
            .putBoolean("run_saved", true)
            .putFloat("run_elapsed", elapsed)
            .putFloat("run_angle", angle)
            .putFloat("run_speed", speed)
            .putInt("run_lane", lane)
            .putInt("run_score", score)
            .putInt("run_gems", gems)
            .putFloat("run_spawn_timer", spawnTimer)
            .putInt("run_spawn_index", spawnIndex)
            .putInt("run_last_hazard_lane", lastHazardLane)
            .putString("run_difficulty", difficulty.key)
            .putString("run_hazards", packedHazards)
            .apply()
    }

    private fun restoreSavedRun(): Boolean {
        if (!prefs.getBoolean("run_saved", false)) return false
        elapsed = prefs.getFloat("run_elapsed", 0f).coerceAtLeast(0f)
        angle = prefs.getFloat("run_angle", (-PI / 2.0).toFloat())
        speed = prefs.getFloat("run_speed", difficulty.startSpeed).coerceAtLeast(0f)
        lane = prefs.getInt("run_lane", 0).coerceIn(0, 1)
        score = prefs.getInt("run_score", 0).coerceAtLeast(0)
        gems = prefs.getInt("run_gems", 0).coerceAtLeast(0)
        spawnTimer = prefs.getFloat("run_spawn_timer", 0.7f).coerceAtLeast(0.05f)
        spawnIndex = prefs.getInt("run_spawn_index", 0).coerceAtLeast(0)
        lastHazardLane = prefs.getInt("run_last_hazard_lane", 1).coerceIn(0, 1)
        difficulty = Difficulty.fromKey(prefs.getString("run_difficulty", difficulty.key))
        hazards.clear()
        val packed = prefs.getString("run_hazards", "").orEmpty()
        if (packed.isNotBlank()) {
            for (row in packed.split(';')) {
                val parts = row.split(',')
                if (parts.size == 5) {
                    try {
                        hazards.add(Obstacle(parts[0].toInt().coerceIn(0, 1), parts[1].toFloat(), parts[2].toFloat(), parts[3].toBoolean(), parts[4].toBoolean()))
                    } catch (_: Exception) {
                        // Ignore a malformed individual obstacle rather than losing the whole saved run.
                    }
                }
            }
        }
        particles.clear()
        return true
    }

    private fun clearRunSave() {
        savedRunAvailable = false
        prefs.edit().putBoolean("run_saved", false).remove("run_hazards").apply()
    }

    private fun updateDailyProgress() {
        var changed = false
        val alive = elapsed.toInt()
        if (alive > dailySurvival) { dailySurvival = alive; changed = true }
        if (score > dailyScore) { dailyScore = score; changed = true }
        if (changed) prefs.edit().putInt("daily_survival", dailySurvival).putInt("daily_score", dailyScore).apply()
    }

    private fun ensureDailyMissionsCurrent() {
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        if (prefs.getString("daily_date", "") != today) {
            prefs.edit()
                .putString("daily_date", today)
                .putInt("daily_stars", 0)
                .putInt("daily_survival", 0)
                .putInt("daily_score", 0)
                .putBoolean("daily_claim_stars", false)
                .putBoolean("daily_claim_survive", false)
                .putBoolean("daily_claim_score", false)
                .apply()
        }
        dailyStars = prefs.getInt("daily_stars", 0).coerceAtLeast(0)
        dailySurvival = prefs.getInt("daily_survival", 0).coerceAtLeast(0)
        dailyScore = prefs.getInt("daily_score", 0).coerceAtLeast(0)
        dailyClaimedStars = prefs.getBoolean("daily_claim_stars", false)
        dailyClaimedSurvive = prefs.getBoolean("daily_claim_survive", false)
        dailyClaimedScore = prefs.getBoolean("daily_claim_score", false)
    }

    private fun claimMission(which: Int) {
        ensureDailyMissionsCurrent()
        val complete = when (which) { 0 -> dailyStars >= 10; 1 -> dailySurvival >= 45; else -> dailyScore >= 400 }
        val claimed = when (which) { 0 -> dailyClaimedStars; 1 -> dailyClaimedSurvive; else -> dailyClaimedScore }
        if (!complete || claimed) return
        val reward = when (which) { 0 -> 20; 1 -> 20; else -> 30 }
        bankedStars += reward
        when (which) {
            0 -> dailyClaimedStars = true
            1 -> dailyClaimedSurvive = true
            else -> dailyClaimedScore = true
        }
        prefs.edit()
            .putInt("banked_stars", bankedStars)
            .putBoolean("daily_claim_stars", dailyClaimedStars)
            .putBoolean("daily_claim_survive", dailyClaimedSurvive)
            .putBoolean("daily_claim_score", dailyClaimedScore)
            .apply()
        audio.play(OrbitAudio.Effect.REWARD)
    }

    private fun readScoreHistory(): List<Int> = prefs.getString("top_scores", "").orEmpty()
        .split(',').mapNotNull { it.toIntOrNull() }.filter { it >= 0 }.sortedDescending().take(5)

    private fun effectiveGraphicsLevel(): Int = when (graphicsQuality) {
        GraphicsQuality.LOW -> 0
        GraphicsQuality.AUTO -> autoGraphicsLevel
        GraphicsQuality.HIGH -> 2
    }

    private fun setGraphicsQuality(value: GraphicsQuality) {
        graphicsQuality = value
        prefs.edit().putString("graphics_quality", value.key).apply()
        rebuildStarfield()
    }

    private fun selectDifficulty(value: Difficulty) {
        difficulty = value
        prefs.edit().putString("difficulty", value.key).apply()
        scene = Scene.HOME
    }

    private fun shipColor(): Int = shipSkins[selectedSkinIndex].color

    private fun selectSkin(index: Int) {
        if (index !in shipSkins.indices || bankedStars < shipSkins[index].requiredStars) return
        selectedSkinIndex = index
        prefs.edit().putInt("selected_skin", index).apply()
        audio.play(OrbitAudio.Effect.REWARD)
    }

    private fun addParticles(x: Float, y: Float, count: Int, color: Int, force: Float) {
        val maxParticles = when (effectiveGraphicsLevel()) { 0 -> 48; 1 -> 88; else -> 132 }
        val actualCount = when (effectiveGraphicsLevel()) { 0 -> max(3, count / 2); else -> count }
        repeat(actualCount) {
            if (particles.size >= maxParticles) particles.removeAt(0)
            val a = Random.nextFloat() * 2f * PI.toFloat()
            val s = (38f + Random.nextFloat() * 162f) * unit * force
            particles.add(Particle(x, y, cos(a) * s, sin(a) * s,
                0.25f + Random.nextFloat() * 0.4f, 0.65f, (1.5f + Random.nextFloat() * 2f) * unit, color))
        }
    }

    // ----- Drawing: reusable paints/paths and pooled hit targets keep per-frame allocation low. -----

    private fun drawBackground(c: Canvas) {
        c.drawColor(BG)
        val haloRadius = max(screenW, screenH) * 0.39f
        fillPaint.color = Color.argb(if (effectiveGraphicsLevel() == 0) 8 else 15, 81, 64, 180)
        c.drawCircle(screenW * 0.50f, screenH * 0.48f, haloRadius, fillPaint)
        if (effectiveGraphicsLevel() >= 2) {
            fillPaint.color = Color.argb(7, 36, 171, 206)
            c.drawCircle(screenW * 0.24f, screenH * 0.38f, haloRadius * 0.62f, fillPaint)
        }
        for (s in stars) {
            val flicker = (0.65f + sin(s.phase + backgroundTime * s.twinkle) * 0.35f).coerceIn(0.05f, 1f)
            fillPaint.color = Color.argb((s.alpha * flicker * 255).toInt().coerceIn(0, 255), 174, 202, 255)
            c.drawCircle(s.x, s.y, s.radius, fillPaint)
        }
        for (p in particles) {
            val alpha = (p.life / p.maxLife).coerceIn(0f, 1f)
            fillPaint.color = Color.argb((alpha * 210).toInt(), Color.red(p.color), Color.green(p.color), Color.blue(p.color))
            c.drawCircle(p.x, p.y, p.radius, fillPaint)
        }
    }

    private fun drawBrand(c: Canvas, showMusicButton: Boolean) {
        text(c, "ORBIT", 22f * unit, 28f * unit, 12.5f * unit, CYAN, true, Paint.Align.LEFT)
        text(c, "DASH", 66f * unit, 28f * unit, 12.5f * unit, WHITE, true, Paint.Align.LEFT)
        text(c, "NEON ARCADE  ·  OFFLINE", 22f * unit, 47f * unit, 7.5f * unit, MUTED, true, Paint.Align.LEFT)
        if (showMusicButton) drawRoundIcon(c, screenW - 29f * unit, 30f * unit, if (audio.musicEnabled) "♫" else "×", ButtonAction.TOGGLE_MUSIC)
    }

    private fun drawTopBack(c: Canvas) {
        drawRoundIcon(c, 29f * unit, 30f * unit, "‹", ButtonAction.BACK)
    }

    private fun drawRoundIcon(c: Canvas, cx: Float, cy: Float, glyph: String, action: ButtonAction) {
        val r = 17f * unit
        fillPaint.color = Color.argb(24, 255, 255, 255)
        c.drawCircle(cx, cy, r, fillPaint)
        strokePaint.color = Color.argb(85, 133, 149, 220)
        strokePaint.strokeWidth = 1f * unit
        c.drawCircle(cx, cy, r, strokePaint)
        text(c, glyph, cx, cy - 0.5f * unit, 23f * unit, WHITE, true)
        registerTarget(action, cx - 23f * unit, cy - 23f * unit, cx + 23f * unit, cy + 23f * unit)
    }

    private fun drawHome(c: Canvas, time: Float) {
        drawBrand(c, true)
        drawLogoOrbits(c, screenW / 2f, screenH * 0.205f, min(screenW * 0.205f, screenH * 0.085f), time)
        text(c, "JUST ONE MORE RUN", screenW / 2f, screenH * 0.335f, 9.5f * unit, MUTED, true)
        drawPill(c, screenW / 2f - 78f * unit, screenH * 0.355f, 156f * unit, 29f * unit,
            "BEST SCORE  ${best.toString().padStart(4, '0')}", Color.argb(24, 139, 123, 255), Color.argb(90, 139, 123, 255), LAVENDER, 9f * unit)
        val mainW = min(screenW - 44f * unit, 330f * unit)
        val mainH = 46f * unit
        drawButton(c, "▶   NEW GAME", "Start a fresh run", screenW / 2f, screenH * 0.405f, mainW, mainH,
            ButtonAction.NEW_GAME, ButtonStyle.PRIMARY, true)
        val hasSave = savedRunAvailable
        drawButton(c, "↻   CONTINUE", if (hasSave) "Resume your saved run" else "No saved run yet",
            screenW / 2f, screenH * 0.464f, mainW, mainH, ButtonAction.CONTINUE,
            if (hasSave) ButtonStyle.SECONDARY else ButtonStyle.DISABLED, hasSave)
        drawButton(c, "DIFFICULTY  ·  ${difficulty.title}", "Tap to choose your challenge",
            screenW / 2f, screenH * 0.523f, mainW, 39f * unit, ButtonAction.OPEN_DIFFICULTY, ButtonStyle.SECONDARY, true)
        val cardW = screenW * 0.43f
        val cardH = 39f * unit
        val left = screenW * 0.275f
        val right = screenW * 0.725f
        drawButton(c, "HIGH SCORES", "Your records", left, screenH * 0.590f, cardW, cardH, ButtonAction.OPEN_SCORES, ButtonStyle.SECONDARY, true, 9.5f * unit)
        drawButton(c, "SHIP LAB", "Unlock skins", right, screenH * 0.590f, cardW, cardH, ButtonAction.OPEN_CUSTOMIZE, ButtonStyle.SECONDARY, true, 9.5f * unit)
        drawButton(c, "MISSIONS", "Daily rewards", left, screenH * 0.646f, cardW, cardH, ButtonAction.OPEN_MISSIONS, ButtonStyle.SECONDARY, true, 9.5f * unit)
        drawButton(c, "SETTINGS", "Sound & graphics", right, screenH * 0.646f, cardW, cardH, ButtonAction.OPEN_SETTINGS, ButtonStyle.SECONDARY, true, 9.5f * unit)
        text(c, "TWO ORBITS. ONE MORE CHANCE.", screenW / 2f, screenH * 0.925f, 8.5f * unit, Color.rgb(101, 111, 153), true)
    }

    private fun drawLogoOrbits(c: Canvas, cx: Float, cy: Float, radius: Float, time: Float) {
        drawGlow(c, cx, cy, 5f * unit, CYAN)
        drawRing(c, cx, cy, radius * 0.63f, Color.argb(175, 97, 228, 255), 1.2f * unit)
        drawRing(c, cx, cy, radius, Color.argb(160, 150, 120, 255), 1.45f * unit)
        drawRing(c, cx, cy, radius * 1.30f, Color.argb(72, 94, 103, 193), 1f * unit)
        repeat(3) { i ->
            val a = time * (0.47f + i * 0.08f) + i * 2f * PI.toFloat() / 3f
            val r = if (i % 2 == 0) radius else radius * 0.63f
            drawGlow(c, cx + cos(a) * r, cy + sin(a) * r, (2.4f + i * 0.3f) * unit, if (i == 1) CYAN else LAVENDER)
        }
    }

    private fun drawPlaying(c: Canvas, time: Float, allowPause: Boolean) {
        drawGameHud(c, allowPause)
        drawOrbitScene(c, time)
        text(c, "TAP TO SWITCH ORBITS", screenW / 2f, screenH * 0.825f, 10f * unit, Color.rgb(213, 217, 244), true)
        text(c, "Avoid pink hazards  ·  Collect gold stars", screenW / 2f, screenH * 0.855f, 9.5f * unit, Color.rgb(119, 127, 166), false)
        val level = min(5, (elapsed / 12f).toInt())
        val segmentW = 9f * unit
        repeat(5) { i ->
            fillPaint.color = if (i <= level) LAVENDER else Color.argb(54, 124, 134, 180)
            val x = screenW / 2f - 31f * unit + i * 14f * unit
            c.drawRoundRect(x, screenH * 0.895f, x + segmentW, screenH * 0.895f + 3f * unit, 1.5f * unit, 1.5f * unit, fillPaint)
        }
    }

    private fun drawGameHud(c: Canvas, allowPause: Boolean) {
        text(c, "ORBIT DASH", 22f * unit, 29f * unit, 10.5f * unit, WHITE, true, Paint.Align.LEFT)
        text(c, difficulty.title, 22f * unit, 45f * unit, 7.5f * unit, MUTED, true, Paint.Align.LEFT)
        text(c, score.toString().padStart(4, '0'), screenW / 2f, 49f * unit, 25f * unit, WHITE, true)
        text(c, "SCORE", screenW / 2f, 70f * unit, 8f * unit, MUTED, true)
        text(c, "✦ $gems", screenW - 66f * unit, 59f * unit, 10f * unit, GOLD, true, Paint.Align.RIGHT)
        if (allowPause) {
            drawRoundIcon(c, screenW - 78f * unit, 30f * unit, if (audio.musicEnabled) "♫" else "×", ButtonAction.TOGGLE_MUSIC)
            drawRoundIcon(c, screenW - 28f * unit, 30f * unit, "Ⅱ", ButtonAction.PAUSE)
        }
    }

    private fun drawOrbitScene(c: Canvas, time: Float) {
        val geo = orbitGeometry()
        fillPaint.color = Color.argb(14, 66, 49, 143)
        c.drawCircle(geo.cx, geo.cy, geo.outer * 1.5f, fillPaint)
        if (effectiveGraphicsLevel() >= 1) drawRing(c, geo.cx, geo.cy, geo.outer + 2f * unit, Color.argb(20, 126, 100, 255), 5f * unit)
        drawRing(c, geo.cx, geo.cy, geo.outer, Color.argb(130, 111, 110, 179), 1.3f * unit)
        drawRing(c, geo.cx, geo.cy, geo.inner, Color.argb(122, 111, 110, 179), 1.3f * unit)
        if (effectiveGraphicsLevel() >= 1) {
            strokePaint.color = Color.argb(74, 106, 126, 195)
            strokePaint.strokeWidth = unit
            strokePaint.pathEffect = android.graphics.DashPathEffect(floatArrayOf(2f * unit, 11f * unit), 0f)
            c.drawCircle(geo.cx, geo.cy, geo.outer + 10f * unit, strokePaint)
            strokePaint.pathEffect = null
        }
        repeat(if (effectiveGraphicsLevel() == 0) 4 else 8) { i ->
            val amount = if (effectiveGraphicsLevel() == 0) 4 else 8
            val a = time * 0.12f + i * 2f * PI.toFloat() / amount
            fillPaint.color = Color.argb(150, 126, 132, 218)
            c.drawCircle(geo.cx + cos(a) * (geo.outer + 10f * unit), geo.cy + sin(a) * (geo.outer + 10f * unit), 1.25f * unit, fillPaint)
        }
        fillPaint.color = Color.rgb(24, 22, 52)
        c.drawCircle(geo.cx, geo.cy, 22f * unit, fillPaint)
        strokePaint.color = Color.argb(150, 151, 120, 255)
        strokePaint.strokeWidth = 1.1f * unit
        c.drawCircle(geo.cx, geo.cy, 22f * unit, strokePaint)
        strokePaint.color = Color.argb(145, 166, 129, 255)
        strokePaint.strokeWidth = 2.2f * unit
        c.save(); c.rotate(-time * 20f, geo.cx, geo.cy)
        c.drawOval(geo.cx - 10f * unit, geo.cy - 4f * unit, geo.cx + 10f * unit, geo.cy + 4f * unit, strokePaint)
        c.restore()
        for (o in hazards) {
            val orbitRadius = if (o.lane == 1) geo.outer else geo.inner
            val a = angle + o.distance
            val x = geo.cx + cos(a) * orbitRadius
            val y = geo.cy + sin(a) * orbitRadius
            if (x < -30f * unit || x > screenW + 30f * unit || y < -30f * unit || y > screenH + 30f * unit) continue
            c.save()
            c.translate(x, y)
            c.rotate(o.spin * 57.2958f)
            c.scale(unit, unit)
            if (o.gem) {
                fillPaint.color = GOLD
                c.drawPath(gemPath, fillPaint)
                if (effectiveGraphicsLevel() >= 1) {
                    strokePaint.color = Color.argb(205, 255, 244, 190)
                    strokePaint.strokeWidth = 0.9f
                    c.drawPath(gemPath, strokePaint)
                }
            } else {
                if (effectiveGraphicsLevel() >= 1) drawGlow(c, 0f, 0f, 5f, PINK)
                fillPaint.color = PINK
                c.drawPath(hazardPath, fillPaint)
                strokePaint.color = Color.rgb(255, 209, 223)
                strokePaint.strokeWidth = 0.85f
                c.drawLine(0f, -4f, 0f, 2f, strokePaint)
                fillPaint.color = WHITE
                c.drawCircle(0f, 4f, 0.8f, fillPaint)
            }
            c.restore()
        }
        val pr = if (lane == 1) geo.outer else geo.inner
        val px = geo.cx + cos(angle) * pr
        val py = geo.cy + sin(angle) * pr
        val color = shipColor()
        if (effectiveGraphicsLevel() >= 1) {
            strokePaint.color = Color.argb(110, Color.red(color), Color.green(color), Color.blue(color))
            strokePaint.strokeWidth = 3f * unit
            strokePaint.strokeCap = Paint.Cap.ROUND
            c.drawLine(px - cos(angle) * 18f * unit, py - sin(angle) * 18f * unit,
                px - cos(angle) * 4f * unit, py - sin(angle) * 4f * unit, strokePaint)
        }
        drawGlow(c, px, py, 7.1f * unit, color)
        fillPaint.color = Color.rgb(249, 255, 255)
        c.drawCircle(px, py, 3.2f * unit, fillPaint)
        if (lastSwitch > 0f) {
            strokePaint.color = Color.argb((lastSwitch * 255f * 2.8f).toInt().coerceIn(0, 255), 140, 225, 255)
            strokePaint.strokeWidth = 1.5f * unit
            c.drawCircle(px, py, (12f + (0.22f - lastSwitch) * 38f) * unit, strokePaint)
        }
    }

    private data class OrbitGeometry(val cx: Float, val cy: Float, val inner: Float, val outer: Float)
    private fun orbitGeometry(): OrbitGeometry {
        val base = min(screenW * 0.355f, screenH * 0.245f)
        return OrbitGeometry(screenW / 2f, screenH * 0.515f, base * 0.69f, base)
    }

    private fun drawPaused(c: Canvas, time: Float) {
        drawPlaying(c, time, false)
        fillPaint.color = Color.argb(184, 4, 6, 17)
        c.drawRect(0f, 0f, screenW, screenH, fillPaint)
        val w = min(screenW - 44f * unit, 330f * unit)
        val h = 365f * unit
        val x = (screenW - w) / 2f
        val y = (screenH - h) / 2f
        drawPanel(c, x, y, w, h)
        drawGlow(c, screenW / 2f, y + 34f * unit, 3.2f * unit, CYAN)
        text(c, "PAUSED", screenW / 2f, y + 53f * unit, 22f * unit, WHITE, true)
        text(c, "YOUR RUN IS SAFE", screenW / 2f, y + 74f * unit, 8f * unit, MUTED, true)
        val bw = w - 40f * unit
        val bh = 39f * unit
        val top = y + 85f * unit
        val gap = 45f * unit
        drawButton(c, "RESUME", "3-second countdown", screenW / 2f, top, bw, bh, ButtonAction.RESUME, ButtonStyle.PRIMARY, true, 10f * unit)
        drawButton(c, "RESTART RUN", "Start this run over", screenW / 2f, top + gap, bw, bh, ButtonAction.RESTART, ButtonStyle.SECONDARY, true, 9.5f * unit)
        drawButton(c, "HOME MENU", "Your run stays saved", screenW / 2f, top + gap * 2f, bw, bh, ButtonAction.HOME, ButtonStyle.SECONDARY, true, 9.5f * unit)
        drawButton(c, "MUSIC  ·  ${if (audio.musicEnabled) "ON" else "OFF"}", "Background soundtrack", screenW / 2f, top + gap * 3f, bw, bh, ButtonAction.TOGGLE_MUSIC, if (audio.musicEnabled) ButtonStyle.SELECTED else ButtonStyle.SECONDARY, true, 9f * unit)
        drawButton(c, "SOUND EFFECTS  ·  ${if (audio.effectsEnabled) "ON" else "OFF"}", "Switch, collect and reward sounds", screenW / 2f, top + gap * 4f, bw, bh, ButtonAction.TOGGLE_EFFECTS, if (audio.effectsEnabled) ButtonStyle.SELECTED else ButtonStyle.SECONDARY, true, 8.6f * unit)
        drawButton(c, "EXIT GAME", "Close Orbit Dash", screenW / 2f, top + gap * 5f, bw, bh, ButtonAction.EXIT, ButtonStyle.DANGER, true, 9.5f * unit)
    }

    private fun drawCountdown(c: Canvas, time: Float) {
        drawPlaying(c, time, true)
        fillPaint.color = Color.argb(100, 4, 6, 17)
        c.drawRect(0f, 0f, screenW, screenH, fillPaint)
        val count = max(1, kotlin.math.ceil(resumeCountdown.toDouble()).toInt())
        drawGlow(c, screenW / 2f, screenH * 0.46f, 15f * unit, if (count == 1) CYAN else LAVENDER)
        text(c, count.toString(), screenW / 2f, screenH * 0.46f, 66f * unit, WHITE, true)
        text(c, "GET READY", screenW / 2f, screenH * 0.515f, 11f * unit, MUTED, true)
    }

    private fun drawGameOver(c: Canvas, time: Float) {
        drawPlaying(c, time, false)
        fillPaint.color = Color.argb(184, 4, 6, 17)
        c.drawRect(0f, 0f, screenW, screenH, fillPaint)
        val w = min(screenW - 44f * unit, 330f * unit)
        val h = 300f * unit
        val x = (screenW - w) / 2f
        val y = (screenH - h) / 2f
        drawPanel(c, x, y, w, h)
        drawGlow(c, screenW / 2f, y + 35f * unit, 3.5f * unit, PINK)
        text(c, "RUN COMPLETE", screenW / 2f, y + 59f * unit, 11f * unit, PINK, true)
        text(c, if (isNewBestRun) "NEW PERSONAL BEST" else "YOU CAN GO FURTHER", screenW / 2f, y + 85f * unit, 9f * unit, WHITE, true)
        text(c, "${score.toString().padStart(4, '0')}", screenW / 2f, y + 125f * unit, 31f * unit, WHITE, true)
        text(c, "SCORE", screenW / 2f, y + 148f * unit, 8f * unit, MUTED, true)
        text(c, "BEST  ${best.toString().padStart(4, '0')}     ✦  $gems", screenW / 2f, y + 175f * unit, 10f * unit, GOLD, true)
        val bw = w - 40f * unit
        val bh = 40f * unit
        drawButton(c, "PLAY AGAIN", "One more run?", screenW / 2f, y + 195f * unit, bw, bh, ButtonAction.NEW_GAME, ButtonStyle.PRIMARY, true, 10.5f * unit)
        drawButton(c, "HOME MENU", "See records and upgrades", screenW / 2f, y + 243f * unit, bw, bh, ButtonAction.HOME, ButtonStyle.SECONDARY, true, 10f * unit)
    }

    private fun drawSettings(c: Canvas) {
        drawPageHeading(c, "SETTINGS", "Tune Orbit Dash for your device")
        val mainW = min(screenW - 44f * unit, 330f * unit)
        drawButton(c, "BACKGROUND MUSIC", if (audio.musicEnabled) "ON · Ambient space soundtrack" else "OFF · Music muted",
            screenW / 2f, screenH * 0.235f, mainW, 58f * unit, ButtonAction.TOGGLE_MUSIC,
            if (audio.musicEnabled) ButtonStyle.SELECTED else ButtonStyle.SECONDARY, true, 10.5f * unit)
        drawButton(c, "SOUND EFFECTS", if (audio.effectsEnabled) "ON · Switch, collect and reward sounds" else "OFF · Effects muted",
            screenW / 2f, screenH * 0.335f, mainW, 58f * unit, ButtonAction.TOGGLE_EFFECTS,
            if (audio.effectsEnabled) ButtonStyle.SELECTED else ButtonStyle.SECONDARY, true, 10.5f * unit)
        text(c, "GRAPHICS QUALITY", screenW / 2f, screenH * 0.465f, 10.5f * unit, WHITE, true)
        val segW = (mainW - 12f * unit) / 3f
        val segTop = screenH * 0.49f
        for (index in 0..2) {
            val quality = when (index) { 0 -> GraphicsQuality.AUTO; 1 -> GraphicsQuality.LOW; else -> GraphicsQuality.HIGH }
            val cx = screenW / 2f - segW - 6f * unit + index * (segW + 6f * unit) + segW / 2f
            val action = when (quality) { GraphicsQuality.AUTO -> ButtonAction.GRAPHICS_AUTO; GraphicsQuality.LOW -> ButtonAction.GRAPHICS_LOW; GraphicsQuality.HIGH -> ButtonAction.GRAPHICS_HIGH }
            drawButton(c, quality.title, "", cx, segTop, segW, 42f * unit, action,
                if (graphicsQuality == quality) ButtonStyle.SELECTED else ButtonStyle.SECONDARY, true, 10f * unit)
        }
        text(c, when (graphicsQuality) {
            GraphicsQuality.AUTO -> "Auto chooses effects using device resources."
            GraphicsQuality.LOW -> "Low reduces particles and glow for lighter rendering."
            GraphicsQuality.HIGH -> "High enables richer glow and extra space detail."
        }, screenW / 2f, screenH * 0.575f, 8.5f * unit, MUTED, false)
        text(c, "CHANGES SAVE AUTOMATICALLY", screenW / 2f, screenH * 0.64f, 8f * unit, Color.rgb(105, 220, 206), true)
        drawButton(c, "BACK TO HOME", "", screenW / 2f, screenH * 0.72f, mainW, 44f * unit, ButtonAction.BACK, ButtonStyle.SECONDARY, true, 10.5f * unit)
    }

    private fun drawDifficulty(c: Canvas) {
        drawPageHeading(c, "DIFFICULTY", "Choose how intense each run feels")
        val w = min(screenW - 44f * unit, 330f * unit)
        val h = 62f * unit
        for (index in 0..2) {
            val option = when (index) { 0 -> Difficulty.EASY; 1 -> Difficulty.NORMAL; else -> Difficulty.HARD }
            val action = when (index) { 0 -> ButtonAction.SELECT_EASY; 1 -> ButtonAction.SELECT_NORMAL; else -> ButtonAction.SELECT_HARD }
            val top = when (index) { 0 -> screenH * 0.25f; 1 -> screenH * 0.385f; else -> screenH * 0.52f }
            val selected = difficulty == option
            drawButton(c, (if (selected) "✓  " else "") + option.title, option.description,
                screenW / 2f, top, w, h, action, if (selected) ButtonStyle.SELECTED else ButtonStyle.SECONDARY, true, 11f * unit)
        }
        text(c, "EASY IS A GREAT WAY TO LEARN THE TIMING.", screenW / 2f, screenH * 0.68f, 8.3f * unit, MUTED, true)
        drawButton(c, "BACK TO HOME", "", screenW / 2f, screenH * 0.74f, w, 44f * unit, ButtonAction.BACK, ButtonStyle.SECONDARY, true, 10.5f * unit)
    }

    private fun drawScores(c: Canvas) {
        drawPageHeading(c, "HIGH SCORES", "Your best local runs · stored on this device")
        val w = min(screenW - 44f * unit, 330f * unit)
        drawPill(c, screenW / 2f - w / 2f, screenH * 0.205f, w, 40f * unit,
            "PERSONAL BEST     ${best.toString().padStart(4, '0')}", Color.argb(25, 143, 122, 255), Color.argb(90, 143, 122, 255), LAVENDER, 10.5f * unit)
        text(c, "LAST RUN  ${lastScore.toString().padStart(4, '0')}     ·     RUNS  $totalRuns", screenW / 2f, screenH * 0.275f, 8.4f * unit, MUTED, true)
        text(c, "TOP RUNS", screenW / 2f, screenH * 0.335f, 10f * unit, WHITE, true)
        val list = readScoreHistory()
        repeat(5) { index ->
            val y = screenH * 0.365f + index * 49f * unit
            val value = list.getOrNull(index)
            drawScoreRow(c, y, index + 1, value)
        }
        drawPill(c, screenW / 2f - 75f * unit, screenH * 0.70f, 150f * unit, 30f * unit,
            "BANKED STARS   ✦ $bankedStars", Color.argb(22, 255, 204, 98), Color.argb(78, 255, 204, 98), GOLD, 8.8f * unit)
        drawButton(c, "BACK TO HOME", "", screenW / 2f, screenH * 0.77f, w, 44f * unit, ButtonAction.BACK, ButtonStyle.SECONDARY, true, 10.5f * unit)
    }

    private fun drawScoreRow(c: Canvas, top: Float, position: Int, value: Int?) {
        val w = min(screenW - 50f * unit, 318f * unit)
        val x = (screenW - w) / 2f
        rect.set(x, top, x + w, top + 39f * unit)
        fillPaint.color = Color.argb(if (position == 1) 34 else 17, 132, 119, 255)
        c.drawRoundRect(rect, 10f * unit, 10f * unit, fillPaint)
        text(c, "#${position.toString().padStart(2, '0')}", x + 24f * unit, top + 19.5f * unit, 10f * unit, if (position == 1) GOLD else MUTED, true)
        text(c, value?.toString()?.padStart(4, '0') ?: "—", x + w - 36f * unit, top + 19.5f * unit, 12f * unit, WHITE, true, Paint.Align.RIGHT)
    }

    private fun drawCustomize(c: Canvas, time: Float) {
        drawPageHeading(c, "SHIP LAB", "Earn stars and choose your glow")
        drawLogoOrbits(c, screenW / 2f, screenH * 0.205f, min(screenW * 0.12f, screenH * 0.05f), time)
        drawPill(c, screenW / 2f - 78f * unit, screenH * 0.29f, 156f * unit, 28f * unit,
            "BANKED STARS   ✦ $bankedStars", Color.argb(22, 255, 204, 98), Color.argb(78, 255, 204, 98), GOLD, 8.8f * unit)
        val w = min(screenW - 44f * unit, 330f * unit)
        shipSkins.forEachIndexed { index, skin ->
            val top = screenH * 0.35f + index * 0.115f * screenH
            val unlocked = bankedStars >= skin.requiredStars
            val selected = selectedSkinIndex == index
            val label = if (selected) "✓  ${skin.title}" else skin.title
            val subtitle = when {
                selected -> "EQUIPPED · YOUR CURRENT SHIP"
                unlocked -> "UNLOCKED · TAP TO EQUIP"
                else -> "UNLOCK AT ${skin.requiredStars} STARS · ✦ ${skin.requiredStars - bankedStars} TO GO"
            }
            drawButton(c, label, subtitle, screenW / 2f, top, w, 62f * unit,
                when (index) { 0 -> ButtonAction.SKIN_NEBULA; 1 -> ButtonAction.SKIN_ICE; else -> ButtonAction.SKIN_SOLAR },
                when { selected -> ButtonStyle.SELECTED; unlocked -> ButtonStyle.SECONDARY; else -> ButtonStyle.DISABLED }, unlocked, 10.7f * unit, skin.color)
        }
        text(c, "SKINS ARE COSMETIC · NO GAMEPLAY ADVANTAGE", screenW / 2f, screenH * 0.72f, 7.8f * unit, MUTED, true)
        drawButton(c, "BACK TO HOME", "", screenW / 2f, screenH * 0.77f, w, 44f * unit, ButtonAction.BACK, ButtonStyle.SECONDARY, true, 10.5f * unit)
    }

    private fun drawMissions(c: Canvas) {
        drawPageHeading(c, "DAILY MISSIONS", "Complete goals today to earn more stars")
        val w = min(screenW - 32f * unit, 342f * unit)
        drawMissionCard(c, screenH * 0.225f, w, 82f * unit, "STAR COLLECTOR", "Collect 10 stars", dailyStars.coerceAtMost(10), 10, dailyClaimedStars, ButtonAction.CLAIM_STARS, 20)
        drawMissionCard(c, screenH * 0.355f, w, 82f * unit, "STAY IN ORBIT", "Survive 45 seconds in one run", dailySurvival.coerceAtMost(45), 45, dailyClaimedSurvive, ButtonAction.CLAIM_SURVIVE, 20)
        drawMissionCard(c, screenH * 0.485f, w, 82f * unit, "SCORE CHASER", "Reach 400 score in a run", dailyScore.coerceAtMost(400), 400, dailyClaimedScore, ButtonAction.CLAIM_SCORE, 30)
        text(c, "PROGRESS RESETS EACH NEW LOCAL DAY", screenW / 2f, screenH * 0.63f, 8f * unit, MUTED, true)
        drawButton(c, "BACK TO HOME", "", screenW / 2f, screenH * 0.70f, min(screenW - 44f * unit, 330f * unit), 44f * unit,
            ButtonAction.BACK, ButtonStyle.SECONDARY, true, 10.5f * unit)
    }

    private fun drawMissionCard(c: Canvas, top: Float, width: Float, height: Float,
                                title: String, description: String, progress: Int, goal: Int, claimed: Boolean,
                                action: ButtonAction, reward: Int) {
        val left = (screenW - width) / 2f
        panelRect.set(left, top, left + width, top + height)
        fillPaint.color = PANEL
        c.drawRoundRect(panelRect, 13f * unit, 13f * unit, fillPaint)
        strokePaint.color = Color.argb(70, 127, 119, 220)
        strokePaint.strokeWidth = unit
        c.drawRoundRect(panelRect, 13f * unit, 13f * unit, strokePaint)
        text(c, title, left + 13f * unit, top + 17f * unit, 9.3f * unit, WHITE, true, Paint.Align.LEFT)
        text(c, description, left + 13f * unit, top + 34f * unit, 7.7f * unit, MUTED, false, Paint.Align.LEFT)
        val barLeft = left + 13f * unit
        val barRight = left + width - 91f * unit
        rect.set(barLeft, top + 54f * unit, barRight, top + 59f * unit)
        fillPaint.color = Color.argb(42, 172, 180, 218)
        c.drawRoundRect(rect, 3f * unit, 3f * unit, fillPaint)
        rect.set(barLeft, top + 54f * unit, barLeft + (barRight - barLeft) * (progress.toFloat() / goal.toFloat()).coerceIn(0f, 1f), top + 59f * unit)
        fillPaint.color = CYAN
        c.drawRoundRect(rect, 3f * unit, 3f * unit, fillPaint)
        text(c, "$progress/$goal", (barLeft + barRight) / 2f, top + 67f * unit, 7f * unit, WHITE, true)
        val complete = progress >= goal
        val claimLabel = when { claimed -> "CLAIMED"; complete -> "CLAIM +$reward"; else -> "✦ $reward" }
        val claimStyle = when { claimed -> ButtonStyle.DISABLED; complete -> ButtonStyle.PRIMARY; else -> ButtonStyle.DISABLED }
        drawButton(c, claimLabel, "", left + width - 49f * unit, top + 28f * unit, 82f * unit, 31f * unit,
            action, claimStyle, complete && !claimed, 7.7f * unit)
    }

    private fun drawPageHeading(c: Canvas, title: String, subtitle: String) {
        drawTopBack(c)
        text(c, title, screenW / 2f, 31f * unit, 12f * unit, WHITE, true)
        text(c, subtitle, screenW / 2f, screenH * 0.145f, 9f * unit, MUTED, false)
    }

    private fun drawPanel(c: Canvas, x: Float, y: Float, width: Float, height: Float) {
        rect.set(x, y, x + width, y + height)
        fillPaint.color = PANEL
        c.drawRoundRect(rect, 23f * unit, 23f * unit, fillPaint)
        strokePaint.color = Color.argb(130, 129, 115, 255)
        strokePaint.strokeWidth = 1.1f * unit
        c.drawRoundRect(rect, 23f * unit, 23f * unit, strokePaint)
        fillPaint.color = Color.argb(18, 94, 240, 255)
        rect.set(x + 1f * unit, y + 1f * unit, x + width - 1f * unit, y + 4f * unit)
        c.drawRoundRect(rect, 2f * unit, 2f * unit, fillPaint)
    }

    private fun drawButton(c: Canvas, label: String, subtitle: String, centerX: Float, top: Float,
                           width: Float, height: Float, action: ButtonAction, style: ButtonStyle,
                           enabled: Boolean, fontSize: Float = 10.5f * unit, accentColor: Int = LAVENDER) {
        val left = centerX - width / 2f
        rect.set(left, top, left + width, top + height)
        fillPaint.color = when (style) {
            ButtonStyle.PRIMARY -> Color.rgb(77, 79, 220)
            ButtonStyle.SECONDARY -> Color.argb(23, 171, 180, 255)
            ButtonStyle.SELECTED -> Color.argb(42, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            ButtonStyle.DANGER -> Color.argb(35, 255, 79, 131)
            ButtonStyle.DISABLED -> Color.argb(11, 170, 177, 214)
        }
        c.drawRoundRect(rect, 13f * unit, 13f * unit, fillPaint)
        if (style == ButtonStyle.PRIMARY && effectiveGraphicsLevel() >= 1) {
            fillPaint.color = Color.argb(20, 99, 239, 255)
            c.drawRoundRect(rect, 13f * unit, 13f * unit, fillPaint)
        }
        strokePaint.color = when (style) {
            ButtonStyle.PRIMARY -> Color.argb(125, 180, 180, 255)
            ButtonStyle.SECONDARY -> Color.argb(68, 161, 172, 235)
            ButtonStyle.SELECTED -> Color.argb(155, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            ButtonStyle.DANGER -> Color.argb(110, 255, 107, 150)
            ButtonStyle.DISABLED -> Color.argb(30, 167, 176, 220)
        }
        strokePaint.strokeWidth = unit
        c.drawRoundRect(rect, 13f * unit, 13f * unit, strokePaint)
        val titleColor = if (style == ButtonStyle.DISABLED) Color.rgb(104, 111, 145) else WHITE
        if (subtitle.isBlank()) {
            text(c, label, centerX, top + height / 2f, fontSize, titleColor, true)
        } else {
            text(c, label, centerX, top + height * 0.40f, fontSize, titleColor, true)
            text(c, subtitle, centerX, top + height * 0.72f, (fontSize * 0.72f).coerceAtLeast(7f * unit),
                if (style == ButtonStyle.DISABLED) Color.rgb(88, 95, 125) else Color.rgb(180, 188, 221), false)
        }
        if (enabled && action != ButtonAction.NONE) registerTarget(action, left, top, left + width, top + height)
    }

    private fun drawPill(c: Canvas, left: Float, top: Float, width: Float, height: Float, label: String,
                         fill: Int, border: Int, color: Int, size: Float) {
        rect.set(left, top, left + width, top + height)
        fillPaint.color = fill
        c.drawRoundRect(rect, height / 2f, height / 2f, fillPaint)
        strokePaint.color = border
        strokePaint.strokeWidth = unit
        c.drawRoundRect(rect, height / 2f, height / 2f, strokePaint)
        text(c, label, left + width / 2f, top + height / 2f, size, color, true)
    }

    private fun drawRing(c: Canvas, cx: Float, cy: Float, radius: Float, color: Int, width: Float) {
        strokePaint.color = color
        strokePaint.strokeWidth = width
        strokePaint.pathEffect = null
        c.drawCircle(cx, cy, radius, strokePaint)
    }

    private fun drawGlow(c: Canvas, x: Float, y: Float, radius: Float, color: Int) {
        val alpha = Color.alpha(color)
        val layers = when (effectiveGraphicsLevel()) { 0 -> 1; 1 -> 3; else -> 4 }
        for (i in 0 until layers) {
            val divisor = if (layers == 1) 1f else layers.toFloat()
            val layerRadius = radius * (2.2f - i * (1.1f / max(1, layers - 1)))
            fillPaint.color = Color.argb((alpha * (0.10f + (i / divisor) * 0.10f)).toInt().coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
            c.drawCircle(x, y, layerRadius, fillPaint)
        }
        fillPaint.color = color
        c.drawCircle(x, y, radius, fillPaint)
    }

    private fun text(c: Canvas, value: String, x: Float, y: Float, size: Float, color: Int,
                     bold: Boolean, align: Paint.Align = Paint.Align.CENTER) {
        textPaint.color = color
        textPaint.textSize = size
        textPaint.textAlign = align
        textPaint.typeface = if (bold) boldTypeface else regularTypeface
        val baseline = y - (textPaint.ascent() + textPaint.descent()) / 2f
        c.drawText(value, x, baseline, textPaint)
    }

    private fun registerTarget(action: ButtonAction, left: Float, top: Float, right: Float, bottom: Float) {
        val target = if (hitTargetCount < hitTargets.size) hitTargets[hitTargetCount] else HitTarget().also { hitTargets.add(it) }
        target.action = action
        target.bounds.set(left, top, right, bottom)
        hitTargetCount++
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            for (i in hitTargetCount - 1 downTo 0) {
                val target = hitTargets[i]
                if (target.bounds.contains(event.x, event.y)) {
                    performClick()
                    dispatch(target.action)
                    invalidate()
                    return true
                }
            }
            if (scene == Scene.PLAYING) {
                switchLane()
                invalidate()
            }
            performClick()
            return true
        }
        return true
    }

    private fun dispatch(action: ButtonAction) {
        val hasOwnFeedback = action == ButtonAction.TOGGLE_MUSIC || action == ButtonAction.TOGGLE_EFFECTS ||
            action == ButtonAction.NEW_GAME || action == ButtonAction.CONTINUE || action == ButtonAction.RESUME ||
            action == ButtonAction.RESTART || action == ButtonAction.SKIN_NEBULA || action == ButtonAction.SKIN_ICE ||
            action == ButtonAction.SKIN_SOLAR || action == ButtonAction.CLAIM_STARS ||
            action == ButtonAction.CLAIM_SURVIVE || action == ButtonAction.CLAIM_SCORE
        if (!hasOwnFeedback) audio.play(OrbitAudio.Effect.CLICK)
        when (action) {
            ButtonAction.NEW_GAME -> startNewGame()
            ButtonAction.CONTINUE -> if (restoreSavedRun()) startResumeCountdown()
            ButtonAction.OPEN_DIFFICULTY -> scene = Scene.DIFFICULTY
            ButtonAction.OPEN_SCORES -> { ensureDailyMissionsCurrent(); scene = Scene.SCORES }
            ButtonAction.OPEN_CUSTOMIZE -> scene = Scene.CUSTOMIZE
            ButtonAction.OPEN_MISSIONS -> { ensureDailyMissionsCurrent(); scene = Scene.MISSIONS }
            ButtonAction.OPEN_SETTINGS -> scene = Scene.SETTINGS
            ButtonAction.TOGGLE_MUSIC -> audio.toggleMusic()
            ButtonAction.TOGGLE_EFFECTS -> audio.toggleEffects()
            ButtonAction.SELECT_EASY -> selectDifficulty(Difficulty.EASY)
            ButtonAction.SELECT_NORMAL -> selectDifficulty(Difficulty.NORMAL)
            ButtonAction.SELECT_HARD -> selectDifficulty(Difficulty.HARD)
            ButtonAction.GRAPHICS_AUTO -> setGraphicsQuality(GraphicsQuality.AUTO)
            ButtonAction.GRAPHICS_LOW -> setGraphicsQuality(GraphicsQuality.LOW)
            ButtonAction.GRAPHICS_HIGH -> setGraphicsQuality(GraphicsQuality.HIGH)
            ButtonAction.BACK -> scene = Scene.HOME
            ButtonAction.PAUSE -> {
                if (scene == Scene.PLAYING || scene == Scene.COUNTDOWN) {
                    saveCurrentRun()
                    scene = Scene.PAUSED
                }
            }
            ButtonAction.RESUME -> startResumeCountdown()
            ButtonAction.RESTART -> startNewGame()
            ButtonAction.HOME -> {
                if (scene == Scene.PAUSED || scene == Scene.PLAYING || scene == Scene.COUNTDOWN) saveCurrentRun()
                scene = Scene.HOME
            }
            ButtonAction.EXIT -> (context as? Activity)?.finish()
            ButtonAction.SKIN_NEBULA -> selectSkin(0)
            ButtonAction.SKIN_ICE -> selectSkin(1)
            ButtonAction.SKIN_SOLAR -> selectSkin(2)
            ButtonAction.CLAIM_STARS -> claimMission(0)
            ButtonAction.CLAIM_SURVIVE -> claimMission(1)
            ButtonAction.CLAIM_SCORE -> claimMission(2)
            ButtonAction.NONE -> Unit
        }
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onDetachedFromWindow() {
        running = false
        lastFrameNs = 0L
        super.onDetachedFromWindow()
    }

    companion object {
        private val BG = Color.rgb(7, 9, 20)
        private val PANEL = Color.rgb(18, 22, 49)
        private val WHITE = Color.rgb(247, 248, 255)
        private val MUTED = Color.rgb(143, 152, 190)
        private val LAVENDER = Color.rgb(161, 136, 255)
        private val CYAN = Color.rgb(100, 239, 255)
        private val PINK = Color.rgb(255, 79, 131)
        private val GOLD = Color.rgb(255, 214, 107)
    }
}
