# No custom shrinking rules are required for this first offline release.
