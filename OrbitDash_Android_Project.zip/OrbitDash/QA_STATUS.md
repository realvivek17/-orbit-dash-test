# Orbit Dash QA status — 11 October 2026

## Revision 1.2.0 changes
- Home screen reorganized with a Star Points balance, direct three-option difficulty selector, Shop, and TecNxt/Vivek Singh credit.
- Star Points reward logic: Easy 30, Normal 50, Hard 100 points per collected star.
- One-time legacy balance conversion: existing `banked_stars × 50` becomes `star_points`; legacy selected Nebula/Ice Comet/Solar Flare unlocks are preserved where existing preferences show them as owned.
- Five priced cosmetic shop items with persistent ownership, one-time deduction, and equip/re-equip behavior.
- Independent persisted Music and Sound Effects volume sliders, quieter defaults, async preparation of the one looping offline soundtrack.
- Hard difficulty curve progressively tightens across 15/30/45/60-second milestones; Easy and Normal retain gentler progression.
- Replaced the old background audio with a custom 24-second atmospheric neon/sci-fi instrumental loop with a loop crossfade.
- Additional obstacle outlines/near-impact warning cue and low-cost pulsing hero animation.
- Updated versionCode/versionName to 4 / 1.2.0.

## Checks completed for this archive
- Inspected the original archive and the changed native Android Canvas game/audio sources.
- Kotlin syntax/type-check passed against lightweight local Android API stubs. This checks Kotlin structure, but it is not equivalent to compiling against the real Android SDK.
- Manifest XML parses and there is no `INTERNET` permission; gameplay and music remain local/offline.
- All referenced `R.raw` resources, scene names and button-action references were checked for matching declarations/files.
- Confirmed the custom music loop is 24 seconds, PCM 16-bit mono at 22,050 Hz, with a very small sample jump at the repeat boundary; all bundled WAV files pass structural checks.
- Checked the mode rewards (30/50/100), the one-time legacy balance conversion, the six Shop rows (free Nebula + five unlocks), sound slider persistence and the hard-mode milestone values.

## Not yet verified
- A full Gradle Android build against the actual Android SDK for this revision. This environment has no installed Android SDK/Gradle distribution and outbound download access is unavailable, so a real local Android build could not be run here.
- Kotlin compilation against the full Android SDK (separate from syntax/static checks).
- Runtime visuals, touch response, audio loudness, shop persistence, migrated state and performance on the user's phone.
- Frame-rate/thermal/battery measurements and compatibility across different Android devices.
- Release-signed APK/AAB and Play Console publishing.

A green GitHub Actions check confirms build/package success only. It does not prove that every runtime behavior works perfectly on-device.

## Physical-device acceptance checklist
1. App opens directly to the home screen without a white screen or crash; Star Points and footer credits are visible without overlapping the orbit art.
2. Easy / Normal / Hard can be selected directly on home and the chosen mode persists.
3. Each collected star awards 30 / 50 / 100 Star Points in Easy / Normal / Hard; points persist after app closure.
4. An existing installation's legacy balance migrates once at 50 points per old banked star; restart does not multiply it again.
5. Each shop item can be bought with enough points, cannot be bought when unaffordable, deducts only once, remains owned and can be equipped again.
6. Music loops; music/effects toggles and sliders respond, save, and have comfortably quiet defaults. Toggle behavior remains correct when paused/backgrounded.
7. Hard increases steadily around 15 / 30 / 45 / 60 seconds and is substantially tougher after one minute without impossible hazard combinations; Easy stays relaxed; Normal remains engaging.
8. Pause freezes gameplay; Resume uses the 3-second countdown; Continue restores a saved run; Restart creates a fresh run; Home and app backgrounding preserve an active run as designed.
9. High score, missions and claimed rewards persist and are not paid twice.
10. Auto / Low / High graphics modes persist; Low materially reduces glow/particle work; no text or buttons are clipped on the test phone.
11. Enable airplane mode and restart: game and local audio remain usable without a network connection.
12. Play multiple rounds and watch for crashes, stutter, missed taps, sudden volume spikes or abnormal heating.

## Publishing note
Before public release, finish on-device tests, generate a release-signed Android App Bundle (`.aab`), confirm the final app ID, update privacy/Data safety answers if any dependencies change, capture real screenshots and follow current Play Console requirements. Ads remain intentionally absent from this build.
