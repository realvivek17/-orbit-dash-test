# Orbit Dash QA status — updated 11 October 2026

## Fix in this revision
- Replaced the Android `WebView` runtime with a native Kotlin `Canvas` game view to remove the local HTML/WebView startup dependency that was present in the prior APK reported to show a blank white screen and close.
- Added lifecycle-aware animation start/pause, native touch input, local best-score/sound preferences, and optional native tone feedback.
- Bumped app version to `1.0.1` (`versionCode 2`) so this is a distinguishable build.
- Kept `compileSdk = 36` and `targetSdk = 36` for current Google Play target API requirements.
- Manifest requests no Android permissions; no ads, analytics, login, internet permission, or remote services are included.

## Checks done in this environment
- Kotlin source parsed and type-checked against locally created minimal Android API stubs with no compiler errors. This catches Kotlin syntax and many type errors, but it is not a substitute for compiling against the real Android SDK.
- Project files and archive layout are checked by packaging scripts.
- Existing GitHub Actions workflow for the earlier WebView project was seen to complete successfully in the user's screenshots. **That does not prove the revised native version has already been built.**

## Still required
- Upload this revised project ZIP to the user's GitHub repository and confirm GitHub Actions compiles it against the real Android SDK.
- Install the new generated APK on the physical Android phone and test launch, touch controls, hazards, gems, game over/replay, persisted best score/sound preference, Back handling, and airplane mode.
- If it still crashes, retrieve device-specific crash evidence; do not guess at another fix.
- No release-signed APK/AAB has been produced here. The GitHub workflow creates a **debug APK** for testing only.
- No AdMob SDK or live ads are integrated. Current build cannot earn advertising revenue.
