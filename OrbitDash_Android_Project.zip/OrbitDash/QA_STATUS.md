# Orbit Dash QA status — revision 1.3.0

## Implemented in this revision
- Code-rendered launch intro with a roughly 4.9-second animation, animated orbital art and cyan-to-violet intro bar.
- Required splash copy: `OFFICIALLY DESIGNED & DEVELOPED BY` and `TecNxt Team • Vivek Singh`.
- Three free persistent world themes with compressed background art: Cosmic Nebula, Celestial Frontier, and Heavenly Realms.
- Selected world background applied to gameplay and the rest of the game's screens; overlays darken imagery to retain text contrast.
- Home menu with Star Points, score, primary New Game, difficulty selector, High Scores, Shop, Missions, Settings, Themes and developer credits. Continue is conditional on a real saved-run flag.
- Improved Shop cards with live cosmetic previews, equipped/owned/locked states and existing point-deduction protections.
- Settings sections for Audio, Volume Levels and Graphics Quality; user-visible help copy is `Higher quality adds glow and detail.`
- Custom 24-second, locally bundled synthesized flute-led instrumental loop; independent music/SFX toggles and persistent quiet volume controls.
- Removed non-functional gameplay progress dots; preserved original two-orbit mechanics, score handling, missions, point values, save/resume, and difficulty logic.
- App bumped to versionCode 5 / versionName 1.3.0.

## Checks actually performed on the source archive
- Kotlin source compile completed against lightweight, locally defined Android API stubs without Kotlin errors. This is a source/type sanity check, not an Android SDK build.
- Android manifest parsed as valid XML; the manifest does not request `INTERNET`.
- The three bundled theme JPGs were opened/verified as valid images (640×960).
- All `R.raw` files referenced by `OrbitAudio.kt` exist; the soundtrack is a 24-second mono 16-bit / 22,050 Hz WAV.
- Static checks cover the theme keys/actions, splash credit text, three themes, version metadata, and local raw resources.
- Project ZIP integrity is verified after packaging.

## Not yet verified — do not treat these as passed
- Full Gradle build against Android SDK 36. The current environment does not contain an Android SDK or Gradle distribution, and outbound package downloads are unavailable.
- Installation/run on a real Android phone.
- Exact visual comparison at different device sizes; runtime text clipping or touch-target review.
- Measured frame rate, thermal/battery performance, and background lifecycle behavior.
- Actual music/SFX loudness on phone speakers or headphones.
- Live purchase, mission claim, run-save migration and theme persistence scenarios on a device.

## Physical-device acceptance checklist
1. Cold-launch intro animates once, shows the exact credit and transitions smoothly to Home; returning home does not replay it.
2. Home items are readable and tappable; Continue appears only with a saved run.
3. All three themes select successfully, remain selected after restart and appear during gameplay without altering hitboxes/scoring.
4. Easy / Normal / Hard can be selected and persist; Hard ramps around 15/30/45/60 seconds without impossible hazard sequences.
5. Collected stars award 30 / 50 / 100 Star Points by mode; balance persists and migration of old banked stars happens once.
6. Shop item purchases deduct only once, never allow negative balance, persist and can be re-equipped; Nebula remains equipable.
7. Flute music loops offline; music/SFX toggles and independent sliders work at low volume and persist after restart.
8. Low / Auto / High settings change visual quality without changing gameplay mechanics.
9. Mission progress reflects real events and claimed rewards cannot be claimed twice; daily reset follows local date.
10. High scores stay sorted; last score, run count and best score remain consistent.
11. Pause, resume countdown, restart, home, app backgrounding and continue behave correctly.
12. Test in airplane mode and on a smaller phone; watch for crashes, stutter, clipped UI, missed taps and unexpected heating.

## Release note
This remains a debug-test candidate until the repository's real Android build passes and on-device checks are completed. A green CI status confirms build/package success only; it does not prove every runtime behavior. Release signing/AAB and Play Console review are out of scope for this ZIP.
