# Orbit Dash 1.4.0 — QA Status

## Source-level verification performed in this working environment
- Kotlin compiler/type-sanity pass for `MainActivity.kt` and `OrbitAudio.kt` against lightweight Android API stubs: passed (repeated three times after final edits).
- Static asset checks: all three theme JPEG assets and all four music OGG resources are present and non-empty.
- Audio file checks: four OGG files are stereo, 44.1 kHz Vorbis, contain flute-led instrumental audio, and have short sample-to-sample loop-boundary differences after crossfade.
- Manifest audit: no `INTERNET` permission; screens/audio/theme assets are local.
- ZIP structure/integrity check: passed after packaging.
- Persistence/navigation code review: profile fields and selected track use local SharedPreferences; theme/settings/shop/missions/scores remain offline.

## Not claimed as passed
- This environment has no installed Android SDK/Gradle distribution, so a full Android Gradle APK build was not run here.
- No emulator or physical Android device is attached, so splash transition timing, native dialog appearance, actual audio switching, touch behaviour, FPS, and device-specific layout still require the GitHub Actions build and on-phone QA.
- Source type-checks cannot prove crash-free runtime or perfect performance.

## Recommended phone checks after GitHub Actions succeeds
1. First launch: wait through the splash; enter name and age; confirm the form does not appear again after force-close/reopen.
2. Settings: tap both music arrows in both directions; verify the track changes immediately, volume slider remains independent, and the selected song is retained after relaunch.
3. Home/About: ensure the footer is readable on the current celestial theme; open About Us and verify all requested copy and the heart background.
4. Gameplay: test all three themes, music/SFX toggles, orbit switching, pause/resume, collision, score/Star Points, missions, and shop.
5. Force-close and reopen, then verify profile, music selection, theme, scores, Star Points and owned items persist.
6. Try LOW/AUTO/HIGH graphics and confirm gameplay remains responsive.
