# Orbit Dash 1.3.0 — Phone se naya APK banane ka guide

## 1) ZIP ko GitHub par update karo
1. ChatGPT se `OrbitDash_Android_Project.zip` download karo.
2. GitHub mein `realvivek17/-orbit-dash-test` repository kholo.
3. **Code** page par `…` → **Upload files** select karo.
4. Downloads folder se updated `OrbitDash_Android_Project.zip` select karo.
5. Commit message likho: `Update Orbit Dash project v1.3.0`.
6. `Commit directly to the main branch` select rehne do, phir **Commit changes** tap karo.

Agar GitHub duplicate/conflict error de, kuch delete mat karna. Error ka screenshot bhej dena.

## 2) Naya debug APK banao
1. Repository ke **Actions** tab par jao.
2. Sabse naya `Build Orbit Dash APK` run kholo.
3. Green ✅ `Success` aane ka wait karo. Red ❌ `Failure` aaye to error screenshot bhejo.
4. Successful run ke andar **Artifacts** section se `OrbitDash-debug-APK` download karo.
5. Artifact ZIP extract karo; andar `app-debug.apk` milega.

## 3) Phone par test karo
- App launch hote waqt intro, TecNxt credit aur home transition check karo.
- Themes menu khol kar Cosmic Nebula, Celestial Frontier aur Heavenly Realms select karo; phir New Game chala kar dekho background badalta hai ya nahi.
- Music/SFX toggle, volume sliders, difficulty, shop, missions, pause/resume aur saved progress test karo.
- Airplane mode mein bhi game khulna chahiye.

Agar Android kahe ki existing app ke signature ki wajah se update install nahi ho sakta, pehle screenshot bhejo. Purani app uninstall karne se local progress/settings mit sakti hain.

**Note:** Kotlin source/static checks pass hue hain, lekin full Gradle build aur actual-phone runtime test abhi pending hai. Final APK ko green GitHub Actions build aur phone testing ke baad hi verified maana jayega.
