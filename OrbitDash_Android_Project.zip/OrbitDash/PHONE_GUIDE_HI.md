# Orbit Dash 1.4.0 — Phone test guide (Hindi)

1. GitHub par updated `OrbitDash_Android_Project.zip` upload karke commit karein.
2. Actions → latest **Build Orbit Dash APK** run kholen. Red Failure aaye to log ka screenshot/share karein; green Success par `OrbitDash-debug-APK` artifact download karein.
3. Artifact ZIP extract karke `app-debug.apk` install karein. Existing app uninstall na karein, warna local progress delete ho sakta hai.
4. Pehli baar startup animation ke baad apna naam aur age bharein. Details sirf is device par save hoti hain.
5. Settings → Music Track mein left/right arrows se 4 tracks test karein: Cosmic Drift, Serenity Flute, Nebula Pulse, Celestial Journey. Choice app reopen karne ke baad bhi rehni chahiye.
6. Home → About Us kholkar text aur heart background check karein. Footer text readable hona chahiye.
7. Teen themes, shop, points, missions, scores, music/SFX, graphics quality, pause/resume aur new game test karein.
8. Crash, blank screen, music stop, button miss ya overlap ho to screenshot aur exact steps note karein.

Note: Source-level checks pass hain, lekin full Android build aur real-device test complete maana jayega sirf successful Actions run aur phone testing ke baad.
