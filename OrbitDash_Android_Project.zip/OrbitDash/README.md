# Orbit Dash — native offline Android arcade

**Version:** 1.1.0 (`versionCode 3`)  
**Package ID:** `com.dealnxt.orbitdash`  
**Minimum Android:** API 23  
**Compile / target SDK:** 36  
**Network:** No internet permission; the playable game and audio are bundled locally.

## Features in this revision

- Premium dark-space visual style with neon purple/cyan glow, twinkling starfield, orbit particles and trails.
- Native Android `Canvas` renderer (no WebView startup dependency); reusable drawing paths/paints and pooled hit targets reduce avoidable per-frame allocation.
- Two-orbit one-touch gameplay, pink hazards, gold-star collectibles and progressive speed.
- Main menu: New Game, Continue saved run, Personal Best, Difficulty, High Scores, Ship Lab, Daily Missions and Settings.
- Easy / Normal / Hard modes with distinct pacing and spawn rates.
- Pause overlay with Resume (3-second countdown), Restart, Home and Exit. A run is persisted when paused or when the app is sent to the background.
- Local best score, last score, top-five run history, total runs and star currency.
- Daily missions with local progress and claimable star rewards.
- Three cosmetic ships (Nebula, Ice Comet, Solar Flare) unlocked by earned stars.
- Independent music and sound-effect toggles; original synthesized loop music and original one-shot sound effects are stored in `res/raw`.
- Auto / Low / High graphics quality. Auto uses memory and CPU count as a simple device heuristic; it is not a runtime benchmark.
- Settings and run state use Android SharedPreferences only. No account, analytics, ad SDK, web service or internet permission is included.

## Files

- `app/src/main/java/com/dealnxt/orbitdash/MainActivity.kt` — game loop, Canvas rendering, controls, menu screens, game state, persistence and missions.
- `app/src/main/java/com/dealnxt/orbitdash/OrbitAudio.kt` — local background music and sound effects with lifecycle-safe best-effort handling.
- `app/src/main/res/raw/` — original local WAV soundtrack and SFX.
- `marketing/` — app icon, feature graphic, listing draft, privacy policy draft and publishing checklist.

## Phone-only GitHub Actions build

The repository workflow expects a ZIP in the repository root named exactly `OrbitDash_Android_Project.zip` and extracts it to `source/OrbitDash`.

1. Download this updated project ZIP from the conversation.
2. Open the repository's **Code** tab at its root. Use `…` → **Upload files** and choose `OrbitDash_Android_Project.zip` from Downloads. Commit to `main`.
3. Open the repository **Actions** tab and select the newest `Build Orbit Dash APK` run. Wait for a green check.
4. On the run summary, scroll to **Artifacts** and download `OrbitDash-debug-APK`.
5. Extract the downloaded artifact ZIP and install `app-debug.apk`. If Android reports a signature conflict with an older CI test build, uninstall the older test build first, then install the new one.

## QA status — what is and is not verified

- Main Kotlin source and audio-controller source passed a local Kotlin compile/type check against minimal Android API stubs. This checks Kotlin syntax and many type relationships, but it is not a build against the real Android SDK.
- Project archive layout, Android manifest XML, raw audio resource names and Gradle settings are checked.
- **This revision has not yet been built in the user's current GitHub Actions run or tested on the user's physical phone.** A successful GitHub run will prove compilation and APK packaging, not every runtime behavior. Install this revision and follow the device checklist below.
- No release-signed APK/AAB has been generated. The GitHub workflow produces a debug APK for testing only.
- Ads are intentionally not integrated. This version earns no ad revenue.

## Physical-device acceptance checklist

1. App opens to the home menu without a white screen or immediate exit.
2. Music plays by default; music/effect toggles work and remain saved after relaunch.
3. New Game begins; tapping switches orbit and there is no unwanted touch-through from menus.
4. Hazards cause game over, stars are collectible, Play Again works and best score persists.
5. Pause freezes gameplay; Resume shows a 3-second countdown, then resumes; Restart resets the run; Home keeps the saved run available; Exit closes the app.
6. Continue restores a saved run after Home or app backgrounding.
7. Easy, Normal and Hard produce different pacing.
8. Graphics Auto, Low and High settings persist; Low reduces visual effects.
9. Ship Lab unlock conditions and Daily Mission progress/rewards work offline.
10. Turn on airplane mode, relaunch and verify gameplay/audio still work.
11. Run multiple sessions and watch for crashes, stutter, audio issues or unusually high heating.

## Google Play release

Before public release, complete on-device tests, add ads only if desired, update the privacy policy/Data safety answers to reflect the final SDKs, generate a release-signed Android App Bundle (`.aab`), capture screenshots from the actual tested build, and follow current Play Console testing and target API requirements. Choose the application ID carefully before first publication.
