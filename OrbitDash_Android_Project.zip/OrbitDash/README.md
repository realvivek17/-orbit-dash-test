# Orbit Dash — native offline Android arcade

**Version:** 1.4.0 (`versionCode 6`)  
**Package ID:** `com.dealnxt.orbitdash`  
**Minimum Android:** API 23  
**Compile / target SDK:** 36  
**Network:** No internet permission; playable game, themes, music and sound effects are bundled locally.

## What changed in 1.4.0

- Added an animated, code-rendered startup intro (~4.9 seconds) with moving orbital rings, player orb, gold star, pink hazard, animated cyan-to-violet progress bar, tagline and the exact credit `OFFICIALLY DESIGNED & DEVELOPED BY` / `TecNxt Team • Vivek Singh`.
- Added three bundled selectable worlds: **Cosmic Nebula**, **Celestial Frontier** and **Heavenly Realms**. Each has a genuine background artwork asset, preview card and locally persisted selection; the selected world is used in gameplay as well as the menus.
- Redesigned home navigation and reorganized the menu. Continue appears only when an actual saved run exists; when absent it no longer leaves a disabled placeholder in the layout. Added the Themes entry and the requested TecNxt/Vivek footer credit.
- Added background-cover drawing with central dimming for readable UI; the game remains a native Canvas implementation with real buttons and touch targets rather than screenshots of complete screens.
- Improved the Shop row design with live skin/effect previews and actual equipped/owned/locked states. The free Nebula skin remains available so players can switch back from paid cosmetics.
- Added consistent neon presentation to pause, score, mission and settings screens; removed non-functional progress dots from gameplay.
- Added locally bundled flute-led instrumental tracks. Music and effects remain separate, default volume remains deliberately quiet, and volume controls persist.
- Kept the Star Points economy (Easy 30 / Normal 50 / Hard 100 per collected star), five paid cosmetic unlocks, daily mission rewards, run recovery, local top scores, and smooth Hard-mode difficulty ramping.
- Version is now 1.4.0 / `versionCode 6`.


- Added a first-run local pilot profile that requests name and age after the splash. Inputs are validated and kept only in on-device SharedPreferences; no account or network permission is used.
- Added four persistent music choices in Settings: **Cosmic Drift**, **Serenity Flute**, **Nebula Pulse**, and **Celestial Journey**. Left/right arrows switch tracks and the selected OGG loops until the player changes it. Each track is an original synthesized flute-led instrumental rendered locally, with a deliberately quiet default volume.
- Added an **About Us** home-menu entry with the requested team message and a softly animated heart backdrop.
- Improved small-text legibility with a brighter secondary text colour, modest global text scaling, and a dark translucent home-footer plaque so the developer credit remains readable against the celestial worlds.
- Moved theme image decoding off the UI thread and decode JPEG artwork to RGB_565 to reduce first-open stalls and memory pressure. Audio assets prepare asynchronously as well.
- Quieted default sound-effect gain a little further. The prior single ambience file was removed once the four selectable OGG tracks were added.

## Existing features retained

- Native Android Canvas renderer; two-orbit one-touch gameplay, pink hazards, gold-star collectibles and local starfield.
- Personal best, last score, top-five local scores, total runs and daily missions.
- Continue/save-run, pause/resume with three-second countdown, restart, home and exit.
- Auto / Low / High graphics quality.
- Local SharedPreferences storage; no account, analytics, ads, backend or internet permission.

## Project files

- `app/src/main/java/com/dealnxt/orbitdash/MainActivity.kt` — animation, Canvas rendering, screen navigation, gameplay, themes, shop, scoring, missions, touch interactions and persistence.
- `app/src/main/java/com/dealnxt/orbitdash/OrbitAudio.kt` — local looping music, independent SFX and volume controls.
- `app/src/main/assets/themes/` — compressed portrait artwork for the three world backgrounds.
- `app/src/main/res/raw/` — four selectable flute-led OGG music loops plus sound effects.
- `marketing/` — app icon, feature graphic, Play listing draft, privacy draft and publishing checklist.

## Build from a phone using the repository workflow

The repository workflow expects the archive at the repository root named exactly `OrbitDash_Android_Project.zip` and extracts it to `source/OrbitDash`.

1. Download the updated ZIP from the conversation.
2. In the repository **Code** page, open `…` → **Upload files** and choose `OrbitDash_Android_Project.zip` from Downloads. Commit to `main` (if GitHub flags a duplicate path, do not delete other files; send the conflict screenshot for the safe replacement step).
3. Open **Actions** and select the newest `Build Orbit Dash APK` run. Wait for a green check.
4. On the run summary, scroll to **Artifacts** and download `OrbitDash-debug-APK`.
5. Extract the artifact ZIP and install `app-debug.apk`. A debug-signing conflict with a previously installed test build can require uninstalling the older test APK first; this may remove local progress.

## Verification status

Kotlin source was compiled against lightweight local Android API stubs and static resource/manifest checks passed. This is not equivalent to a full Gradle build against the Android SDK, nor does it verify runtime rendering or physical-device behavior. The latest archive still needs the repository's real Gradle build and on-device acceptance checks before it can be called fully verified. See `QA_STATUS.md`.

The included workflow produces a **debug testing APK**, not a Play Store release. A release-signed AAB, Play Console checks, final privacy/Data safety review, real screenshots and device testing remain separate tasks.
