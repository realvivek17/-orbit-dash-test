# Orbit Dash — native offline Android game

**Genre:** one-touch arcade / endless survival  
**Package ID:** `com.dealnxt.orbitdash`  
**Current source version:** `1.0.1` (`versionCode 2`)  
**Minimum Android:** API 23  
**Target / compile API:** 36

## What changed in this build

The previous test build used a `WebView` to run the HTML game. Because that APK showed a white screen and closed on the user's phone, this version replaces the Android runtime with a **native Android `Canvas` game view**. The launcher activity no longer depends on Android System WebView or loading a local HTML page.

## Gameplay

- Tap once to start a run.
- During a run, tap anywhere to switch between inner and outer orbits.
- Avoid pink hazards and collect gold stars.
- Speed increases gradually.
- Best score and sound preference are saved locally on the device.
- Sound is optional and can be toggled from the speaker icon.
- Portrait, fullscreen, offline gameplay; no internet permission, ads, accounts, analytics, or server calls in this build.

## Project layout

- `app/src/main/java/com/dealnxt/orbitdash/MainActivity.kt` — native activity and game rendering/input/score logic.
- `app/src/main/assets/index.html` — older self-contained browser prototype only. The Android app no longer loads this file.
- `app/src/main/AndroidManifest.xml` — launcher activity, portrait orientation, no requested permissions.
- `app/build.gradle.kts` — application ID, API levels and version.
- `marketing/` — icon, feature graphic, store copy, privacy-policy draft, release checklist.

## Build using the phone-only GitHub Actions workflow

The repository workflow expects a project archive in the repository root named exactly `OrbitDash_Android_Project.zip`. Upload this ZIP to the root of your repository (not into `.github/workflows`) and commit to `main`. The existing workflow runs automatically and uploads an artifact named `OrbitDash-debug-APK` when the build succeeds.

1. Download the updated project ZIP.
2. In the GitHub repository's **root Code tab**, use `…` → **Upload files** and upload/replace `OrbitDash_Android_Project.zip`.
3. Commit to `main`.
4. Open **Actions**, then the newest `Build Orbit Dash APK` run. Wait for the green check.
5. Open the run summary, scroll to **Artifacts**, and tap the download icon beside `OrbitDash-debug-APK`.
6. Extract the artifact ZIP; install `app-debug.apk` on the Android phone. Uninstall the previous debug build first if Android reports an installation/signature conflict.

## QA status — be precise about what's verified

- Kotlin source passed a local syntax/type check against minimal Android API stubs.
- Project configuration declares compile/target API 36, Java/Kotlin target 17 and min API 23.
- Manifest does not request internet or other runtime permissions.
- **Not yet verified in a real Android Gradle build or on a physical handset.** The new native version must be uploaded and built in GitHub Actions, then installed and exercised on the target phone. A successful CI build proves compilation/package creation only, not that every device behaves correctly.

## On-device test checklist

1. Launch app and confirm the dark Orbit Dash menu appears promptly.
2. Tap anywhere; the run begins and score is visible.
3. Tap several times; the player moves between the two orbits.
4. Confirm pink hazards can end a run, gold stars increase score, and replay works.
5. Toggle sound and confirm it remembers the preference after relaunch.
6. End a run, relaunch the app, and confirm best score is retained.
7. Turn on airplane mode, relaunch, and confirm the game still works offline.
8. Try Android Back while playing and from the menu.

## Google Play and earning

This is an **ad-free testing build** and earns no ad revenue yet. Add AdMob only after the game passes physical-device testing; configure test ads first, then privacy policy/data-safety disclosures that match the shipped SDKs. Before public distribution, build a signed Android App Bundle (`.aab`), confirm the package name/title are final, use screenshots captured from the actual tested app, and complete Play Console declarations/testing.

The application ID is already set to `com.dealnxt.orbitdash`. Choose carefully before the first Play Store publication because changing it later creates a different app listing.
