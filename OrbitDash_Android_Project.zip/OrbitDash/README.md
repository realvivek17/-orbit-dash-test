# Orbit Dash — Offline Android Game (starter project)

**Genre:** one-touch arcade / endless survival  
**Gameplay:** tap to switch between inner and outer orbits, avoid pink hazards, collect gold stars, and beat your best score.

## What is included

- `app/src/main/assets/index.html` — complete self-contained game; no CDN, images, fonts, or network fetches.
- `app/src/main/java/com/dealnxt/orbitdash/MainActivity.kt` — Android WebView wrapper that loads the game from the app's local assets.
- Android Gradle project targeting **API 36** with portrait orientation and no requested Android permissions.
- App launcher icons and a Google Play feature-graphic starter asset in `marketing/`.
- Starter store listing text and a privacy-policy draft in `marketing/`.

## Try the game immediately

Open `app/src/main/assets/index.html` in a modern browser. On a phone, use the downloaded HTML file in a browser/file viewer that permits local HTML. On desktop, use mouse clicks or Space; on a phone, tap anywhere in a run to switch tracks. The game stores only the best score and sound toggle locally.

## Build the Android app

1. Install **Android Studio** with Android SDK Platform 36 and a JDK 17-compatible setup.
2. Extract this folder, then open the **OrbitDash** folder (the one containing `settings.gradle.kts`) in Android Studio.
3. Let Gradle sync and install the requested SDK/build components if prompted.
4. Use **Build → Build Bundle(s) / APK(s) → Build APK(s)** for a local test APK, or **Build → Generate Signed Bundle / APK → Android App Bundle** for a Play Console AAB.
5. Install and test on several real devices before releasing. Check touch controls, sound toggle, saved best score after relaunch, Android Back behavior, and different screen sizes.

This environment did not have the Android SDK or Gradle installed, so the signed APK/AAB has **not** been built here. The source project is prepared for an Android Studio build; the project still needs a real-device build/test pass before release.

## Monetization plan

This first build deliberately contains **no ads, analytics, account, or internet permission**, so the core game works offline. To earn from ads, integrate Google AdMob in a later build, add the required network permission and test ad IDs, publish an accurate privacy policy and Data safety declaration, and verify ad placements do not interrupt controls or create accidental clicks. Never click your own live ads. Ad revenue depends on downloads, active users, geography, ad fill, retention, and policy compliance; it is not guaranteed.

## Suggested first improvements before launch

- Play-test difficulty and tune spawn timing based on real users.
- Add a proper pause/resume flow and optional vibration setting.
- Add a genuine store screenshot set from the final Android build.
- Add AdMob only after the no-ad build is stable.
- Confirm that the app title and package name are available and suitable before release.

## Technical notes

- Application ID: `com.dealnxt.orbitdash` (change this before first publication if you prefer a different publisher namespace; after publishing, changing it creates a different app listing).
- Version: `1.0.0` / version code `1`.
- Minimum Android version: API 23.
- Compile/target API: 36.
- The game uses canvas + vanilla JavaScript and is bundled locally in the APK. Gameplay does not require Wi-Fi or mobile data.
