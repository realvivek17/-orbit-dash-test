# Orbit Dash — native offline Android arcade

**Version:** 1.2.0 (`versionCode 4`)  
**Package ID:** `com.dealnxt.orbitdash`  
**Minimum Android:** API 23  
**Compile / target SDK:** 36  
**Network:** No internet permission; the playable game, soundtrack and sound effects are bundled locally.

## What changed in 1.2.0

- Reorganized the home screen: Star Points balance at the top, compact Easy / Normal / Hard selectors, primary New Game / Continue actions, and a consistent High Scores / Shop / Missions / Settings grid.
- Added home-screen credits: `Developed by TecNxt Developers · Vivek Singh`.
- Replaced the old earned-star currency with **Star Points**. Each collectible star earns 30 points in Easy, 50 in Normal, or 100 in Hard. The existing `banked_stars` balance is migrated once at 50 points per old star, preserving existing progress at the Normal-mode rate.
- Replaced Ship Lab with a five-item cosmetic Shop: Ice Comet (3,000), Solar Flare (5,000), Aurora Trail (8,000), Starburst (12,000), and Eclipse (18,000) Star Points. Nebula remains free. Purchases persist and purchased items can be equipped again without paying twice.
- Made cosmetic items visibly different: ship colors, longer Aurora trail, and alternate Starburst/Eclipse collection effects. Items do not affect collision rules or gameplay advantage.
- Replaced the previous ambience with a custom 24-second atmospheric neon/sci-fi instrumental loop, locally bundled and crossfaded for a smoother repeat; no streaming or network access is needed.
- Balanced modes separately. Easy uses slower hazards and a longer spawn interval; Normal increases challenge steadily; Hard uses smooth difficulty milestones at 15, 30, 45, and 60 seconds, with additional gradual ramping after one minute.
- Added music and effects volume sliders to Settings. Default levels are intentionally low; independent on/off controls remain available. The single local 24-second instrumental loops automatically.
- Background music prepares asynchronously so decoding the WAV is less likely to delay the first home-screen frame. Audio errors remain non-fatal.
- Polished the home orbit animation with low-cost breathing pulses; improved obstacle outline and a subtle near-impact warning halo.
- Cached milestone/action tables outside the frame loop to reduce avoidable repeated allocation.
- Bumped app version to 1.2.0 / versionCode 4.

## Existing features retained

- Native Android Canvas renderer; two-orbit one-touch gameplay, pink hazards, gold-star collectibles and local starfield.
- Personal best, last score, top-five local scores, total runs and daily missions.
- Continue / save-run, pause/resume with 3-second countdown, restart, home and exit.
- Auto / Low / High graphics quality.
- Local SharedPreferences storage; no account, analytics, ads, network services or internet permission.

## Project files

- `app/src/main/java/com/dealnxt/orbitdash/MainActivity.kt` — game loop, rendering, home/menu scenes, shop, difficulty, missions, interactions and persistence.
- `app/src/main/java/com/dealnxt/orbitdash/OrbitAudio.kt` — local looping instrumental music, independent sound effects and volume controls.
- `app/src/main/res/raw/` — bundled WAV music and SFX.
- `marketing/` — app icon, feature graphic, Play listing draft, privacy draft and publishing checklist.

## Build from a phone using the repository workflow

The repository workflow expects an archive in the repository root named exactly `OrbitDash_Android_Project.zip` and extracts it to `source/OrbitDash`.

1. Download this updated ZIP from the conversation.
2. Open the repository's **Code** tab. Use `…` → **Upload files** and choose `OrbitDash_Android_Project.zip` from Downloads. Commit to `main`.
3. Open **Actions** and select the newest `Build Orbit Dash APK` run. Wait for a green check.
4. On the run summary, scroll to **Artifacts** and download `OrbitDash-debug-APK`.
5. Extract the artifact ZIP and install `app-debug.apk`. A debug signing-key conflict with a previously installed test build may require uninstalling the older test APK first.

## Verification status

A source ZIP is not a real-device test. The revised project must still pass the current repository's Gradle Android build and be installed on a physical device before it is called release-ready. Test the controls, sound sliders, shop purchases, point migration, three difficulty modes, pause/save/continue, Low/High graphics and offline behavior. See `QA_STATUS.md` for the current check status and device acceptance checklist.

The included workflow is for a **debug testing APK**, not a Play Store release. A release-signed AAB, Play Console checks, final privacy/Data safety review, and device testing remain separate tasks.
