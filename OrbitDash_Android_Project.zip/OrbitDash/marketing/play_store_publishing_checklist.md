# Google Play publishing checklist

This is a release checklist, not a claim that the app has already been approved.

## Before building a release

- Choose your final publisher name and decide whether `com.dealnxt.orbitdash` is the package ID you want to keep permanently.
- Install Android Studio, JDK 17, and Android SDK Platform 36.
- Build and install a debug APK; test on real devices and fix issues before release.
- Build a signed Android App Bundle (AAB) for Play Console.
- Create final screenshots captured from the actual game, and check icon/feature graphic dimensions in Play Console.
- Replace all placeholders in the privacy policy and host it at a stable public URL.
- Complete the Data safety, content rating, target audience, app access, and ads declarations truthfully for the exact build submitted.

## Important current requirements to verify in Play Console

- As of 31 August 2026, new apps and updates must target Android 16 / API 36 or higher.
- New personal Play Console accounts created after 13 November 2023 must complete a closed test with at least 12 opted-in testers continuously for 14 days before applying for production access.
- A full-distribution Google Play developer account has a one-time US$25 registration fee; identity verification also applies.

Official references:
- Target API level: https://support.google.com/googleplay/android-developer/answer/11926878
- New personal account testing: https://support.google.com/googleplay/android-developer/answer/14151465
- Developer account registration: https://support.google.com/googleplay/android-developer/answer/6112435

## Ads / earnings

The current prototype ships with no ad SDK, analytics, network permission, or real-money features. It will not earn ad revenue in this state. Before earning from ads, choose an ad format and ad network, configure the actual publisher account and app IDs, integrate the SDK with test ads first, review consent/privacy obligations, and update your privacy policy and Play Console declarations. Then test the game both offline and online. Ad revenue is not guaranteed.
