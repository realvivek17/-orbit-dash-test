# Orbit Dash — Google Play publishing checklist

This checklist describes remaining work; it is not a claim that the app is approved or publication-ready today.

## Before public release

- [ ] Build the revised native project in GitHub Actions; check a green build result.
- [ ] Install the generated debug APK on a real phone and complete the full on-device checklist in `QA_STATUS.md`.
- [ ] Test at least one additional Android device / screen size before release.
- [ ] Tune hazard spawn timing based on play tests; check for crashes, bad tap areas and unwanted exits.
- [ ] Choose the final developer/publisher name and support email.
- [ ] Check that the app title and `com.dealnxt.orbitdash` package ID are suitable and available before first publication.
- [ ] Produce a **release-signed Android App Bundle (`.aab`)**; the GitHub debug APK is not the Play Store release artifact.
- [ ] Capture actual screenshots from the tested game. Do not use feature artwork as a screenshot.
- [ ] Replace privacy policy placeholders and host the policy at a stable public URL.
- [ ] Complete app access, content rating, target audience, Data safety, ads and all other Play Console declarations truthfully.

## Current official requirements to re-check in Play Console

- As of 31 August 2026, new apps and updates must target Android 16 / API 36 or higher for Google Play submissions.
- Personal developer accounts created after 13 November 2023 must run a closed test with at least 12 opted-in testers continuously for 14 days before applying for production access.
- A Google Play full-distribution developer account has a one-time US$25 registration fee; identity verification also applies.

Official references:
- Target API: https://support.google.com/googleplay/android-developer/answer/11926878
- New personal account testing: https://support.google.com/googleplay/android-developer/answer/14151465
- Developer registration: https://support.google.com/googleplay/android-developer/answer/6112435

## Ads and revenue

This revision is an ad-free test build; it cannot earn advertising revenue yet. Only after core gameplay is stable should AdMob be integrated: start with test ads, then configure the publisher's own app/ad IDs and required privacy/consent disclosures, and update the privacy policy and Play Console declarations. Test both offline and online behavior. Revenue depends on active users, geography, ad fill, impressions and retention; it is not guaranteed. Never click your own live ads.
