# Privacy Policy — Orbit Dash (draft for the no-ads starter build)

**Effective date:** [insert publication date]

Orbit Dash is developed by [insert developer or business name]. This policy explains how the current no-ads version handles information.

## Information the app stores

The game saves your best score and sound preference locally on your device. These settings are used only to remember your progress and preference. They are not sent to the developer by this build.

## Network access, analytics and advertising

The current starter build does not request internet access and does not include advertising SDKs, analytics SDKs, user accounts, or third-party sign-in.

## Children

The app has no account or online social features in this starter build. Complete the Play Console target-audience and content-rating steps accurately before release.

## Changes to this policy

If the app later adds ads, analytics, cloud saves, or other network features, this policy must be revised to disclose the actual data collected, purposes, sharing, retention, and user choices. The Play Console Data safety form must match the shipped app and SDK behavior.

## Contact

Email: [insert a monitored support email]

---

**Do not publish this draft with placeholders.** Replace the developer name, date, and contact email, host it at a stable public URL, and ensure it accurately matches the exact build you submit.
