# Orbit Dash — Privacy Policy (testing-build draft)

**Last updated:** 11 October 2026

Orbit Dash is an offline arcade game. In this testing build, the app does not request internet access, does not use advertising or analytics SDKs, does not create an account, and does not send gameplay information to a server.

The app stores gameplay preferences and progress locally on the device using Android SharedPreferences. This includes the selected difficulty/graphics options, music and sound settings, best and recent scores, star balance, selected cosmetic ship, daily mission progress, and a paused run used by the Continue feature. This information stays on the device in this build and can be removed by clearing the app's storage or uninstalling it.

Background music and sound effects are bundled inside the app and play locally. There are no third-party content downloads in this build.

This document describes the current ad-free testing build only. If advertising, analytics, online leaderboards, crash-reporting or other third-party SDKs are added later, revise this policy and the Google Play Data safety form before release to describe the actual data practices and SDK behavior.

**Contact:** Add a monitored developer contact email before public release.
