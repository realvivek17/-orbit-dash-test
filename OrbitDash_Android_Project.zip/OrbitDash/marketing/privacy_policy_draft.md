# Privacy Policy — Orbit Dash (ad-free native test build draft)

**Effective date:** [insert publication date]  
**Developer:** [insert your legal/publisher name]  
**Contact:** [insert a monitored support email]

## Information handled by this version

Orbit Dash saves the player's best score and sound preference locally on the device. These settings are used only to maintain game progress and preference. This version does not send them to the developer.

## Internet, advertising and analytics

The current native test build does not request internet permission and does not include ad SDKs, analytics SDKs, accounts, third-party sign-in, or remote services.

## Children and ratings

The app has no account or online social features in this test build. The developer must still complete the Play Console target-audience and content-rating declarations accurately before publication.

## Future versions

If ads, analytics, cloud saves, online services, or other SDKs are added later, this policy must be rewritten to describe actual collection, use, sharing, retention, and user choices. The Play Console Data safety and ads declarations must match the actual published build and its SDK behavior.

## Before publication

Do not publish this draft with placeholders. Replace the publisher name, date and contact email; host the policy at a stable public URL; then verify that it accurately describes the exact version submitted to Google Play.
