# Orbit Dash — Google Play listing draft

## App name
Orbit Dash

## Short description
One tap. Two orbits. Dodge neon hazards and chase your best score.

## Full description
Enter a neon-lit space arcade where one quick tap can save your run. Switch between two glowing orbits, dodge pink hazards, collect golden stars and push your score a little further every time.

**FEATURES**
- One-touch, easy-to-learn two-orbit gameplay.
- Easy, Normal and Hard difficulty modes.
- Polished neon space visuals, glowing trails and animated starfields.
- Pause anytime, resume with a short countdown, restart instantly or continue a saved run.
- Local personal best and top-five score history.
- Daily missions with earnable star rewards.
- Unlockable cosmetic ships.
- Background soundtrack and sound effects with independent controls.
- Auto, Low and High graphics settings.
- Play offline: gameplay, soundtrack and effects are bundled in the app.

Orbit Dash is designed for short breaks and high-score challenges. No account is needed in this testing build.

## Release note draft — 1.1.0
Added a full home menu, difficulty selection, saved-run continuation, pause/resume countdown, local score history, daily missions, ship skins, graphics settings and original background audio. Improved the native rendering path and removed the Android WebView dependency.

## Before publication
Replace draft claims only after testing the release candidate on multiple devices. Add actual phone screenshots, a developer support email and the final privacy-policy URL. Update this listing if ads or any network features are added later.
