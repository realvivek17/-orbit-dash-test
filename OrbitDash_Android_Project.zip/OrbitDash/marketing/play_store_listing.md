# Play Store listing — draft

## App name
Orbit Dash: Neon Switch

## Short description
Switch orbits, dodge hazards and chase your best score — fully offline.

## Full description
One tap. Two orbits. How long can you last?

Orbit Dash is a quick-to-learn arcade survival game built for short breaks and “one more run” moments. Your runner circles the core automatically. Tap to switch between the inner and outer orbit, avoid pink hazards, and collect glowing gold stars.

FEATURES
- One-thumb controls: tap to switch orbits.
- Endless arcade runs with gradually increasing speed.
- Gold collectibles and a score bonus.
- Personal best saved on your device.
- Optional sound effects.
- Works offline — no account or connection needed to play.
- Lightweight, portrait-friendly gameplay.

HOW TO PLAY
1. Tap Play.
2. Tap anywhere during the run to switch orbits.
3. Do not collide with pink hazards.
4. Collect gold stars and beat your best score.

Easy to start, challenging to master. Take one quick run and see how far you can go.

## Category suggestion
Games → Arcade

## Content rating
Complete the official content-rating questionnaire in Play Console based on the final build.

## Store assets
- App icon: `orbitdash_icon_512.png`
- Feature graphic: `play_feature_graphic_1024x500.png`
- Capture real device screenshots after building/testing the final Android version; do not use the feature graphic as a screenshot.

Note: This is starter copy. Confirm title availability, policy declarations, and the final implemented feature set before submission. If ads are added, update the listing/privacy/data declarations accordingly.
